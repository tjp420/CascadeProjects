// Bridge the VS Code webview host, the extension, and the embedded dashboard iframe.
(function () {
  'use strict';

  const vscode = acquireVsCodeApi();
  const iframe = document.getElementById('dash');
  const overlay = document.getElementById('drag-overlay');
  const urlInput = document.getElementById('sbUrlInput');
  const backBtn = document.getElementById('sbBackBtn');
  const fwdBtn = document.getElementById('sbFwdBtn');
  const reloadBtn = document.getElementById('sbReloadBtn');
  const externalBtn = document.getElementById('sbExternalBtn');

  const browserHistory = { urls: [], index: -1, pendingUrl: null };

  function getCurrentUrl() {
    if (browserHistory.index >= 0 && browserHistory.urls[browserHistory.index]) {
      return browserHistory.urls[browserHistory.index];
    }
    if (urlInput && urlInput.value) return urlInput.value;
    if (iframe) return iframe.getAttribute('src') || iframe.src || '';
    return '';
  }

  function updateToolbar() {
    if (urlInput) urlInput.value = browserHistory.urls[browserHistory.index] || '';
    if (backBtn) backBtn.disabled = browserHistory.index <= 0;
    if (fwdBtn) fwdBtn.disabled = browserHistory.index < 0 || browserHistory.index >= browserHistory.urls.length - 1;
  }

  function pushHistory(url) {
    if (!url) return;
    browserHistory.urls = browserHistory.urls.slice(0, browserHistory.index + 1);
    if (browserHistory.urls[browserHistory.index] === url) return;
    browserHistory.urls.push(url);
    browserHistory.index = browserHistory.urls.length - 1;
    updateToolbar();
  }

  function navigateToUrl(url, push) {
    if (!url || !iframe) return;
    browserHistory.pendingUrl = url;
    iframe.src = url;
    if (urlInput) urlInput.value = url;
    if (push) pushHistory(url);
    else updateToolbar();
  }

  function goBack() {
    if (browserHistory.index > 0) {
      browserHistory.index--;
      navigateToUrl(browserHistory.urls[browserHistory.index], false);
    }
  }

  function goForward() {
    if (browserHistory.index < browserHistory.urls.length - 1) {
      browserHistory.index++;
      navigateToUrl(browserHistory.urls[browserHistory.index], false);
    }
  }

  function refresh() {
    if (iframe && browserHistory.index >= 0) {
      navigateToUrl(browserHistory.urls[browserHistory.index], false);
    }
  }

  if (iframe) {
    const initialUrl = iframe.getAttribute('src') || iframe.src;
    if (initialUrl) pushHistory(initialUrl);
  }

  if (backBtn) backBtn.addEventListener('click', goBack);
  if (fwdBtn) fwdBtn.addEventListener('click', goForward);
  if (reloadBtn) reloadBtn.addEventListener('click', refresh);
  if (externalBtn) {
    externalBtn.addEventListener('click', function () {
      const url = getCurrentUrl();
      if (url) vscode.postMessage({ command: 'openExternalUrl', url });
    });
  }
  if (urlInput) {
    urlInput.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      const raw = urlInput.value.trim();
      if (!raw) return;
      navigateToUrl(raw, true);
    });
  }

  window.addEventListener('message', function (ev) {
    if (!ev.data || !ev.data.command) return;
    const fromIframe = typeof ev.origin === 'string' && ev.origin.length > 0 && ev.origin.startsWith('http');

    if (fromIframe) {
      if (ev.data.command === 'dashboardRouteChanged' && ev.data.url) {
        const url = ev.data.url;
        if (browserHistory.pendingUrl === url) {
          browserHistory.pendingUrl = null;
          updateToolbar();
        } else {
          pushHistory(url);
        }
      }
      if (ev.data.command === 'setAuthState' || ev.data.command === 'getAuthState' || ev.data.command === 'dashboardRouteChanged' || ev.data.command === 'scanWorkspace' || ev.data.command === 'downloadComplete') {
        vscode.postMessage(ev.data);
      }
      return;
    }

    if (ev.data.command === 'navigateToRoute' && ev.data.url) {
      navigateToUrl(ev.data.url, true);
      return;
    }

    if (ev.data.command === 'setAuthState' || ev.data.command === 'setTheme' || ev.data.command === 'getAuthState') {
      if (iframe && iframe.contentWindow) {
        iframe.contentWindow.postMessage(ev.data, '*');
      }
    }
  });

  function requestDashboardAuthState() {
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'getAuthState' }, '*');
    }
  }

  if (iframe) {
    iframe.addEventListener('load', requestDashboardAuthState);
  }
  let authPollCount = 0;
  const authPollInterval = setInterval(function () {
    requestDashboardAuthState();
    authPollCount++;
    if (authPollCount >= 3) { clearInterval(authPollInterval); }
  }, 1000);

  let dragDepth = 0;
  function showOverlay() {
    dragDepth++;
    overlay.style.display = 'block';
    if (iframe) iframe.style.pointerEvents = 'none';
  }
  function hideOverlay() {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) {
      overlay.style.display = 'none';
      if (iframe) iframe.style.pointerEvents = '';
    }
  }
  function parseFileUri(uri) {
    if (!uri || !uri.startsWith('file:///')) return '';
    let p = uri.slice(8).replace(/\/$/, '');
    try { p = decodeURIComponent(p); } catch (e) {}
    return p;
  }
  function extractDropPath(dt) {
    if (!dt) return { path: '', name: '' };
    let entryName = '';
    try {
      const item = dt.items && dt.items[0];
      if (item && typeof item.webkitGetAsEntry === 'function') {
        const entry = item.webkitGetAsEntry();
        if (entry) { entryName = entry.name || ''; }
      }
    } catch (e) {}
    const files = dt.files;
    if (files && files.length > 0 && files[0].path) {
      const fp = files[0].path.replace(/\\/g, '/');
      const name = entryName || files[0].name || '';
      if (name) {
        const idx = fp.indexOf('/' + name + '/');
        if (idx >= 0) { return { path: fp.slice(0, idx + name.length + 1), name }; }
        const endIdx = fp.lastIndexOf('/' + name);
        if (endIdx >= 0) { return { path: fp.slice(0, endIdx + name.length + 1), name }; }
      }
      return { path: fp.substring(0, fp.lastIndexOf('/')), name: files[0].name };
    }
    const uriList = (() => { try { return dt.getData('text/uri-list') || ''; } catch (e) { return ''; } })();
    if (uriList) {
      const uri = uriList.trim().split('\n')[0]?.trim();
      const p = parseFileUri(uri);
      if (p) return { path: p, name: p.split('/').pop() || '' };
    }
    const plain = (() => { try { return dt.getData('text/plain') || ''; } catch (e) { return ''; } })();
    if (plain) {
      const p = plain.trim().split('\n')[0]?.trim().replace(/^["']|["']$/g, '');
      if (p && /^[a-zA-Z]:[\\\/]/.test(p)) {
        const normalized = p.replace(/[\\\/]+$/, '').replace(/\\/g, '/');
        return { path: normalized, name: normalized.split('/').pop() || '' };
      }
    }
    return { path: '', name: '' };
  }
  window.addEventListener('dragenter', function (ev) { ev.preventDefault(); showOverlay(); });
  window.addEventListener('dragover', function (ev) { ev.preventDefault(); if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'copy'; });
  window.addEventListener('dragleave', function () { hideOverlay(); });
  overlay.addEventListener('dragover', function (ev) { ev.preventDefault(); if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'copy'; });
  overlay.addEventListener('drop', function (ev) {
    ev.preventDefault();
    dragDepth = 0;
    overlay.style.display = 'none';
    const dt = ev.dataTransfer;
    const { path, name } = extractDropPath(dt);
    if (path && iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'ideDropPath', path: path.replace(/\//g, '\\\\'), name }, '*');
    } else if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'ideDropFailed', reason: 'Could not read dropped path. Use Browse Folder or type the path.' }, '*');
    }
  });
})();
//# sourceURL=dashboard-wrapper.js
