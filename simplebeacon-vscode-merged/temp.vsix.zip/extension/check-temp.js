const fs = require('fs');
const html = fs.readFileSync(process.env.TEMP + '/simplebeacon-sidebar-browser.html', 'utf8');
const lines = html.split('\n');

let inScript = false;
let inString = false;
let stringStartLine = -1;
let quoteChar = '';

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  if (line.includes('<script') && !line.includes('</script>')) {
    inScript = true;
    continue;
  }
  if (line.includes('</script>')) {
    inScript = false;
    continue;
  }
  
  if (!inScript) continue;
  
  let skip = false;
  for (let j = 0; j < line.length; j++) {
    if (skip) { skip = false; continue; }
    const ch = line[j];
    if (ch === '\\') { skip = true; continue; }
    
    if (!inString && (ch === "'" || ch === '"' || ch === '`')) {
      inString = true;
      quoteChar = ch;
      stringStartLine = i;
    } else if (inString && ch === quoteChar) {
      inString = false;
    }
  }
  
  if (inString && i > stringStartLine) {
    console.log('Multi-line string from line', stringStartLine + 1, 'to', i + 1);
    console.log('  Start:', lines[stringStartLine].trim().substring(0, 80));
    console.log('  End:', lines[i].trim().substring(0, 80));
  }
}

if (inString) {
  console.log('Unclosed string starting at line', stringStartLine + 1);
  console.log('  ', lines[stringStartLine].trim().substring(0, 80));
}
