const fs = require('fs');
const path = require('path');

// Read the compiled welcomeDashboard.js
const compiledPath = path.join(__dirname, 'out', 'welcomeDashboard.js');
if (!fs.existsSync(compiledPath)) {
  console.error('Compiled file not found:', compiledPath);
  process.exit(1);
}

const code = fs.readFileSync(compiledPath, 'utf8');

// Find the buildHtml method and extract its template literal
// The compiled JS will have the template literal converted to string concatenation
// Let's search for the HTML output pattern
const doctypeIdx = code.indexOf('<!DOCTYPE html>');
if (doctypeIdx === -1) {
  console.error('DOCTYPE not found in compiled code');
  process.exit(1);
}

// Find the end of the template literal (the closing backtick or equivalent)
// In compiled JS, template literals are often preserved
let htmlStart = doctypeIdx;
let htmlEnd = code.indexOf('";\n}', htmlStart);
if (htmlEnd === -1) htmlEnd = code.indexOf('`;\n}', htmlStart);
if (htmlEnd === -1) htmlEnd = code.indexOf('");\n}', htmlStart);
if (htmlEnd === -1) htmlEnd = code.indexOf('`);\n}', htmlStart);

// Try a broader search
if (htmlEnd === -1) {
  // Find the pattern that ends buildHtml
  const pattern = 'buildHtml(): string {\n    const nonce';
  const methodStart = code.indexOf('buildHtml()');
  if (methodStart !== -1) {
    // Find the return statement
    const returnIdx = code.indexOf('return `', methodStart);
    if (returnIdx !== -1) {
      htmlStart = returnIdx + 'return '.length;
      // Find the end of the template literal
      let depth = 0;
      for (let i = htmlStart; i < code.length; i++) {
        if (code[i] === '`' && (i === 0 || code[i-1] !== '\\')) {
          if (depth === 0) { depth = 1; }
          else { htmlEnd = i; break; }
        }
      }
    }
  }
}

if (htmlEnd === -1 || htmlEnd <= htmlStart) {
  console.error('Could not find end of HTML template');
  process.exit(1);
}

let html = code.substring(htmlStart, htmlEnd + 1);

// The html might start with a backtick and end with a backtick
if (html.startsWith('`')) html = html.slice(1);
if (html.endsWith('`')) html = html.slice(0, -1);

// Replace escaped newlines and template expression placeholders
html = html.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\`/g, '`');

// Write the HTML to a file for inspection
fs.writeFileSync('debug-welcome.html', html);
console.log('HTML written to debug-welcome.html');
console.log('Total lines:', html.split('\n').length);

// Now check line 4265
const lines = html.split('\n');
if (lines.length > 4264) {
  console.log('\nLine 4265:');
  console.log(lines[4264]);
  console.log('\nContext (lines 4260-4270):');
  for (let i = 4259; i < Math.min(lines.length, 4270); i++) {
    console.log((i+1) + ': ' + lines[i].substring(0, 120));
  }
}
