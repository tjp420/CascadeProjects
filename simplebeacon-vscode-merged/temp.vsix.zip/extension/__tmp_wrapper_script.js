
  const vscode = acquireVsCodeApi();
  const iframe = document.getElementById('dash');
  const overlay = document.getElementById('drag-overlay');
  window.addEventListener('message', function(ev) {
    if (!ev.data || !ev.data.command) return;
    // The embedded dashboard comes from an http(s) origin; the extension host does not.
    const fromIframe = typeof ev.origin === 'string' && ev.origin.length > 0 && ev.origin.startsWith('http');
    if (fromIframe) {
      // iframe (or nested dashboard) -> extension
      if (ev.data.command === 'setAuthState' || ev.data.command === 'getAuthState' || ev.data.command === 'dashboardRouteChanged' || ev.data.command === 'scanWorkspace' || ev.data.command === 'downloadComplete') {
        vscode.postMessage(ev.data);
      }
    } else if (ev.data.command === 'setAuthState' || ev.data.command === 'setTheme' || ev.data.command === 'getAuthState') {
      // Extension/webview host -> iframe
      if (iframe && iframe.contentWindow) {
        iframe.contentWindow.postMessage(ev.data, '*');
      }
    }
  });
  // Poll the dashboard for its current auth state after load so the extension/sidebar sync
  // even if the initial sign-in message was missed (e.g. due to timing or source-reference issues).
  setTimeout(function() {
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'getAuthState' }, '*');
    }
  }, 500);
  setInterval(function() {
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'getAuthState' }, '*');
    }
  }, 5000);
  // Intercept OS file/folder drops so the VS Code: webview wrapper can read the path
  // and forward it to the dashboard iframe. The overlay prevents the cross-origin iframe
  // from receiving the native drop event and failing to read the absolute path.
  let dragDepth = 0;
  function showOverlay() {
    dragDepth++;
    overlay.style.display = 'block';
    if (iframe) iframe.style.pointerEvents = 'none';
  }
  function hideOverlay() {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) {
      overlay.style.display = 'none';
      if (iframe) iframe.style.pointerEvents = '';
    }
  }
  function parseFileUri(uri) {
    if (!uri || !uri.startsWith('file:///')) return '';
    let p = uri.slice(8).replace(/\/$/, '');
    try { p = decodeURIComponent(p); } catch (e) {}
    return p;
  }
  function extractDropPath(dt) {
    if (!dt) return { path: '', name: '' };
    // Try reading the first dropped item as a file entry (folder or file).
    let entryName = '';
    try {
      const item = dt.items && dt.items[0];
      if (item && typeof item.webkitGetAsEntry === 'function') {
        const entry = item.webkitGetAsEntry();
        if (entry) { entryName = entry.name || ''; }
      }
    } catch (e) {}
    const files = dt.files;
    if (files && files.length > 0 && files[0].path) {
      const fp = files[0].path.replace(/\\/g, '/');
      const name = entryName || files[0].name || '';
      if (name) {
        const idx = fp.indexOf('/' + name + '/');
        if (idx >= 0) { return { path: fp.slice(0, idx + name.length + 1), name }; }
        const endIdx = fp.lastIndexOf('/' + name);
        if (endIdx >= 0) { return { path: fp.slice(0, endIdx + name.length + 1), name }; }
      }
      return { path: fp.substring(0, fp.lastIndexOf('/')), name: files[0].name };
    }
    // Fall back to standard file URI / plain text drop data.
    const uriList = (() => { try { return dt.getData('text/uri-list') || ''; } catch (e) { return ''; } })();
    if (uriList) {
      const uri = uriList.trim().split('\\n')[0]?.trim();
      const p = parseFileUri(uri);
      if (p) return { path: p, name: p.split('/').pop() || '' };
    }
    const plain = (() => { try { return dt.getData('text/plain') || ''; } catch (e) { return ''; } })();
    if (plain) {
      const p = plain.trim().split('\\n')[0]?.trim().replace(/^["']|["']$/g, '');
      if (p && /^[a-zA-Z]:[\\\/]/.test(p)) {
        const normalized = p.replace(/[\\\/]+$/, '').replace(/\\/g, '/');
        return { path: normalized, name: normalized.split('/').pop() || '' };
      }
    }
    return { path: '', name: '' };
  }
  window.addEventListener('dragenter', function(ev) { ev.preventDefault(); showOverlay(); });
  window.addEventListener('dragover', function(ev) { ev.preventDefault(); if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'copy'; });
  window.addEventListener('dragleave', function(ev) { hideOverlay(); });
  overlay.addEventListener('dragover', function(ev) { ev.preventDefault(); if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'copy'; });
  overlay.addEventListener('drop', function(ev) {
    ev.preventDefault();
    dragDepth = 0;
    overlay.style.display = 'none';
    const dt = ev.dataTransfer;
    const { path, name } = extractDropPath(dt);
    if (path && iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'ideDropPath', path: path.replace(/\\//g, '\\\\'), name }, '*');
    } else if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ command: 'ideDropFailed', reason: 'Could not read dropped path. Use Browse Folder or type the path.' }, '*');
    }
  });
