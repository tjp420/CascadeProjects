const fs = require('fs');
const zlib = require('zlib');

function createPNG(width, height, r, g, b) {
    const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    const ihdrData = Buffer.alloc(13);
    ihdrData.writeUInt32BE(width, 0);
    ihdrData.writeUInt32BE(height, 4);
    ihdrData.writeUInt8(8, 8);
    ihdrData.writeUInt8(2, 9);
    ihdrData.writeUInt8(0, 10);
    ihdrData.writeUInt8(0, 11);
    ihdrData.writeUInt8(0, 12);
    const ihdr = makeChunk('IHDR', ihdrData);
    const rowSize = width * 3 + 1;
    const rawData = Buffer.alloc(rowSize * height);
    for (let y = 0; y < height; y++) {
        rawData[y * rowSize] = 0;
        for (let x = 0; x < width; x++) {
            const offset = y * rowSize + 1 + x * 3;
            rawData[offset] = r;
            rawData[offset + 1] = g;
            rawData[offset + 2] = b;
        }
    }
    const compressed = zlib.deflateSync(rawData);
    const idat = makeChunk('IDAT', compressed);
    const iend = makeChunk('IEND', Buffer.alloc(0));
    return Buffer.concat([signature, ihdr, idat, iend]);
}

function makeChunk(type, data) {
    const length = Buffer.alloc(4);
    length.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type);
    const chunk = Buffer.concat([typeBuf, data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(chunk), 0);
    return Buffer.concat([length, chunk, crc]);
}

function crc32(buf) {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
        let c = i;
        for (let j = 0; j < 8; j++) {
            c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        table[i] = c;
    }
    let crc = -1;
    for (let i = 0; i < buf.length; i++) {
        crc = table[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ -1) >>> 0;
}

const png = createPNG(128, 128, 0, 120, 255);
fs.mkdirSync('resources', { recursive: true });
fs.writeFileSync('resources/icon.png', png);
console.log('Created resources/icon.png (128x128)');
