/**
 * Barrel tests for js-es2018/utils-lib/index.js
 * Run with: node __tests__.mjs
 */
import assert from 'assert';
import * as utils from './index.js';

// 1. Metadata & discovery
assert.ok(Array.isArray(utils.exportNames) && utils.exportNames.length > 0, 'exportNames populated');
assert.ok(Array.isArray(utils.getExportNames()), 'getExportNames returns array');
assert.ok(Array.isArray(utils.getNamespaceNames()), 'getNamespaceNames returns array');

const expectedNamespaces = [
  'string', 'number', 'async', 'array', 'object', 'url', 'storage',
  'accessibility', 'dom', 'format', 'type', 'fn', 'crypto', 'color',
  'download', 'fetch', 'privacy', 'clipboard', 'vscode', 'event',
  'path', 'polling', 'theme', 'notify'
];
for (const ns of expectedNamespaces) {
  assert.ok(utils.getNamespaceNames().includes(ns), `namespace ${ns} exists`);
  assert.ok(utils.default[ns], `defaultExport.${ns} exists`);
}

// 2. Key barrel exports exist
const expectedExports = [
  'escapeHtml', 'escapeRegExp', 'truncate', 'capitalize', 'words', 'repeat',
  'titleCase', 'slugify', 'stripHtml', 'kebabCase', 'camelCase', 'snakeCase',
  'padStart', 'padEnd', 'isBlank',
  'formatNumber', 'formatPercent', 'formatBytes', 'clamp', 'roundTo',
  'toFixedNumber', 'formatDuration', 'sum', 'mean', 'maxBy', 'minBy',
  'safeParseInt', 'safeParseFloat', 'random', 'randomId', 'uid',
  'sleep', 'delay', 'debounce', 'debounceAsync', 'debounceLeading',
  'throttle', 'throttleAsync', 'once', 'memoize', 'memoizeAsync',
  'withTimeout', 'retry', 'pMap', 'poll', 'waitForAsync',
  'deepClone', 'deepEqual', 'pick', 'omit', 'defaults', 'merge', 'invert',
  'mapValues', 'mapKeys', 'has', 'get', 'set', 'zipObject', 'identity',
  'constant', 'at', 'unset', 'defaultsDeep',
  'parseQueryString', 'stringifyQueryString', 'isValidUrl',
  'localStorageGet', 'localStorageSet', 'localStorageRemove',
  'localStorageGetString', 'localStorageSetString', 'sessionStorageGet',
  'sessionStorageSet',
  'prefersReducedMotion', 'prefersDarkMode',
  'showToast', 'removeToastContainer', 'hasClass', 'addClass', 'removeClass',
  'toggleClass',
  'formatDate', 'relativeTime', 'redactPathForDisplay', 'isRedactedPathDisplay',
  'formatPathLabel', 'normalizeSlashes', 'formatPathInputValue',
  'formatScanPathForDisplay', 'formatAiSummarySkipMessage',
  'isDefined', 'isNil', 'noop', 'assertNever', 'parseJsonSafe',
  'hash', 'hexToRgba', 'contrastColor',
  'downloadJson', 'downloadText', 'downloadCsv',
  'fetchWithTimeout',
  'sanitizePrivacyData',
  'copyToClipboard',
  'isVSCodeWebview', 'isStandalone', 'getVSCodeApi',
  'createEventBus', 'createBroadcastChannel',
  'resolveDashboardProjectPath',
  'createPoller',
  'getCssVar', 'setCssVar',
  'notifyVSCode', 'notifyDownloadComplete', 'notifyAuthState',
  'seq', 'flow', 'negate', 'zipWith', 'curry', 'partial', 'tap',
  'deepFreeze', 'parseJsonSafe', 'toFixedNumber', 'zipObject', 'delay',
  'throttleAsync',
  'exportNames', 'getExportNames', 'getNamespaceNames',
  'validateBarrelIntegrity', 'integrityTest', '__barrel__'
];
for (const name of expectedExports) {
  assert.ok(utils.exportNames.includes(name), `exportNames includes ${name}`);
  assert.ok(typeof utils[name] !== 'undefined', `top-level export ${name} is defined`);
}

// 3. Default export has expected namespaces and composition
assert.ok(typeof utils.default.string === 'object', 'default string namespace');
assert.ok(typeof utils.default.fn === 'object', 'default fn namespace');
assert.ok(typeof utils.default.format === 'object', 'default format namespace');
assert.ok(typeof utils.default.composition === 'object', 'default composition namespace');
assert.ok(typeof utils.default.__barrel__ === 'object', 'default __barrel__ metadata');

// 4. Integrity & barrel validation
const integrity = utils.integrityTest();
assert.ok(integrity.passed, `integrityTest passed: ${integrity.failures.join(', ')}`);

const validation = utils.validateBarrelIntegrity();
assert.ok(validation.valid, `validateBarrelIntegrity valid: ${validation.errors.join(', ')}`);

// 5. Spot-check a few representative functions
assert.strictEqual(utils.escapeHtml('<script>'), '&lt;script&gt;', 'escapeHtml');
assert.strictEqual(utils.normalizeSlashes('C:\\Users'), 'C:/Users', 'normalizeSlashes');
assert.strictEqual(utils.isBlank(' '), true, 'isBlank whitespace');
assert.strictEqual(utils.isBlank('hi'), false, 'isBlank non-empty');
assert.strictEqual(utils.seq((x) => x + 1, (x) => x * 2)(3), 8, 'seq left-to-right');
assert.strictEqual(utils.flow((x) => x + 1, (x) => x * 2)(3), 7, 'flow right-to-left');
assert.strictEqual(utils.parseJsonSafe('{"a":1}', null).a, 1, 'parseJsonSafe');
assert.strictEqual(utils.toFixedNumber(2.5, 0), 3, 'toFixedNumber');
assert.deepStrictEqual(utils.zipObject(['a', 'b'], [1, 2]), { a: 1, b: 2 }, 'zipObject');
assert.strictEqual(await utils.delay(5, 42), 42, 'delay');
assert.strictEqual(typeof utils.throttleAsync(() => { }, 100), 'function', 'throttleAsync');
assert.strictEqual(typeof utils.hash('test'), 'number', 'hash');
assert.ok(utils.formatNumber(1000).includes('1,000'), 'formatNumber');
assert.ok(utils.formatBytes(1024).includes('KB'), 'formatBytes');
assert.strictEqual(utils.randomId(4).length, 4, 'randomId');
assert.deepStrictEqual(utils.clamp(15, 0, 10), 10, 'clamp');

// 6. composition namespace
assert.strictEqual(typeof utils.composition.escapeHtml, 'function', 'composition has escapeHtml');
assert.strictEqual(typeof utils.composition.seq, 'function', 'composition has seq');
assert.strictEqual(typeof utils.composition.deepClone, 'function', 'composition has deepClone');

// 7. notify namespace
assert.strictEqual(typeof utils.notifyVSCode, 'function', 'notifyVSCode is a function');
assert.strictEqual(typeof utils.notifyDownloadComplete, 'function', 'notifyDownloadComplete is a function');
assert.strictEqual(typeof utils.notifyAuthState, 'function', 'notifyAuthState is a function');
assert.strictEqual(typeof utils.default.notify, 'object', 'default.notify namespace exists');

// 8. Every published export name resolves to a defined value
for (const name of utils.exportNames) {
  assert.ok(typeof utils[name] !== 'undefined', `exportName ${name} resolves to a defined value`);
}

// 9. Every flat utility export is also resolvable through the composition namespace
const compositionExcluded = new Set([
  'exportNames', 'getExportNames', 'getNamespaceNames',
  'validateBarrelIntegrity', 'integrityTest', '__barrel__', 'composition'
]);
for (const name of utils.exportNames) {
  if (compositionExcluded.has(name)) continue;
  assert.ok(
    typeof utils.default.composition[name] !== 'undefined',
    `composition namespace exposes ${name}`
  );
}

// 10. waitForAsync behavior
{
  let flag = false;
  const promise = utils.waitForAsync(async () => flag, 10, 500);
  await utils.sleep(50);
  flag = true;
  await promise;
  assert.ok(true, 'waitForAsync resolves when predicate becomes true');

  await assert.rejects(
    utils.waitForAsync(async () => false, 10, 50),
    { message: 'Timeout waiting for condition' },
    'waitForAsync rejects on timeout'
  );
}

// 11. pMap behavior
{
  const items = [1, 2, 3, 4];
  const results = await utils.pMap(items, async (n) => n * 2, 2);
  assert.deepStrictEqual(results, [2, 4, 6, 8], 'pMap maps values with concurrency limit');
}

console.log('All barrel tests passed! ✓');
