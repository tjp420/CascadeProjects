import { escapeHtml } from './string.js';
import { notifyDownloadComplete } from './notify.js';
export { downloadJson, downloadBlob, downloadText, downloadCsv, normalDownload } from './download.js';
let _toastId = 0;
function _renderToast(container, message, type, duration) {
    const id = `toast-${++_toastId}`;
    const toast = document.createElement('div');
    toast.id = id;
    toast.className = `toast ${type} show`;
    toast.textContent = message == null ? '' : String(message);
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.remove('show');
        toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    }, duration);
}
export function showToast(message, type = 'info') {
    if (typeof document === 'undefined' || !document.body)
        return;
    const container = document.getElementById('toast-container') || (() => {
        const el = document.createElement('div');
        el.id = 'toast-container';
        el.style.cssText = 'position:fixed;top:1rem;right:1rem;z-index:9999;display:flex;flex-direction:column;gap:0.5rem;pointer-events:none;';
        document.body.appendChild(el);
        return el;
    })();
    _renderToast(container, message, typeof type === 'string' ? type : 'info', 3500);
}
/**
 * Manually remove the toast container and clear any active timers.
 * @returns {void}
 */
export function removeToastContainer() {
    _toastId = 0;
    if (typeof document === 'undefined')
        return;
    const container = document.getElementById('toast-container');
    if (container)
        container.remove();
}
/**
 * Trigger a browser download from a string or Blob.
 * @param {string|Blob} content
 * @param {string} filename
 * @param {string} [mimeType='text/plain']
 * @returns {void}
 */
export function downloadFile(content, filename, mimeType = 'text/plain') {
    if (typeof document === 'undefined')
        return;
    const blob = content instanceof Blob ? content : new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = String(filename || 'download');
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    notifyDownloadComplete(String(filename || 'download'));
}
/**
 * Check whether an element has a CSS class.
 * @param {HTMLElement|null} el
 * @param {string} className
 * @returns {boolean}
 */
export function hasClass(el, className) {
    if (!el || !className || typeof el.classList === 'undefined')
        return false;
    return el.classList.contains(className);
}
/**
 * Add one or more CSS classes to an element.
 * @param {HTMLElement|null} el
 * @param {string} className Space-separated class names.
 * @returns {void}
 */
export function addClass(el, className) {
    if (!el || !className || typeof el.classList === 'undefined')
        return;
    const classes = String(className).trim().split(/\s+/).filter(Boolean);
    for (const c of classes)
        el.classList.add(c);
}
/**
 * Remove one or more CSS classes from an element.
 * @param {HTMLElement|null} el
 * @param {string} className Space-separated class names.
 * @returns {void}
 */
export function removeClass(el, className) {
    if (!el || !className || typeof el.classList === 'undefined')
        return;
    const classes = String(className).trim().split(/\s+/).filter(Boolean);
    for (const c of classes)
        el.classList.remove(c);
}
/**
 * Toggle a CSS class on an element.
 * @param {HTMLElement|null} el
 * @param {string} className
 * @param {boolean} [force] If true, add; if false, remove.
 * @returns {boolean}
 */
export function toggleClass(el, className, force) {
    if (!el || !className || typeof el.classList === 'undefined')
        return false;
    if (typeof force === 'boolean') {
        el.classList.toggle(className, force);
        return force;
    }
    return el.classList.toggle(className);
}
/**
 * Return all focusable elements within a container.
 * @param {HTMLElement|null} [container=document]
 * @returns {HTMLElement[]}
 */
export function getFocusableElements(container) {
    const root = container || (typeof document !== 'undefined' ? document : null);
    if (!root)
        return [];
    const selector = 'a[href], button, input, textarea, select, details, [tabindex]:not([tabindex="-1"])';
    return Array.from(root.querySelectorAll(selector)).filter((el) => {
        if (el.hasAttribute('disabled'))
            return false;
        if (el.getAttribute('tabindex') === '-1')
            return false;
        return true;
    });
}
/**
 * Focus the first focusable element within a container.
 * @param {HTMLElement|null} [container=document]
 * @returns {boolean} True if an element was focused.
 */
export function focusFirst(container) {
    const candidates = getFocusableElements(container);
    if (candidates.length === 0)
        return false;
    try {
        candidates[0].focus();
        return document.activeElement === candidates[0];
    }
    catch (_a) {
        return false;
    }
}
/** Create a DOM element with attributes and child nodes.
 * @param {string} tag Element tag name.
 * @param {Object} [attrs={}] Attribute key-value pairs.
 * @param {(string|HTMLElement)[]} [children=[]] Child strings (text) or HTMLElement nodes.
 * @returns {HTMLElement}
 */
export function createElement(tag, attrs = {}, children = []) {
    if (typeof document === 'undefined')
        return null;
    const el = document.createElement(tag);
    for (const [key, val] of Object.entries(attrs)) {
        if (key === 'className') {
            el.className = val;
        }
        else if (key === 'style' && typeof val === 'object') {
            Object.assign(el.style, val);
        }
        else if (key.startsWith('on') && typeof val === 'function') {
            el.addEventListener(key.slice(2).toLowerCase(), val);
        }
        else {
            el.setAttribute(key, val);
        }
    }
    for (const child of children) {
        if (child == null)
            continue;
        el.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
    }
    return el;
}
/**
 * Remove all child nodes from a DOM element.
 * @param {HTMLElement} el
 * @returns {void}
 */
export function removeAllChildren(el) {
    if (!el || typeof el.removeChild !== 'function')
        return;
    while (el.firstChild) {
        el.removeChild(el.firstChild);
    }
}
/**
 * Scroll to a DOM element by CSS selector.
 * @param {string} selector CSS selector.
 * @param {string} [behavior='smooth'] Scroll behavior.
 * @returns {boolean} True if the element was found.
 */
export function scrollToElement(selector, behavior = 'smooth') {
    if (typeof document === 'undefined')
        return false;
    const el = document.querySelector(selector);
    if (el && typeof el.scrollIntoView === 'function') {
        el.scrollIntoView({ behavior, block: 'start' });
        return true;
    }
    return false;
}
/**
 * Check whether a DOM element is within the viewport.
 * @param {HTMLElement} el
 * @returns {boolean}
 */
export function elementInViewport(el) {
    if (!el || typeof el.getBoundingClientRect !== 'function')
        return false;
    const rect = el.getBoundingClientRect();
    return rect.top >= 0 && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && rect.right <= (window.innerWidth || document.documentElement.clientWidth);
}
/**
 * Observe when an element enters the viewport via IntersectionObserver.
 * @param {HTMLElement} el
 * @param {(entry: IntersectionObserverEntry) => void} callback
 * @param {IntersectionObserverInit} [options]
 * @returns {IntersectionObserver|null}
 */
export function observeIntersection(el, callback, options = {}) {
    if (typeof window === 'undefined' || !window.IntersectionObserver || !el)
        return null;
    const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
            callback(entry);
        }
    }, options);
    observer.observe(el);
    return observer;
}
/**
 * Preload an image and return a Promise that resolves when loaded.
 * @param {string} src
 * @returns {Promise<HTMLImageElement>}
 */
export function preloadImage(src) {
    return new Promise((resolve, reject) => {
        if (typeof window === 'undefined') {
            reject(new Error('Cannot preload image outside browser'));
            return;
        }
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error(`Failed to load image: ${src}`));
        img.src = src;
    });
}
export async function copyToClipboard(text) {
    if (text == null)
        throw new Error('Cannot copy null or undefined to clipboard.');
    const str = String(text);
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
        try {
            return await navigator.clipboard.writeText(str);
        }
        catch (_a) {
            // Non-secure context or permission denied — fall through to execCommand
        }
    }
    if (typeof document === 'undefined' || !document.body) {
        throw new Error('Clipboard unavailable in this environment.');
    }
    const ta = document.createElement('textarea');
    ta.value = str;
    ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try {
        const ok = document.execCommand('copy');
        if (!ok)
            throw new Error('execCommand(copy) returned false');
    }
    finally {
        ta.remove();
    }
}
/** @returns {string | {html:string, attach:(container:HTMLElement)=>void}} HTML string, or object with html + attach when actions have onClick handlers
 */
export function renderEmptyState(opts) {
    if (!opts || typeof opts !== 'object' || Array.isArray(opts))
        return '';
    const { icon, title, body = '', actions: rawActions = [], iconWrapper = 'svg' } = opts;
    const actions = Array.isArray(rawActions) ? rawActions.filter(a => a && typeof a === 'object') : [];
    const safeIcon = String(icon || '');
    const iconHtml = iconWrapper === 'emoji'
        ? `<div class="empty-state-icon" style="font-size:3rem;background:none;width:auto;height:auto;">${escapeHtml(safeIcon)}</div>`
        : `<div class="empty-state-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${safeIcon}</svg></div>`;
    const unsafeBody = opts.unsafeBody === true;
    const bodyHtml = body ? `<p class="empty-state-body">${unsafeBody ? body : escapeHtml(body)}</p>` : '';
    const actionsHtml = actions.length
        ? `<div class="empty-state-actions">${actions.map((a, idx) => `<button class="btn ${escapeHtml(a.className || 'btn-primary')}"${a.id ? ` id="${escapeHtml(a.id)}"` : ` data-action-index="${idx}"`}>${escapeHtml(a.label)}</button>`).join('')}</div>`
        : '';
    const html = `
    <div class="empty-state card">
      ${iconHtml}
      <p class="empty-state-title">${escapeHtml(title)}</p>
      ${bodyHtml}
      ${actionsHtml}
    </div>
  `.trim();
    if (actions.some(a => typeof a.onClick === 'function')) {
        return {
            html,
            attach(container) {
                actions.forEach((action, idx) => {
                    if (typeof action.onClick !== 'function')
                        return;
                    const selector = action.id ? `#${CSS.escape(action.id)}` : `[data-action-index="${idx}"]`;
                    const btn = container.querySelector(selector);
                    if (btn)
                        btn.addEventListener('click', action.onClick);
                });
            }
        };
    }
    return html;
}
