import { escapeHtml, showToast, formatPercent, formatNumber, renderEmptyState } from '../utils.js';
import { getScanFileMetrics, resolveDisplayScore } from '../services/analyzeService.js?v=20260710inventory1';
const SEVERITIES = ['all', 'high', 'medium', 'low'];
/**
 * Results view.
 */
export class ResultsView {
    constructor(app) {
        this.app = app;
        this.filterSeverity = 'all';
        this.filterCategory = 'all';
        this.selectedIssue = null;
        this._container = null;
    }
    applyRouteParams(params = {}) {
        this.filterSeverity = params.q ? 'all' : 'all';
        this.filterCategory = params.filter || 'all';
    }
    getFilteredIssues() {
        var _a, _b;
        const report = this.app.state.report;
        let source = (_a = report === null || report === void 0 ? void 0 : report.rawIssues) !== null && _a !== void 0 ? _a : report === null || report === void 0 ? void 0 : report.detectedIssues;
        // Defensive fallback for legacy or sandbox reports that don't expose rawIssues/detectedIssues directly.
        if (!Array.isArray(source) || !source.length) {
            if (report && typeof report === 'object') {
                if (Array.isArray(report.issues))
                    source = report.issues;
                else if (Array.isArray(report.findings))
                    source = report.findings;
                else if (report.categories && typeof report.categories === 'object') {
                    const all = [];
                    for (const [category, data] of Object.entries(report.categories)) {
                        if (data && Array.isArray(data.findings)) {
                            for (const finding of data.findings) {
                                all.push({
                                    type: category,
                                    filePath: finding.file || finding.filePath || '',
                                    line: finding.line || 0,
                                    severity: String(finding.severity || data.severity || 'medium').toLowerCase(),
                                    description: finding.message || finding.description || ''
                                });
                            }
                        }
                    }
                    source = all;
                }
            }
        }
        if (!(source === null || source === void 0 ? void 0 : source.length))
            return [];
        let issues = source.map((issue, index) => {
            var _a, _b, _c, _d, _e;
            return ({
                ...issue,
                id: issue.id || `${issue.severity}|${issue.type}|${issue.description}|${index}`,
                filePaths: issue.filePaths || ((_a = issue.metadata) === null || _a === void 0 ? void 0 : _a.duplicatePaths) || (issue.filePath ? [issue.filePath] : []),
                filePath: issue.filePath || ((_b = issue.filePaths) === null || _b === void 0 ? void 0 : _b[0]) || ((_d = (_c = issue.metadata) === null || _c === void 0 ? void 0 : _c.duplicatePaths) === null || _d === void 0 ? void 0 : _d[0]) || ((_e = issue.affectedFiles) === null || _e === void 0 ? void 0 : _e[0])
            });
        });
        const query = (_b = this.app.state.routeParams) === null || _b === void 0 ? void 0 : _b.q;
        if (query) {
            const q = query.toLowerCase();
            issues = issues.filter((i) => {
                var _a, _b, _c;
                return ((_a = i.type) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes(q)) ||
                    ((_b = i.description) === null || _b === void 0 ? void 0 : _b.toLowerCase().includes(q)) ||
                    ((_c = i.filePath) === null || _c === void 0 ? void 0 : _c.toLowerCase().includes(q));
            });
        }
        if (this.filterSeverity !== 'all') {
            issues = issues.filter((i) => i.severity === this.filterSeverity);
        }
        if (this.filterCategory !== 'all') {
            const cats = this.app.scanService.getIssueCategories(report);
            const cat = cats.find((c) => c.id === this.filterCategory);
            if (cat === null || cat === void 0 ? void 0 : cat.filter) {
                issues = issues.filter(cat.filter);
            }
        }
        issues = issues.filter((i) => !String(i.filePath || '').includes('node_modules'));
        return issues;
    }
    renderScanSummary(report) {
        var _a, _b, _c, _d, _e;
        if (!report)
            return '';
        const metrics = getScanFileMetrics(report);
        const gateLabel = ((_a = report.gate) === null || _a === void 0 ? void 0 : _a.pass) ? 'PASS' : report.gate ? 'REVIEW' : '—';
        const gateClass = ((_b = report.gate) === null || _b === void 0 ? void 0 : _b.pass) ? 'pass' : 'warn';
        return `
      <div class="metrics-row mb-4">
        <div class="metric-chip gate-badge ${gateClass}">${gateLabel}</div>
        <div class="metric-chip"><strong>${formatPercent(resolveDisplayScore(report))}</strong> consistency</div>
        <div class="metric-chip"><strong>${formatNumber((_c = metrics.mockSampleFiles) !== null && _c !== void 0 ? _c : report.totalFiles)}</strong> mock/sample</div>
        ${metrics.repositoryFiles != null ? `<div class="metric-chip"><strong>${formatNumber(metrics.repositoryFiles)}</strong> repo files</div>` : ''}
        <div class="metric-chip"><strong>${formatNumber((_d = metrics.ruleScopedFilesAnalyzed) !== null && _d !== void 0 ? _d : metrics.credentialScanned)}</strong> gate rules checked</div>
        <div class="metric-chip"><strong>${formatPercent(report.schemaCompliance)}</strong> schema</div>
        <div class="metric-chip"><strong>${(_e = report.issueCount) !== null && _e !== void 0 ? _e : 0}</strong> issue groups</div>
      </div>
    `;
    }
    render() {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const report = this.app.state.report;
        const issues = this.getFilteredIssues();
        const categories = this.app.scanService.getIssueCategories(report);
        const totalIssues = ((_b = (_a = report === null || report === void 0 ? void 0 : report.rawIssues) !== null && _a !== void 0 ? _a : report === null || report === void 0 ? void 0 : report.detectedIssues) !== null && _b !== void 0 ? _b : []).reduce((sum, i) => sum + (i.count || 1), 0);
        const activeCategory = categories.find((c) => c.id === this.filterCategory);
        const filtersActive = this.filterSeverity !== 'all'
            || this.filterCategory !== 'all'
            || Boolean((_c = this.app.state.routeParams) === null || _c === void 0 ? void 0 : _c.q);
        const fromAudit = ((_d = this.app.state.routeParams) === null || _d === void 0 ? void 0 : _d.from) === 'audit';
        const el = document.createElement('div');
        el.className = 'fade-in';
        el.innerHTML = `
      <div class="section-heading mb-4">
        <h1 class="page-title" style="margin:0">Results</h1>
        ${this.app.isCurrentUserAdmin() ? '<button class="btn btn-primary btn-sm" id="send-ai-btn" type="button" title="Send scan data to AI coding agent">🤖 Send to AI Agent</button>' : ''}
      </div>
      ${this.app.isCurrentUserAdmin() ? `
      <div id="ai-send-panel" class="card mb-4" style="display:none;padding:var(--space-3);background:rgba(99,102,241,0.06);border-color:rgba(99,102,241,0.2);">
        <p style="font-size:0.8rem;color:var(--text-muted);margin:0 0 8px;">Add notes for the AI agent (optional):</p>
        <textarea id="ai-notes-input" rows="2" style="width:100%;border:1px solid var(--border);border-radius:8px;padding:8px;background:var(--bg);color:var(--text);font-family:var(--font-mono);font-size:0.8rem;resize:vertical;" placeholder="e.g., 'Focus on critical credential leaks first, ignore test files...'"></textarea>
        <div class="flex gap-2 mt-2">
          <button class="btn btn-primary btn-sm" id="ai-send-confirm" type="button">Confirm Send</button>
          <button class="btn btn-ghost btn-sm" id="ai-send-cancel" type="button">Cancel</button>
        </div>
        <div id="ai-send-status" style="margin-top:8px;font-size:0.8rem;display:none;"></div>
      </div>` : ''}
      ${fromAudit && report ? `
        <div class="card mb-4" style="padding:var(--space-4)">
          <p style="margin:0">
            Opened from Compliance Audit.
            ${totalIssues === 0 && ((_e = report.gate) === null || _e === void 0 ? void 0 : _e.pass)
            ? 'The gate passed with <strong>0 blocking issues</strong> — that is a successful result. Browse sample files below or return to <a href="/dashboard/audit">Compliance Audit</a> for layer breakdown.'
            : `Showing ${totalIssues} issue group(s) from the latest scan.`}
          </p>
        </div>
      ` : ''}
      ${report ? this.renderScanSummary(report) : ''}
      ${((_f = this.app.state.routeParams) === null || _f === void 0 ? void 0 : _f.q) ? `<p class="text-muted mb-4">Search: “${escapeHtml(this.app.state.routeParams.q)}”</p>` : ''}

      <div class="results-layout" style="display:grid;grid-template-columns:260px 1fr;gap:var(--space-4);align-items:start;">
        <aside class="results-sidebar" style="position:sticky;top:var(--space-4);">
          <div class="card mb-4" style="padding:var(--space-3);">
            <h3 class="text-sm font-semibold mb-3" style="margin:0 0 12px;">Severity</h3>
            <div class="flex flex-col gap-2" id="severity-filters">
              ${SEVERITIES.map((s) => `
                <button type="button" class="filter-chip justify-start ${this.filterSeverity === s ? 'active' : ''}" data-severity="${s}">
                  ${s === 'all' ? 'All severities' : s.charAt(0).toUpperCase() + s.slice(1)}
                </button>
              `).join('')}
            </div>
          </div>
          <div class="card mb-4" style="padding:var(--space-3);">
            <h3 class="text-sm font-semibold mb-3" style="margin:0 0 12px;">Issue Type</h3>
            <div class="flex flex-col gap-2" id="category-filters">
              <button type="button" class="filter-chip justify-start ${this.filterCategory === 'all' ? 'active' : ''}" data-category="all">All types</button>
              ${categories.map((c) => `
                <button type="button" class="filter-chip justify-start ${this.filterCategory === c.id ? 'active' : ''}" data-category="${c.id}">
                  ${c.icon} ${escapeHtml(c.title)} (${c.count})
                </button>
              `).join('')}
            </div>
          </div>
          <div class="card" style="padding:var(--space-3);">
            <h3 class="text-sm font-semibold mb-3" style="margin:0 0 12px;">Actions</h3>
            <div class="flex flex-col gap-2">
              <button class="btn btn-secondary btn-sm w-full" id="export-full-btn" type="button">Export full report</button>
              <button class="btn btn-secondary btn-sm w-full" id="export-filtered-json-btn" type="button">Export filtered JSON</button>
              <button class="btn btn-secondary btn-sm w-full" id="export-csv-btn" type="button">Export CSV</button>
              ${filtersActive ? '<button type="button" class="btn btn-ghost btn-sm w-full" id="clear-results-filters">Clear filters</button>' : ''}
            </div>
          </div>
        </aside>

        <div class="results-main">
          ${!report ? `
            ${renderEmptyState({
                icon: '📋',
                title: 'No scan report loaded yet',
                body: 'Run a Simplebeacon or Complete scan from Analyze, or use Dashboard → Run scan.',
                iconWrapper: 'emoji'
            })}
          ` : issues.length === 0 ? `
            ${renderEmptyState({
                icon: totalIssues === 0 && ((_g = report.gate) === null || _g === void 0 ? void 0 : _g.pass) && !filtersActive ? '✅' : '🔍',
                title: this.emptyStateMessage(report, totalIssues, filtersActive, activeCategory),
                iconWrapper: 'emoji'
            })}
          ` : `
            <div class="card" style="padding: 0; overflow: hidden;">
              <table class="results-table">
                <thead>
                  <tr>
                    <th>Severity</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>File</th>
                    <th>Count</th>
                  </tr>
                </thead>
                <tbody id="results-body"></tbody>
              </table>
            </div>
            <div id="issue-detail"></div>
          `}
          ${this.renderSampleFiles()}
        </div>
      </div>
    `;
        this.bindFilters(el);
        this.bindExport(el, issues);
        (_h = el.querySelector('#clear-results-filters')) === null || _h === void 0 ? void 0 : _h.addEventListener('click', () => {
            this.filterSeverity = 'all';
            this.filterCategory = 'all';
            this.app.state.routeParams = {};
            this.app.router.navigate('results');
        });
        const tbody = el.querySelector('#results-body');
        if (tbody) {
            issues.forEach((issue) => {
                var _a;
                const tr = document.createElement('tr');
                tr.dataset.issueId = issue.id;
                tr.innerHTML = `
          <td><span class="severity-pill ${issue.severity}">${issue.severity}</span></td>
          <td>${escapeHtml(issue.type)}</td>
          <td>${escapeHtml(issue.description)}</td>
          <td><code>${escapeHtml(this.app.scanService.basename(issue.filePath))}</code></td>
          <td>${(_a = issue.count) !== null && _a !== void 0 ? _a : 1}</td>
        `;
                tr.addEventListener('click', () => this.showDetail(el, issue));
                tbody.appendChild(tr);
            });
        }
        return el;
    }
    emptyStateMessage(report, totalIssues, filtersActive, activeCategory) {
        var _a;
        if (filtersActive && activeCategory) {
            return `No ${activeCategory.title.toLowerCase()} issues match the current filters.`;
        }
        if (filtersActive) {
            return 'No issues match the current filters.';
        }
        if (totalIssues === 0 && ((_a = report.gate) === null || _a === void 0 ? void 0 : _a.pass)) {
            return 'Simplebeacon gate passed — no blocking issues in the latest scan. This is expected when paths are clean. Scroll down for the sample file inventory, or open Compliance Audit for per-layer metrics.';
        }
        return 'No issues in the loaded report.';
    }
    bindExport(el, issues) {
        var _a, _b, _c, _d, _e, _f, _g;
        const svc = this.app.scanService;
        const meta = {
            severity: this.filterSeverity,
            category: this.filterCategory,
            query: ((_a = this.app.state.routeParams) === null || _a === void 0 ? void 0 : _a.q) || null
        };
        (_b = el.querySelector('#export-full-btn')) === null || _b === void 0 ? void 0 : _b.addEventListener('click', async () => {
            try {
                await svc.exportReport(this.app.state.report);
                showToast('Full report downloaded', 'success');
            }
            catch (err) {
                showToast(err.message, 'error');
            }
        });
        (_c = el.querySelector('#export-filtered-json-btn')) === null || _c === void 0 ? void 0 : _c.addEventListener('click', () => {
            if (!issues.length) {
                showToast('No issues match current filters', 'info');
                return;
            }
            svc.exportFilteredIssues(issues, meta);
            showToast(`Exported ${issues.length} issue(s) as JSON`, 'success');
        });
        (_d = el.querySelector('#export-csv-btn')) === null || _d === void 0 ? void 0 : _d.addEventListener('click', () => {
            if (!issues.length) {
                showToast('No issues match current filters', 'info');
                return;
            }
            svc.exportIssuesCsv(issues);
            showToast(`Exported ${issues.length} issue(s) as CSV`, 'success');
        });
        // Send to AI Agent handlers
        const aiPanel = el.querySelector('#ai-send-panel');
        const aiNotesInput = el.querySelector('#ai-notes-input');
        const aiSendStatus = el.querySelector('#ai-send-status');
        const doSendToAi = async (notes = '') => {
            var _a, _b, _c, _d, _e;
            const report = this.app.state.report;
            if (!report) {
                showToast('No report loaded — run a scan first', 'error');
                return;
            }
            const allIssues = report.rawIssues || report.detectedIssues || [];
            const reportSummary = {
                gatePass: (_b = (_a = report.gate) === null || _a === void 0 ? void 0 : _a.pass) !== null && _b !== void 0 ? _b : 'N/A',
                qualityScore: (_c = report.qualityScore) !== null && _c !== void 0 ? _c : 'N/A',
                totalIssues: allIssues.length,
                filesScanned: (_e = (_d = report.repositoryFilesTotal) !== null && _d !== void 0 ? _d : report.totalFiles) !== null && _e !== void 0 ? _e : 'N/A',
                reportType: report.type || 'simplebeacon'
            };
            // If running inside a VS Code-family webview, message the extension directly
            const hasVsCodeApi = typeof window !== 'undefined' && typeof window.acquireVsCodeApi === 'function';
            if (hasVsCodeApi) {
                try {
                    const vscode = window.acquireVsCodeApi();
                    vscode.postMessage({
                        command: 'sendToAI',
                        data: {
                            projectPath: report.projectRoot || report.projectPath || window.location.origin,
                            notes,
                            reportSummary,
                            issues: allIssues
                        }
                    });
                    showToast('Scan data sent to your AI coding agent. Check the editor chat panel.', 'success');
                    return;
                }
                catch (err) {
                    console.warn('[AI-Send] vscode.postMessage failed:', err);
                }
            }
            try {
                const res = await fetch('/api/ai-context', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        projectPath: report.projectRoot || report.projectPath || window.location.origin,
                        notes,
                        reportSummary,
                        issues: allIssues
                    })
                });
                const json = await res.json();
                if (json.success) {
                    if (json.content) {
                        try {
                            await navigator.clipboard.writeText(json.content);
                            showToast('Copied to clipboard — paste into your AI coding agent with Ctrl+V', 'success');
                        }
                        catch (clipErr) {
                            showToast('AI context saved. Use sidebar 🤖 button or mention @.simplebeacon/ai-context.md', 'success');
                        }
                    }
                    else {
                        showToast('AI context saved. Mention @.simplebeacon/ai-context.md in chat.', 'success');
                    }
                }
                else {
                    showToast('Failed: ' + (json.error || 'Unknown'), 'error');
                }
            }
            catch (err) {
                showToast('Network error: ' + err.message, 'error');
            }
        };
        (_e = el.querySelector('#send-ai-btn')) === null || _e === void 0 ? void 0 : _e.addEventListener('click', () => {
            doSendToAi('');
        });
        (_f = el.querySelector('#ai-send-cancel')) === null || _f === void 0 ? void 0 : _f.addEventListener('click', () => {
            if (aiPanel)
                aiPanel.style.display = 'none';
            if (aiNotesInput)
                aiNotesInput.value = '';
            if (aiSendStatus) {
                aiSendStatus.style.display = 'none';
                aiSendStatus.textContent = '';
            }
        });
        (_g = el.querySelector('#ai-send-confirm')) === null || _g === void 0 ? void 0 : _g.addEventListener('click', async () => {
            const btn = el.querySelector('#ai-send-confirm');
            btn.disabled = true;
            btn.textContent = 'Sending…';
            await doSendToAi((aiNotesInput === null || aiNotesInput === void 0 ? void 0 : aiNotesInput.value) || '');
            btn.disabled = false;
            btn.textContent = 'Confirm Send';
        });
    }
    bindFilters(el) {
        el.querySelectorAll('#severity-filters .filter-chip').forEach((btn) => {
            btn.addEventListener('click', () => {
                this.filterSeverity = btn.dataset.severity;
                this.paint();
            });
        });
        el.querySelectorAll('#category-filters .filter-chip').forEach((btn) => {
            btn.addEventListener('click', () => {
                this.filterCategory = btn.dataset.category;
                this.paint();
            });
        });
    }
    renderSampleFiles() {
        var _a, _b;
        const report = this.app.state.report;
        const files = (report === null || report === void 0 ? void 0 : report.sampleFiles) || [];
        if (!files.length)
            return '';
        const total = (_b = (_a = report.mockSampleFiles) !== null && _a !== void 0 ? _a : report.totalFiles) !== null && _b !== void 0 ? _b : files.length;
        const shown = files.slice(0, 24);
        const more = Math.max(0, files.length - shown.length);
        const extra = Math.max(0, (total || files.length) - files.length);
        return `
      <div class="section-block mt-6">
        <div class="section-heading"><h2>Sample Files (${total || files.length})</h2></div>
        <div class="sample-file-grid">
          ${shown.map((f) => `<code class="sample-file-chip">${escapeHtml(f)}</code>`).join('')}
          ${more > 0 ? `<span class="text-muted">+${more} more in report</span>` : ''}
          ${extra > 0 ? `<span class="text-muted">+${extra} not listed — re-run scan</span>` : ''}
        </div>
      </div>
    `;
    }
    showDetail(container, issue) {
        var _a, _b, _c;
        const slot = container.querySelector('#issue-detail');
        if (!slot)
            return;
        slot.innerHTML = `
      <div class="detail-panel">
        <h3>${escapeHtml(issue.type)}</h3>
        <p>${escapeHtml(issue.description)}</p>
        <p><strong>Recommended:</strong> ${escapeHtml(issue.recommendedAction || 'Review and fix manually')}</p>
        <p><strong>File:</strong> <code>${escapeHtml(issue.filePath)}</code></p>
        ${((_a = issue.affectedFiles) === null || _a === void 0 ? void 0 : _a.length) ? `<p><strong>Affected:</strong> ${issue.affectedFiles.map(escapeHtml).join(', ')}</p>` : ''}
        ${((_c = (_b = issue.metadata) === null || _b === void 0 ? void 0 : _b.duplicatePaths) === null || _c === void 0 ? void 0 : _c.length) ? `
          <p><strong>Duplicate paths:</strong></p>
          <ul class="settings-path-list">
            ${issue.metadata.duplicatePaths.map((p) => `<li><code>${escapeHtml(p)}</code></li>`).join('')}
          </ul>
        ` : ''}
      </div>
    `;
        slot.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    paint(container = this._container) {
        if (!container)
            return;
        this._container = container;
        container.innerHTML = '';
        container.appendChild(this.render());
    }
    mount(container) {
        this._container = container;
        this.applyRouteParams(this.app.state.routeParams || {});
        this.paint(container);
    }
}
