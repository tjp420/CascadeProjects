/**
 * Browser mirror of fiction-digest-export-sanitize.js — keep in sync.
 */

import { redactProjectPathForExport } from './quality-export.browser.js?v=20260531qualityexport8';

/**
 * Project label from path.
 * @param {string} projectPath
 * @returns {any}
 */
function projectLabelFromPath(projectPath) {
  const normalized = String(projectPath || 'ai-platform').replace(/\\/g, '/');
  const parts = normalized.split('/').filter(Boolean);
  return parts[parts.length - 1] || 'ai-platform';
}

const SCANNER_IMPL_PATH_RE = /(?:^|\/)packages\/simplebeacon-cli\/src\/(?:rules|reporters|analyzers|lib|proxy|mcp)(?:\/|$)|(?:^|\/)src\/(?:rules|reporters|analyzers|lib|proxy|mcp)(?:\/|$)/;
const OSS_SCANNER_ROOT_FILES = new Set(['src/scan.js', 'src/config.js', 'src/project-detect.js', 'src/index.js']);

const SUPPRESSED_PRODUCTION_LEAK_INTENTS = new Set([
  'scanner-meta',
  'repository-audit-loader',
  'repository-audit-stub-loader',
  'config-metadata',
  'demo-tool-sample'
]);

/**
 * Normalize rel.
 * @param {string} filePath
 * @returns {any}
 */
function normalizeRel(filePath) {
  return String(filePath || '').replace(/\\/g, '/');
}

/**
 * Is scanner implementation path.
 * @param {string} relativePath
 * @returns {any}
 */
function isScannerImplementationPath(relativePath) {
  const rel = normalizeRel(relativePath);
  if (SCANNER_IMPL_PATH_RE.test(rel.toLowerCase())) return true;
  if (OSS_SCANNER_ROOT_FILES.has(rel)) return true;
  return false;
}

/**
 * Is benchmark path.
 * @param {string} filePath
 * @returns {any}
 */
function isBenchmarkPath(filePath) {
  const rel = normalizeRel(filePath).toLowerCase();
  return rel.includes('/github-cache/') || rel.startsWith('github-cache/')
    || rel.includes('/java-ai-vulnerable/') || rel.startsWith('java-ai-vulnerable/');
}

/**
 * Resolve product platform root.
 * @param {string} projectPath
 * @returns {any}
 */
function resolveProductPlatformRoot(projectPath) {
  const normalized = String(projectPath || '').replace(/\\/g, '/');
  const idx = normalized.toLowerCase().indexOf('/github-cache/');
  if (idx <= 0) return null;
  return normalized.slice(0, idx);
}

/**
 * Resolve digest project path.
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function resolveDigestProjectPath(digest, options = {}) {
  return String(
    options.projectPath
    || digest.projectPath
    || digest.sourceProjectPath
    || digest.sourceReport?.projectRoot
    || ''
  ).replace(/\\/g, '/');
}

/**
 * Is benchmark fiction digest.
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function isBenchmarkFictionDigest(digest, options = {}) {
  if (options.benchmarkScan != null) return Boolean(options.benchmarkScan);
  return isBenchmarkPath(resolveDigestProjectPath(digest, options));
}

/**
 * Is benchmark clone noise issue.
 * @param {boolean} issue
 * @returns {any}
 */
function isBenchmarkCloneNoiseIssue(issue) {
  if (!issue) return false;
  const pattern = String(issue.pattern || issue.metadata?.patternId || '');
  const category = String(issue.category || issue.metadata?.category || '');
  const type = String(issue.type || '');
  if (/SB-HANDOFF/i.test(pattern) || category === 'handoff-integrity') return true;
  if (/EUAI-/i.test(pattern) || /EU AI Act/i.test(type)) return true;
  return false;
}

/**
 * Is benchmark scanner meta issue.
 * @param {boolean} issue
 * @returns {any}
 */
function isBenchmarkScannerMetaIssue(issue) {
  if (!issue) return false;
  const intent = String(issue.metadata?.intent || issue.intent || '');
  if (intent && SUPPRESSED_PRODUCTION_LEAK_INTENTS.has(intent)) return true;
  if (!/production leak/i.test(String(issue.type || ''))) return false;
  const filePath = issue.filePath || issue.file || '';
  return filePath ? isScannerImplementationPath(filePath) : false;
}

/**
 * Is benchmark digest excluded issue.
 * @param {boolean} issue
 * @param {any} benchmarkScan
 * @returns {any}
 */
function isBenchmarkDigestExcludedIssue(issue, benchmarkScan) {
  if (!benchmarkScan || !issue) return false;
  if (isBenchmarkCloneNoiseIssue(issue)) return true;
  return isBenchmarkScannerMetaIssue(issue);
}

/**
 * Filter digest issues.
 * @param {Array} issues
 * @param {any} benchmarkScan
 * @returns {any}
 */
function filterDigestIssues(issues = [], benchmarkScan) {
  return issues.filter((issue) => {
    const filePath = issue.filePath || issue.file || '';
    if (filePath && isBenchmarkPath(filePath)) return false;
    if (isBenchmarkDigestExcludedIssue(issue, benchmarkScan)) return false;
    return true;
  });
}

/**
 * Build benchmark fiction conclusion.
 * @param {Array} fictionIssues
 * @param {Array} nonFictionIssues
 * @param {number} sourceReport
 * @returns {any}
 */
function buildBenchmarkFictionConclusion(fictionIssues, nonFictionIssues, sourceReport) {
  const repoFiles = sourceReport?.repositoryFilesTotal ?? sourceReport?.scanScope?.repositoryFilesTotal;
  const ruleScoped = sourceReport?.ruleScopedFilesAnalyzed ?? sourceReport?.scanScope?.ruleScopedFilesAnalyzed ?? 0;
  const jsonFiction = sourceReport?.fictionJsonFilesScanned ?? sourceReport?.scanScope?.fictionJsonFilesScanned;
  const fictionN = fictionIssues.reduce((sum, issue) => sum + (issue.count || 1), 0);
  const parts = [
    'OSS benchmark clone under github-cache/ — not Simplebeacon product handoff',
    fictionN
      // simplebeacon:production-leak-intent - legitimate sample path reference for fiction digest reporting
      ? `${fictionN} fiction/KPI pattern(s) in clone JSON — not product *-sample.json`
      : 'No Simplebeacon fiction KPI hits in product sample paths',
    nonFictionIssues.length
      ? `${nonFictionIssues.length} clone-local pattern hit(s) remain — informational only`
      : 'No actionable fiction-digest findings on this clone',
    repoFiles != null ? `Repository inventory: ${Number(repoFiles).toLocaleString()} files` : null,
    `Product gate paths checked ${Number(ruleScoped).toLocaleString()} files`,
    jsonFiction != null ? `Fiction rules scanned ${Number(jsonFiction).toLocaleString()} JSON file(s) in clone` : null,
    'Agency-handoff and EU AI Act blog matches are excluded from vendor gate scoring',
    'Re-run Complete scan on ai-platform root for handoff evidence'
  ].filter(Boolean);
  return `${parts.join('. ')}.`;
}

/**
 * Is stale full tree scan.
 * @param {number} report
 * @returns {any}
 */
function isStaleFullTreeScan(report) {
  if (report.fullDirectoryScan || report.scanScope?.fullDirectoryScan) {
    return false;
  }
  const mock = report.mockSampleFiles ?? report.totalFiles ?? 0;
  const repoFiles = report.repositoryFilesTotal ?? 0;
/**
 * Paths.
 * @param {number} report.scanPaths || []
 * @returns {any}
 */
  const paths = (report.scanPaths || []).map((p) => String(p).replace(/\\/g, '/').toLowerCase());
  const platformKey = String(report.projectRoot || '').replace(/\\/g, '/').toLowerCase();
  const scanIsPlatformRootOnly = paths.length === 1 && paths[0] === platformKey;
  return mock > 500 || scanIsPlatformRootOnly || repoFiles > 15000;
}

/**
 * Normalize digest project paths.
 * @param {string} projectPath
 * @param {any} projectLabel
 * @returns {any}
 */
function normalizeDigestProjectPaths(projectPath, projectLabel) {
  const normalized = String(projectPath || '').replace(/\\/g, '/');
  if (!normalized) return undefined;
  const label = projectLabel || projectLabelFromPath(normalized);
  return redactProjectPathForExport(normalized, label);
}

/**
 * Reconcile product digest scan scope.
 * @param {any} scanScope
 * @param {number} report
 * @returns {any}
 */
function reconcileProductDigestScanScope(scanScope = {}, report = {}) {
  const fullTree = Boolean(report.fullDirectoryScan || scanScope.fullDirectoryScan);
  if (!fullTree) return scanScope;

  const mockInPaths = scanScope.mockSampleFilesInScanPaths ?? 0;
  const ruleScoped = report.ruleScopedFilesAnalyzed ?? scanScope.ruleScopedFilesAnalyzed ?? 0;
  const mockSampleFiles = report.mockSampleFiles ?? report.totalFiles ?? null;
  const fictionSamples = report.fictionSampleFilesScanned ?? scanScope.fictionSampleFilesScanned ?? null;

  let reconciled = mockInPaths;
  if (mockSampleFiles != null && mockSampleFiles < mockInPaths) {
    reconciled = mockSampleFiles;
  } else if (mockInPaths >= ruleScoped && ruleScoped > 0 && fictionSamples != null && fictionSamples < mockInPaths) {
    reconciled = fictionSamples;
  } else if (mockInPaths >= ruleScoped && ruleScoped > 0) {
    const jsonFiction = report.fictionJsonFilesScanned ?? scanScope.fictionJsonFilesScanned ?? null;
    if (jsonFiction != null && jsonFiction < mockInPaths) {
      reconciled = jsonFiction;
    }
  }

  if (reconciled === mockInPaths) return scanScope;

  return {
    ...scanScope,
    mockSampleFilesInScanPaths: reconciled,
    mockSampleFilesReconciledNote:
      `mockSampleFilesInScanPaths reconciled from ${Number(mockInPaths).toLocaleString()} to ${Number(reconciled).toLocaleString()} — full-directory scan counts repo-wide paths, not mock/sample JSON only.`
  };
}

/**
 * Infer digest scan target from hints.
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function inferDigestScanTargetFromHints(digest, options = {}) {
  const filename = String(options.exportFilename || options.filename || '').toLowerCase();
  if (!filename.includes('github-cache')) return '';
  const slugMatch = filename.match(/github-cache[-_]([a-z0-9._-]+?)(?:-\d{4}-\d{2}-\d{2}|\(\d+\)|\.json)/i);
  if (!slugMatch) return '';
  const cloneName = slugMatch[1];
  const sourceRoot = resolveDigestProjectPath(digest, options);
  if (isBenchmarkPath(sourceRoot)) return '';
  const platformRoot = resolveProductPlatformRoot(sourceRoot) || sourceRoot;
  return `${platformRoot.replace(/\/$/, '')}/github-cache/${cloneName}`;
}

/**
 * Dedupe fiction digest export notes.
 * @param {Array} notes
 * @returns {any}
 */
function dedupeFictionDigestExportNotes(notes = []) {
  const seen = new Set();
  const out = [];
  for (const note of notes) {
    const normalized = String(note).replace(/\s+/g, ' ').trim().toLowerCase();
    const scopeKey = /agency-handoff and eu ai act blog matches/i.test(normalized)
      ? 'benchmark-handoff-note'
      : /production-leak hits in simplebeacon scanner source/i.test(normalized)
        ? 'benchmark-scanner-meta-note'
        : /gate pass on clone does not imply/i.test(normalized)
          ? 'benchmark-gate-handoff-note'
          : /llm slop file count reconciled/i.test(normalized)
            ? 'benchmark-llm-reconcile-note'
            : normalized;
    if (seen.has(scopeKey)) continue;
    seen.add(scopeKey);
    out.push(String(note));
  }
  return out.slice(0, 6);
}

/**
 * Build benchmark fiction export notes.
 * @param {Array} existingNotes
 * @param {Array} extras
 * @returns {any}
 */
function buildBenchmarkFictionExportNotes(existingNotes = [], extras = []) {
  const canonical = [
    'Agency-handoff and EU AI Act blog matches removed from fiction digest for github-cache/ benchmark target.',
    'Production-leak hits in Simplebeacon scanner source (src/) excluded on OSS self-scan benchmark clone.',
    'Gate pass on clone does not imply Simplebeacon product handoff readiness.'
  ];
  const filtered = dedupeFictionDigestExportNotes(existingNotes).filter((note) => {
    const text = String(note).toLowerCase();
    return !/agency-handoff and eu ai act blog matches/i.test(text)
      && !/production-leak hits in simplebeacon scanner source/i.test(text)
      && !/gate pass on clone does not imply/i.test(text);
  });
  return dedupeFictionDigestExportNotes([...filtered, ...extras, ...canonical]);
}

/**
 * Reconcile benchmark digest scan metrics.
 * @param {number} report
 * @returns {any}
 */
function reconcileBenchmarkDigestScanMetrics(report) {
  const repoTotal = report.repositoryFilesTotal ?? report.repositoryInventory?.totalFiles ?? null;
  const ruleScoped = report.ruleScopedFilesAnalyzed ?? report.scanScope?.ruleScopedFilesAnalyzed ?? null;
  const cap = repoTotal ?? ruleScoped;
  const rawLlm = report.llmSlopScanRaw
    ?? report.scanScope?.llmSlopScanRaw
    ?? report.llmSlopFilesScanned
    ?? report.scanScope?.llmSlopFilesScanned
    ?? 0;
  if (cap == null || rawLlm <= cap) return report;
  const scanScope = {
    ...(report.scanScope || {}),
    llmSlopFilesScanned: cap,
    llmSlopScanRaw: rawLlm,
    llmSlopScanReconciled: true
  };
  return {
    ...report,
    llmSlopFilesScanned: cap,
    llmSlopScanRaw: rawLlm,
    llmSlopScanReconciled: true,
    scanScope
  };
}

/**
 * Sanitize benchmark digest scan scope.
 * @param {any} scanScope
 * @param {number} report
 * @returns {any}
 */
function sanitizeBenchmarkDigestScanScope(scanScope, report) {
  if (!scanScope) return scanScope;
  const repoTotal = report.repositoryFilesTotal ?? report.repositoryInventory?.totalFiles ?? null;
  const scanned = scanScope.llmSlopFilesScanned ?? report.llmSlopFilesScanned ?? repoTotal;
  const rawLlm = scanScope.llmSlopScanRaw ?? report.llmSlopScanRaw;
  const reconciled = scanScope.llmSlopScanReconciled ?? report.llmSlopScanReconciled;
  if (!reconciled || rawLlm == null || scanned == null || rawLlm <= scanned) return scanScope;
  const next = { ...scanScope };
  delete next.llmSlopScanRaw;
  next.llmSlopReconciliationNote = `LLM slop scan reconciled from ${rawLlm} to ${scanned} files to match clone inventory.`;
  return next;
}

/**
 * Resolve benchmark digest gate attestation.
 * @param {number} sourceReport
 * @returns {any}
 */
function resolveBenchmarkDigestGateAttestation(sourceReport) {
  if (!sourceReport) return 'benchmark-clone';
  if (sourceReport.gateAttestation === 'benchmark-clone') return 'benchmark-clone';
  const ruleScoped = sourceReport.ruleScopedFilesAnalyzed ?? sourceReport.scanScope?.ruleScopedFilesAnalyzed ?? 0;
  if (sourceReport.gate?.pass && ruleScoped > 0) return 'benchmark-clone';
  if (sourceReport.gate?.pass && ruleScoped === 0) return 'limited-benchmark';
  return 'benchmark-clone';
}

/**
 * Build benchmark fiction scope summary.
 * @param {number} sourceReport
 * @returns {any}
 */
function buildBenchmarkFictionScopeSummary(sourceReport) {
  const scope = sourceReport?.scanScope || {};
  const repoTotal = sourceReport?.repositoryFilesTotal ?? scope.repositoryFilesTotal ?? null;
  const llmScanned = scope.llmSlopFilesScanned ?? sourceReport?.llmSlopFilesScanned ?? repoTotal;
  const rawLlm = scope.llmSlopScanRaw ?? sourceReport?.llmSlopScanRaw;
  const reconciled = scope.llmSlopScanReconciled ?? sourceReport?.llmSlopScanReconciled;
  return {
    benchmarkScannerMetaExcluded: scope.benchmarkScannerMetaExcluded ?? 0,
    benchmarkCloneNoiseExcluded: scope.benchmarkCloneNoiseExcluded ?? 0,
    fictionJsonFilesScanned: sourceReport?.fictionJsonFilesScanned ?? scope.fictionJsonFilesScanned ?? null,
    ruleScopedFilesAnalyzed: sourceReport?.ruleScopedFilesAnalyzed ?? scope.ruleScopedFilesAnalyzed ?? 0,
    repositoryFilesTotal: repoTotal,
    llmSlopFilesScanned: llmScanned,
    ...(reconciled && rawLlm != null && llmScanned != null && rawLlm > llmScanned
      ? { llmSlopScanReconciledFrom: rawLlm }
      : {})
  };
}

/**
 * Resolve product fiction digest gate attestation.
 * @param {number} sourceReport
 * @returns {any}
 */
function resolveProductFictionDigestGateAttestation(sourceReport) {
  if (!sourceReport) return 'limited-scope';
  const ruleScoped = sourceReport.ruleScopedFilesAnalyzed ?? sourceReport.scanScope?.ruleScopedFilesAnalyzed ?? 0;
  if (sourceReport.gate?.pass === false) return 'fiction-review-required';
  if (sourceReport.gate?.pass && ruleScoped > 0) return 'platform-fiction-clean';
  if (sourceReport.gate?.pass && ruleScoped === 0) return 'limited-scope';
  return 'limited-scope';
}

/**
 * Summarize ancillary pattern hits.
 * @param {number} sourceReport
 * @returns {any}
 */
function summarizeAncillaryPatternHits(sourceReport) {
  const totals = sourceReport?.scanScope?.fullDirectoryStats?.ruleHitTotals
    ?? sourceReport?.fullDirectoryStats?.ruleHitTotals;
  if (totals && typeof totals === 'object') {
    const ancillary = {};
    for (const [key, val] of Object.entries(totals)) {
      if (key === 'fictionKpi' || !val) continue;
      ancillary[key] = val;
    }
    if (Object.keys(ancillary).length > 0) {
      return { fictionKpi: totals.fictionKpi ?? 0, ancillary };
    }
    return null;
  }
  const scope = sourceReport?.scanScope || {};
  const ancillary = {};
  if ((scope.llmSlopPatternHits ?? 0) > 0) ancillary.llmSlop = scope.llmSlopPatternHits;
  if ((scope.euAiActPatternHits ?? 0) > 0) ancillary.euAiAct = scope.euAiActPatternHits;
  const prodLeak = scope.productionLeakFindings ?? sourceReport?.productionLeakFindings ?? 0;
  if (prodLeak > 0) ancillary.productionLeak = prodLeak;
  return Object.keys(ancillary).length ? { fictionKpi: 0, ancillary } : null;
}

/**
 * Format ancillary pattern hits note.
 * @param {number} sourceReport
 * @returns {any}
 */
function formatAncillaryPatternHitsNote(sourceReport) {
  const summary = summarizeAncillaryPatternHits(sourceReport);
  if (!summary?.ancillary) return null;
  const parts = Object.entries(summary.ancillary).map(([key, val]) => {
    const label = key === 'llmSlop' ? 'LLM slop'
      : key === 'euAiAct' ? 'EU AI Act'
      : key === 'agencyHandoff' ? 'agency-handoff'
      : key === 'productionLeak' ? 'production-leak'
      : key;
    return `${label}: ${val}`;
  });
  const total = Object.values(summary.ancillary).reduce((sum, n) => sum + n, 0);
  const blocking = sourceReport?.gate?.blockingCount ?? 0;
  const gateClause = blocking > 0
    ? `gate blockingCount ${Number(blocking).toLocaleString()} on configured severities`
    : 'gate blockingCount 0 on configured severities';
  return `${total} ancillary pattern hit(s) in full-tree scan (${parts.join(', ')}) — not fiction-KPI digest rows; ${gateClause}.`;
}

/**
 * Resolve fiction digest gate context.
 * @param {number} sourceReport
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function resolveFictionDigestGateContext(sourceReport, digest, options = {}) {
  const gate = options.gateReport || {};
  const scope = sourceReport?.scanScope || {};
  const hygiene = digest?.hygieneSummary || {};
  return {
    gateReport: gate,
    repositoryFilesTotal: options.repositoryFilesTotal
      ?? gate.repositoryFilesTotal
      ?? sourceReport?.repositoryFilesTotal
      ?? scope.repositoryFilesTotal
      ?? hygiene.repositoryFilesTotal
      ?? digest?.scanScope?.gateRepositoryFilesTotal
      ?? null,
    contentScanned: scope.fullDirectoryStats?.contentScanned
      ?? scope.fullDirectoryStats?.filesContentScanned
      ?? sourceReport?.credentialScanned
      ?? gate.credentialScanned
      ?? hygiene.contentFilesScanned
      ?? null,
    gateProfile: scope.profile
      ?? scope.gateRuleBundleProfile
      ?? digest?.scanScope?.gateRuleBundleProfile
      ?? hygiene.gateRuleBundleProfile
      ?? gate.scanScope?.profile
      ?? null
  };
}

/**
 * Build product fiction hygiene summary.
 * @param {number} sourceReport
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function buildProductFictionHygieneSummary(sourceReport, digest, options = {}) {
  const gateContext = resolveFictionDigestGateContext(sourceReport, digest, options);
  const { repositoryFilesTotal: repoTotal, contentScanned, gateProfile, gateReport } = gateContext;
  const scope = sourceReport?.scanScope || {};
  const ancillary = summarizeAncillaryPatternHits(sourceReport);
  const sourceScanned = scope.sourceCodeFilesScanned ?? sourceReport?.sourceCodeFilesScanned ?? null;
  const jestChecked = sourceReport?.jestBaselineChecked === false
    || scope.jestExecutedDuringScan === false
    || gateReport.jestBaselineChecked === false
    || digest?.hygieneSummary?.jestBaselineChecked === false
    ? false
    : null;
  return {
    digestTrust: digest.digestTrust ?? null,
    gatePass: sourceReport?.gate?.pass ?? null,
    blockingCount: sourceReport?.gate?.blockingCount ?? 0,
    repositoryFilesTotal: repoTotal,
    ruleScopedFilesAnalyzed: sourceReport?.ruleScopedFilesAnalyzed ?? scope.ruleScopedFilesAnalyzed ?? null,
    fictionJsonFilesScanned: sourceReport?.fictionJsonFilesScanned ?? scope.fictionJsonFilesScanned ?? null,
    fictionSampleFilesScanned: sourceReport?.fictionSampleFilesScanned ?? scope.fictionSampleFilesScanned ?? null,
    fictionKpiHits: (digest.fictionIssues || []).reduce((sum, issue) => sum + (issue.count || 1), 0),
    fullDirectoryScan: Boolean(sourceReport?.fullDirectoryScan || scope.fullDirectoryScan),
    sourceCodeFilesScanned: sourceScanned,
    ...(contentScanned != null ? { contentFilesScanned: contentScanned } : {}),
    ...(repoTotal != null && contentScanned != null && repoTotal > contentScanned
      ? { metadataOnlyInventoryFiles: repoTotal - contentScanned }
      : {}),
    ...(gateProfile ? { gateRuleBundleProfile: gateProfile } : {}),
    ...(ancillary?.fictionKpi != null ? { fictionKpiPatternHits: ancillary.fictionKpi } : {}),
    ...(ancillary?.ancillary ? { ancillaryPatternHits: ancillary.ancillary } : {}),
    ...(jestChecked === false ? { jestBaselineChecked: false } : {}),
    attestationNote: 'Fiction/KPI digest hygiene — not vendor handoff or Complete scan clearance certification.'
  };
}

/**
 * Build product fiction scan scope.
 * @param {number} sourceReport
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
function buildProductFictionScanScope(sourceReport, digest, options = {}) {
  const gateContext = resolveFictionDigestGateContext(sourceReport, digest, options);
  const scope = sourceReport?.scanScope || {};
  const { repositoryFilesTotal: gateTotal, gateProfile } = gateContext;
  return {
    resultsViewScope: scope.resultsViewScope || 'platform-only',
    reportHealth: scope.reportHealth || 'platform-scoped',
    securityHandoffEligible: false,
    fullDirectoryScan: Boolean(sourceReport?.fullDirectoryScan || scope.fullDirectoryScan),
    ...(gateTotal != null ? { gateRepositoryFilesTotal: gateTotal } : {}),
    ...(gateProfile ? { gateRuleBundleProfile: gateProfile } : {}),
    fictionDigestNote: scope.fictionDigestNote
      || digest?.scanScope?.fictionDigestNote
      || 'Fiction/KPI digest export — gate pass here does not replace Complete scan clearance bundle.'
  };
}

/**
 * Build product fiction export notes.
 * @param {any} digest
 * @param {number} sourceReport
 * @param {Object} options
 * @returns {any}
 */
function buildProductFictionExportNotes(digest, sourceReport, options = {}) {
  const notes = [
    'securityHandoffEligible is false — fiction/KPI digest is hygiene attestation only, not vendor security handoff.',
    'Absolute scan paths are redacted to project label in operator exports.'
  ];
  const gateContext = resolveFictionDigestGateContext(sourceReport, digest, options);
  const { repositoryFilesTotal: repoTotal, contentScanned, gateProfile } = gateContext;
  if (repoTotal != null && contentScanned != null && contentScanned < repoTotal) {
    notes.push(
      `Gate content-scanned ${Number(contentScanned).toLocaleString()} production-path file(s) — ${Number(repoTotal - contentScanned).toLocaleString()} binary/metadata-only path(s) in full-tree inventory of ${Number(repoTotal).toLocaleString()}.`
    );
  }
  const scope = sourceReport?.scanScope || {};
  const fictionJson = sourceReport?.fictionJsonFilesScanned ?? scope.fictionJsonFilesScanned;
  const sourceScanned = scope.sourceCodeFilesScanned ?? sourceReport?.sourceCodeFilesScanned;
  if (fictionJson != null && sourceScanned != null) {
    notes.push(
      `Fiction/KPI rules evaluated ${Number(fictionJson).toLocaleString()} repository JSON path(s) plus ${Number(sourceScanned).toLocaleString()} source file(s) under server/, src/.`
    );
  }
  if (!scope.jestExecutedDuringScan) {
    notes.push('Jest was not run during this scan — use `npm run simplebeacon:full` or `npm test` for live test verification.');
  }
  if (scope.mockSampleFilesReconciledNote) {
    notes.push(scope.mockSampleFilesReconciledNote);
  }
  const mockSamples = sourceReport?.mockSampleFiles
    ?? sourceReport?.totalFiles
    ?? scope.mockSampleFilesInScanPaths
    ?? 0;
  const fictionSamples = sourceReport?.fictionSampleFilesScanned
    ?? scope.fictionSampleFilesScanned
    ?? 0;
  if (mockSamples > 0 && fictionSamples === 0 && !scope.mockSampleFilesReconciledNote) {
    notes.push(
      // simplebeacon:production-leak-intent - legitimate sample path reference for fiction digest reporting
      `${mockSamples} mock-data path(s) exist in the tree — fiction KPI rules target *-sample.json filenames; none were counted in this pass.`
    );
  }
  const ruleScoped = sourceReport?.ruleScopedFilesAnalyzed ?? scope.ruleScopedFilesAnalyzed ?? 0;
  if (sourceReport?.fullDirectoryScan || scope.fullDirectoryScan) {
    notes.push(
      'Fiction digest sourced from intentional full-directory scan — rule-scoped counts include configured production paths (e.g. server/, src/).'
    );
  }
  if (sourceReport?.gate?.pass && ruleScoped > 0) {
    notes.push(
      `Gate pass on ${Number(ruleScoped).toLocaleString()} rule-scoped files — fiction digest is hygiene only, not vendor handoff certification.`
    );
  } else if (sourceReport?.gate?.pass && ruleScoped === 0) {
    notes.push('Gate pass with zero rule-scoped files — limited-scope attestation; re-run on product root with gate profile.');
  } else if (sourceReport?.gate?.pass === false) {
    const blocking = sourceReport.gate?.blockingCount ?? 0;
    if (blocking > 0) {
      notes.push(
        `Gate FAIL — ${Number(blocking).toLocaleString()} blocking finding(s) in bundled scan — fiction KPI rows are clean; see json/simplebeacon-gate.json for production-path evidence.`
      );
    }
  }
  const profile = gateProfile ?? sourceReport?.scanScope?.profile;
  if (profile && !/^(gate|full-tree)$/i.test(String(profile))) {
    notes.push(
      `scanScope.profile (${profile}) reflects Complete scan rule bundle — fiction digest lists fiction-KPI rows only.`
    );
  }
  const ancillaryNote = formatAncillaryPatternHitsNote(sourceReport);
  if (ancillaryNote) {
    notes.push(ancillaryNote);
  }
  if ((digest.fictionIssues || []).length === 0 && (digest.nonFictionIssues || []).length === 0) {
    notes.push(ancillaryNote
      ? 'No fiction-KPI digest rows exported — ancillary pattern totals are in sourceReport.scanScope.fullDirectoryStats.ruleHitTotals.'
      : 'No fiction or ancillary pattern rows in digest export — see sourceReport.scanScope for scan limits.');
  }
  return [...new Set(notes)].slice(0, 12);
}

/**
 * Enrich product source report.
 * @param {number} sourceReport
 * @returns {any}
 */
function enrichProductSourceReport(sourceReport) {
  if (!sourceReport || sourceReport.type !== 'simplebeacon-report') return sourceReport;
  const { gateAttestation: _gateAttestation, ...reportRest } = sourceReport;
  const intentionalFullTree = Boolean(sourceReport.fullDirectoryScan || sourceReport.scanScope?.fullDirectoryScan);
  const reportHealth = intentionalFullTree
    ? 'platform-scoped-full-tree'
    : (sourceReport.scanScope?.reportHealth || 'platform-scoped');
  const scanProfile = sourceReport.scanScope?.profile;
  const fictionDigestProfileNote = scanProfile && !/^(gate|full-tree)$/i.test(String(scanProfile))
    ? `scanScope.profile (${scanProfile}) reflects Complete scan rule bundle — fiction digest lists fiction-KPI rows only.`
    : undefined;
  return {
    ...reportRest,
    scanTargetProfile: 'product',
    exportSanitized: true,
    handoffEligible: false,
    securityHandoffEligible: false,
    scanScope: {
      ...(sourceReport.scanScope || {}),
      resultsViewScope: sourceReport.scanScope?.resultsViewScope || 'platform-only',
      reportHealth,
      rescanRecommended: intentionalFullTree
        ? false
        : Boolean(sourceReport.scanScope?.rescanRecommended),
      inventoryMetricsStale: intentionalFullTree
        ? false
        : (sourceReport.scanScope?.inventoryMetricsStale ?? false),
      fictionDigestNote: 'Fiction/KPI digest export — gate pass here does not replace Complete scan clearance bundle.',
      ...(fictionDigestProfileNote ? { fictionDigestProfileNote } : {})
    }
  };
}

/**
 * Resolve digest trust.
 * @param {any} benchmarkScan
 * @param {Array} fictionIssues
 * @param {number} sourceReport
 * @returns {any}
 */
function resolveDigestTrust(benchmarkScan, fictionIssues, sourceReport) {
  if (benchmarkScan) return 'benchmark-clone';
  const fictionN = fictionIssues.reduce((sum, issue) => sum + (issue.count || 1), 0);
  if (fictionN > 0) return 'review';
  const ruleScoped = sourceReport?.ruleScopedFilesAnalyzed ?? sourceReport?.scanScope?.ruleScopedFilesAnalyzed ?? 0;
  if (sourceReport?.gate?.pass && ruleScoped === 0) return 'limited-scope';
  return 'trustworthy';
}

/**
 * Sanitize source report for digest.
 * @param {number} report
 * @param {string} projectPath
 * @returns {any}
 */
function sanitizeSourceReportForDigest(report, projectPath) {
  if (!report || report.type !== 'simplebeacon-report') return report;
  const projectKey = String(report.projectRoot || projectPath || '').replace(/\\/g, '/');
  const benchmarkTarget = isBenchmarkPath(projectKey);
  const sourceIssues = report.rawIssues?.length ? report.rawIssues : (report.detectedIssues || []);
  const platformIssues = [];
  const benchmarkCloneNoiseIssues = [];
  const benchmarkScannerMetaIssues = [];

  for (const issue of sourceIssues) {
    const paths = [issue?.filePath, issue?.file, ...(issue?.affectedFiles || [])].filter(Boolean);
    if (paths.some(isBenchmarkPath)) continue;
    if (benchmarkTarget && isBenchmarkCloneNoiseIssue(issue)) {
      benchmarkCloneNoiseIssues.push(issue);
      continue;
    }
    if (benchmarkTarget && isBenchmarkScannerMetaIssue(issue)) {
      benchmarkScannerMetaIssues.push(issue);
      continue;
    }
    platformIssues.push(issue);
  }

  const gateConfig = report.gate || report.scanScope?.gatePolicy || { failOn: ['high'], warnOn: ['medium', 'low'] };
  const blockingCount = platformIssues
    .filter((issue) => (gateConfig.failOn || ['high']).includes(issue.severityBand || issue.severity))
    .reduce((sum, issue) => sum + (issue.count || 1), 0);
  const warningCount = platformIssues
    .filter((issue) => (gateConfig.warnOn || ['medium', 'low']).includes(issue.severityBand || issue.severity))
    .reduce((sum, issue) => sum + (issue.count || 1), 0);
  const ruleScoped = report.ruleScopedFilesAnalyzed ?? report.scanScope?.ruleScopedFilesAnalyzed ?? 0;
  const gatePass = blockingCount === 0;
  const hollowGate = gatePass && ruleScoped === 0;
  const intentionalFullTree = Boolean(report.fullDirectoryScan || report.scanScope?.fullDirectoryScan);
  const staleFullTreeScan = !benchmarkTarget && !intentionalFullTree && isStaleFullTreeScan(report);
  let normalizedReport = benchmarkTarget ? reconcileBenchmarkDigestScanMetrics(report) : report;
  const gateAttestation = benchmarkTarget ? resolveBenchmarkDigestGateAttestation(normalizedReport) : undefined;
  const scanScopeBase = {
    ...(normalizedReport.scanScope || {}),
    resultsViewScope: benchmarkTarget ? 'benchmark-clone' : 'platform-only',
    benchmarkScanTarget: benchmarkTarget || undefined,
    benchmarkCloneNoiseExcluded: benchmarkCloneNoiseIssues.length || undefined,
    benchmarkScannerMetaExcluded: benchmarkScannerMetaIssues.length || undefined,
    reportHealth: benchmarkTarget
      ? 'benchmark-clone-scan'
      : intentionalFullTree
        ? 'platform-scoped-full-tree'
        : staleFullTreeScan
          ? 'stale-full-tree-scan'
          : (report.scanScope?.reportHealth || 'platform-scoped'),
    rescanRecommended: benchmarkTarget
      ? false
      : intentionalFullTree
        ? false
        : staleFullTreeScan || Boolean(report.scanScope?.rescanRecommended),
    limitations: benchmarkTarget
      ? ['Scanning OSS benchmark clone under github-cache/ — Simplebeacon product gate paths were not evaluated.']
      : report.scanScope?.limitations
  };
  const scanScope = benchmarkTarget
    ? sanitizeBenchmarkDigestScanScope(scanScopeBase, normalizedReport)
    : reconcileProductDigestScanScope(scanScopeBase, normalizedReport);

  const projectLabel = projectLabelFromPath(projectKey);
  return {
    ...normalizedReport,
    projectRoot: normalizeDigestProjectPaths(normalizedReport.projectRoot || projectKey, projectLabel),
    platformRoot: benchmarkTarget
      ? normalizeDigestProjectPaths(normalizedReport.platformRoot || resolveProductPlatformRoot(projectKey), projectLabel)
      : normalizeDigestProjectPaths(normalizedReport.platformRoot, projectLabel),
    rawIssues: platformIssues,
    detectedIssues: platformIssues.slice(0, 12),
    benchmarkCloneNoiseIssues: benchmarkCloneNoiseIssues.length ? benchmarkCloneNoiseIssues : undefined,
    benchmarkScannerMetaIssues: benchmarkScannerMetaIssues.length ? benchmarkScannerMetaIssues : undefined,
    issueCount: blockingCount,
    gate: { ...gateConfig, pass: gatePass, blockingCount, warningCount },
    ...(hollowGate && !benchmarkTarget ? { gateAttestation: 'limited-scope' } : {}),
    ...(benchmarkTarget ? { gateAttestation } : {}),
    scanScope,
    ...(benchmarkTarget
      ? {
          benchmarkScan: true,
          scanTargetProfile: 'benchmark-cache',
          handoffEligible: false,
          productPlatformRoot: normalizeDigestProjectPaths(resolveProductPlatformRoot(projectKey))
        }
      : {})
  };
}

/**
 * Sanitize fiction digest export.
 * @param {any} digest
 * @param {Object} options
 * @returns {any}
 */
export function sanitizeFictionDigestExport(digest, options = {}) {
  if (!digest || digest.type !== 'simplebeacon-fiction-digest') return digest;

  const hintedPath = inferDigestScanTargetFromHints(digest, options);
  const rawProjectPath = hintedPath || resolveDigestProjectPath(digest, options);
  const benchmarkScan = isBenchmarkFictionDigest(digest, { ...options, projectPath: rawProjectPath });
  const projectLabel = projectLabelFromPath(rawProjectPath);
  const projectPath = normalizeDigestProjectPaths(rawProjectPath, projectLabel);
  const rawPlatformRoot = benchmarkScan
    ? (options.productPlatformRoot || resolveProductPlatformRoot(rawProjectPath))
    : null;
  const productPlatformRoot = rawPlatformRoot
    ? normalizeDigestProjectPaths(rawPlatformRoot, projectLabelFromPath(rawPlatformRoot))
    : null;
  const normalizedPath = projectPath;
  const scanTargetRoot = normalizedPath;
  const sourceReport = digest.sourceReport
    ? sanitizeSourceReportForDigest(digest.sourceReport, rawProjectPath)
    : null;
  const enrichedSourceReport = benchmarkScan ? sourceReport : enrichProductSourceReport(sourceReport);
  const fictionIssues = filterDigestIssues(digest.fictionIssues || [], benchmarkScan);
  const nonFictionIssues = filterDigestIssues(digest.nonFictionIssues || [], benchmarkScan);
  const digestTrust = resolveDigestTrust(benchmarkScan, fictionIssues, enrichedSourceReport);
  const fictionScopePreview = benchmarkScan
    ? buildBenchmarkFictionScopeSummary(enrichedSourceReport)
    : null;
  const ancillaryPatternSummary = benchmarkScan ? null : summarizeAncillaryPatternHits(enrichedSourceReport);
  const exportNotes = benchmarkScan
    ? buildBenchmarkFictionExportNotes(
        digest.exportNotes || [],
        fictionScopePreview?.llmSlopScanReconciledFrom != null
          ? [`LLM slop file count reconciled from ${fictionScopePreview.llmSlopScanReconciledFrom} to ${fictionScopePreview.llmSlopFilesScanned} clone inventory files on benchmark export.`]
          : []
      )
    : buildProductFictionExportNotes(
        { ...digest, fictionIssues, nonFictionIssues, digestTrust },
        enrichedSourceReport,
        options
      );

  return {
    type: 'simplebeacon-fiction-digest',
    generatedAt: digest.generatedAt || new Date().toISOString(),
    conclusion: benchmarkScan
      ? buildBenchmarkFictionConclusion(fictionIssues, nonFictionIssues, enrichedSourceReport)
      : digest.conclusion,
    fictionIssues,
    nonFictionIssues,
    digestTrust,
    projectPath: normalizedPath,
    sourceProjectPath: normalizeDigestProjectPaths(digest.sourceProjectPath, projectLabel) || normalizedPath,
    ...(benchmarkScan
      ? {
          benchmarkScan: true,
          scanTargetProfile: 'benchmark-cache',
          handoffEligible: false,
          exportNormalized: true,
          scanTargetRoot,
          platformRoot: productPlatformRoot || undefined,
          productPlatformRoot: productPlatformRoot || undefined,
          gateAttestation: resolveBenchmarkDigestGateAttestation(enrichedSourceReport),
          fictionScopeSummary: buildBenchmarkFictionScopeSummary(enrichedSourceReport)
        }
      : {
          exportNormalized: true,
          scanTargetProfile: 'product',
          securityHandoffEligible: false,
          handoffEligible: false,
          gateAttestation: resolveProductFictionDigestGateAttestation(enrichedSourceReport),
          fictionScopeSummary: {
            fictionJsonFilesScanned: enrichedSourceReport?.fictionJsonFilesScanned
              ?? enrichedSourceReport?.scanScope?.fictionJsonFilesScanned
              ?? null,
            fictionSampleFilesScanned: enrichedSourceReport?.fictionSampleFilesScanned
              ?? enrichedSourceReport?.scanScope?.fictionSampleFilesScanned
              ?? null,
            sourceFictionPatternHits: enrichedSourceReport?.scanScope?.sourceFictionPatternHits ?? 0,
            jestExecutedDuringScan: enrichedSourceReport?.scanScope?.jestExecutedDuringScan ?? false,
            ...(ancillaryPatternSummary?.ancillary
              ? { ancillaryPatternHits: ancillaryPatternSummary.ancillary }
              : {})
          },
          hygieneSummary: buildProductFictionHygieneSummary(enrichedSourceReport, {
            ...digest,
            fictionIssues,
            nonFictionIssues,
            digestTrust
          }, options),
          scanScope: buildProductFictionScanScope(enrichedSourceReport, {
            ...digest,
            fictionIssues,
            nonFictionIssues,
            digestTrust
          }, options)
        }),
    sourceReport: enrichedSourceReport,
    exportSanitized: true,
    exportNotes: exportNotes.length ? exportNotes : undefined
  };
}
