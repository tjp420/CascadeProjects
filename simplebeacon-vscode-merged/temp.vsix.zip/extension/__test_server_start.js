// Minimal test to verify dataServer can start
const http = require('http');
const Module = require('module');
const path = require('path');

// Mock vscode minimally
const mockOutputChannel = {
  appendLine: (msg) => console.log(msg)
};

const mockConfig = {
  get: (key, def) => def
};

const mockVscode = {
  workspace: {
    workspaceFolders: null,
    getConfiguration: () => mockConfig
  },
  window: {
    showInformationMessage: (msg) => console.log('[INFO]', msg),
    showErrorMessage: (msg) => console.log('[ERROR]', msg)
  }
};

// Hook module resolution to return mock vscode
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function(request, parent, isMain, options) {
  if (request === 'vscode') {
    return path.join(__dirname, '__fake_vscode.js');
  }
  return originalResolve(request, parent, isMain, options);
};

// Write fake vscode module
require('fs').writeFileSync(
  path.join(__dirname, '__fake_vscode.js'),
  `module.exports = ${JSON.stringify(mockVscode, null, 2)};`
);

const mockContext = {
  extension: { packageJSON: { version: 'test' } },
  subscriptions: { push: () => {} }
};

// Now load the dataServer module
const ds = require('./out/dataServer.js');

ds.startDataServer(mockContext, mockOutputChannel);

setTimeout(() => {
  const port = ds.getDataServerPort();
  console.log('Server port:', port);
  console.log('Is running:', ds.isDataServerRunning());
  if (port > 0) {
    http.get(`http://127.0.0.1:${port}/api/health`, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        console.log('Health response:', data);
        process.exit(0);
      });
    }).on('error', (err) => {
      console.log('Health request failed:', err.message);
      process.exit(1);
    });
  } else {
    console.log('Server did not start on a valid port');
    process.exit(1);
  }
}, 500);
