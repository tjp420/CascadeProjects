const fs = require('fs');
const vm = require('vm');

// Read compiled file
const code = fs.readFileSync('out/welcomeDashboard.js', 'utf8');

// Find the buildHtml method - look for the return statement with template literal
const methodMatch = code.match(/buildHtml\(\)[^{]*\{/);
if (!methodMatch) {
  console.error('Could not find buildHtml method');
  process.exit(1);
}

const methodStart = methodMatch.index;
let depth = 0;
let inTemplate = false;
let templateStart = -1;
let templateEnd = -1;

for (let i = methodStart; i < code.length; i++) {
  const ch = code[i];
  const prev = code[i-1];
  
  if (ch === '{' && !inTemplate) depth++;
  if (ch === '}' && !inTemplate) {
    depth--;
    if (depth === 0) break;
  }
  
  if (ch === '`' && prev !== '\\') {
    if (!inTemplate) {
      inTemplate = true;
      templateStart = i;
    } else {
      templateEnd = i;
      break;
    }
  }
}

if (templateStart === -1 || templateEnd === -1) {
  console.error('Could not find template literal');
  process.exit(1);
}

let html = code.substring(templateStart + 1, templateEnd);

// Replace template interpolations with safe placeholders
// Handle nested template literals carefully
let result = '';
let depth2 = 0;
for (let i = 0; i < html.length; i++) {
  if (html[i] === '$' && html[i+1] === '{') {
    let j = i + 2;
    let nested = 1;
    while (j < html.length && nested > 0) {
      if (html[j] === '{') nested++;
      if (html[j] === '}') nested--;
      if (html[j] === '`' && html[j-1] !== '\\') {
        // Skip nested template literal
        j++;
        while (j < html.length && !(html[j] === '`' && html[j-1] !== '\\')) j++;
      }
      j++;
    }
    result += 'PLACEHOLDER';
    i = j - 1;
  } else {
    result += html[i];
  }
}
html = result;

// Find script section
const scriptOpen = html.indexOf('<script');
const scriptTagEnd = html.indexOf('>', scriptOpen) + 1;
const scriptClose = html.indexOf('</script>', scriptTagEnd);
const js = html.substring(scriptTagEnd, scriptClose);

// Parse with vm.Script
try {
  new vm.Script(js);
  console.log('Compiled JS syntax: OK');
} catch (e) {
  console.error('Syntax error:', e.message);
  const lines = js.split('\n');
  const match = e.stack.match(/<anonymous>:(\d+):(\d+)/);
  if (match) {
    const line = parseInt(match[1]);
    console.error('At line', line);
    for (let i = Math.max(0, line-3); i < Math.min(lines.length, line+2); i++) {
      console.error((i+1) + ': ' + lines[i].substring(0, 100));
    }
  }
}
