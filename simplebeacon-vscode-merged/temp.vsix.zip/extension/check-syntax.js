const fs = require('fs');
const text = fs.readFileSync('src/welcomeDashboard.ts', 'utf8');

// Find buildHtml method and extract the template literal
const buildHtmlStart = text.indexOf('buildHtml(): string {');
const templateStart = text.indexOf('return `<!DOCTYPE html>', buildHtmlStart);
let templateEnd = text.indexOf('`;\n  }', templateStart);
if (templateEnd === -1) templateEnd = text.indexOf('`;\n  }\n\n', templateStart);

let html = text.substring(templateStart + 'return '.length, templateEnd + 1);

// Replace template interpolations
html = html.replace(/\$\{[^}]*\}/g, 'PLACEHOLDER');

// Extract JS between first <script> and </script>
const scriptStart = html.indexOf('<script');
const scriptTagEnd = html.indexOf('>', scriptStart) + 1;
const scriptEnd = html.indexOf('</script>', scriptTagEnd);

const js = html.substring(scriptTagEnd, scriptEnd);

// Try to parse with Function constructor
try {
  new Function(js);
  console.log('JS syntax OK');
} catch (e) {
  console.error('Syntax error:', e.message);
  // Find the approximate line in the JS
  const lines = js.split('\n');
  if (e.stack) {
    const match = e.stack.match(/<anonymous>:(\d+):(\d+)/);
    if (match) {
      const line = parseInt(match[1]);
      const col = parseInt(match[2]);
      console.error('At line', line, 'col', col);
      console.error('Context:');
      for (let i = Math.max(0, line - 3); i < Math.min(lines.length, line + 2); i++) {
        console.error('  ' + (i + 1) + ': ' + lines[i].substring(0, 100));
      }
    }
  }
}
