const fs = require('fs');
const text = fs.readFileSync('src/welcomeDashboard.ts', 'utf8');

// Extract the browser bridge script
const bridgeStart = text.indexOf('const bridge = `<script>');
const bridgeEnd = text.indexOf('</script>`;', bridgeStart);
let bridge = text.substring(bridgeStart, bridgeEnd + 10);

// Extract just the JS inside
const jsStart = bridge.indexOf('(function(){');
const jsEnd = bridge.lastIndexOf('})();');
const js = bridge.substring(jsStart, jsEnd + 5);

try {
  new Function(js);
  console.log('Bridge syntax OK');
} catch (e) {
  console.error('Bridge syntax error:', e.message);
}
