const s = `\\/`;
const r = /(?:^|\\/)(test)(?:\\/|$)/;
console.log(s);
console.log(r.source);
