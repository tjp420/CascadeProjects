
// simplebeacon-ignore innerhtml-usage — webview template uses controlled HTML strings
let vscode;
try { vscode = acquireVsCodeApi(); } catch (e) { vscode = undefined; }
if (!vscode) {
  vscode = {
    postMessage: (msg) => {
      if (window.parent && window.parent.postMessage) {
        window.parent.postMessage({ ...msg, source: 'simplebeacon-welcome' }, '*');
      }
    }
  };
}
// Cache the VS Code API globally so other scripts don't try to re-acquire it
window.vscode = vscode;
if (vscode && typeof window.acquireVsCodeApi === 'function') {
  try {
    const _cachedApi = vscode;
    window.acquireVsCodeApi = function() { return _cachedApi; };
  } catch (e) { /* silent — already acquired is OK */ }
}
function addTab(label, paneId) {
  const bar = document.getElementById('tabBar');
  const barLeft = document.getElementById('tabBarLeft');
  if (!bar) return;
  const container = barLeft || bar;
  const existing = container.querySelector('[data-pane="' + paneId + '"]');
  if (existing) { activateTab(paneId); return; }
  const tab = document.createElement('div');
  tab.className = 'tab';
  tab.dataset.pane = paneId;
  const tabLabel = document.createElement('span');
  tabLabel.className = 'tab-label';
  tabLabel.textContent = label;
  const tabClose = document.createElement('span');
  tabClose.className = 'tab-close';
  tabClose.title = 'Close';
  tabClose.textContent = '×';
  tab.appendChild(tabLabel);
  tab.appendChild(tabClose);
  tabLabel.addEventListener('click', () => activateTab(paneId));
  tabClose.addEventListener('click', (e) => { e.stopPropagation(); tab.remove(); const p = document.getElementById(paneId); if (p) p.classList.remove('active'); const rem = container.querySelector('.tab'); if (rem) activateTab(rem.dataset.pane); });
  container.appendChild(tab);
  activateTab(paneId);
}
function activateTab(paneId) {
  const pane = document.getElementById(paneId);
  if (!pane) return;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.pane === paneId));
  document.querySelectorAll('.pane').forEach(p => p.classList.toggle('active', p.id === paneId));
}
function getTabList() { return Array.from(document.querySelectorAll('#tabBar .tab')); }
function getActiveTabIndex() { return getTabList().findIndex(t => t.classList.contains('active')); }
function bindBtn(id, paneId, command) {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener('click', () => {
      try { addTab(paneId.replace('Pane',''), paneId); } catch (e) { console.error('addTab error:', e); }
      try { activateTab(paneId); } catch (e) { console.error('activateTab error:', e); }
      if (command) {
        try { vscode.postMessage({ command }); } catch (e) { console.error('postMessage error:', e); }
      }
    });
  } else {
    console.warn('bindBtn: element not found for id', id);
  }
}
function bindProfileToggle(id, command) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('click', () => {
    const on = el.classList.toggle('on');
    vscode.postMessage({ command: command, value: on });
  });
}
function initWelcomeButtons() {
  console.log('[SB] initWelcomeButtons start');
  document.querySelectorAll('#tabBar .tab').forEach(t => { if (!t.dataset.bound) { t.dataset.bound = '1'; t.addEventListener('click', () => activateTab(t.dataset.pane)); } });
  const tabArrowLeft = document.getElementById('tabArrowLeft');
  if (tabArrowLeft) tabArrowLeft.addEventListener('click', () => {
    const tabs = getTabList(); const idx = getActiveTabIndex();
    if (tabs.length > 1 && idx > 0) { activateTab(tabs[idx - 1].dataset.pane); }
  });
  const tabArrowRight = document.getElementById('tabArrowRight');
  if (tabArrowRight) tabArrowRight.addEventListener('click', () => {
    const tabs = getTabList(); const idx = getActiveTabIndex();
    if (tabs.length > 1 && idx >= 0 && idx < tabs.length - 1) { activateTab(tabs[idx + 1].dataset.pane); }
  });
  const tabCloseBtn = document.getElementById('tabCloseBtn');
  if (tabCloseBtn) tabCloseBtn.addEventListener('click', () => {
    const tabs = getTabList();
    const idx = getActiveTabIndex();
    if (idx < 0) return;
    const activeTab = tabs[idx];
    const paneId = activeTab.dataset.pane;
    activeTab.remove();
    const p = document.getElementById(paneId);
    if (p) p.classList.remove('active');
    const rem = getTabList();
    if (rem.length > 0) { activateTab(rem[Math.min(idx, rem.length - 1)].dataset.pane); }
  });
  bindBtn('openDashboard','dashboardPane','openDashboard');
  bindBtn('openAnalyze','analyzePane','openAnalyze');
  bindBtn('openReport','reportPane','openReport');
  bindBtn('openCertificate','certificatePane','openCertificate');
  bindBtn('openCodeMap','codeMapPane','openCodeMap');
  bindBtn('openRoadmap','roadmapPane','openRoadmap');
  bindBtn('openAiContext','aiContextPane','openAiContext');
  bindBtn('openUpload','uploadPane','openUpload');
  bindBtn('openAudit','auditPane','openAudit');
  bindBtn('openSecurity','securityPane','openSecurity');
  bindBtn('openTrust','trustPane','openTrust');
  bindBtn('openQuality','qualityPane','openQuality');
  bindBtn('openAssessments','assessmentsPane','openAssessments');
  bindBtn('openPlatform','platformPane','openPlatform');
  bindBtn('openProfile','profilePane','openProfile');
  bindBtn('openCompliance','compliancePane','openCompliance');
  bindBtn('openRepoHealth','repoHealthPane','openRepoHealth');
  bindBtn('openAnalytics','analyticsPane','openAnalytics');
  bindBtn('openTeam','teamPane','openTeam');
  bindBtn('openScan','scanPane','openScan');
  bindBtn('openSettings','settingsPane','openSettings');
  const profileSaveBtn = document.getElementById('profileSaveBtn');
  if (profileSaveBtn) profileSaveBtn.addEventListener('click', () => {
    const name = document.getElementById('profileName');
    const email = document.getElementById('profileEmail');
    const role = document.getElementById('profileRole');
    const org = document.getElementById('profileOrg');
    const statusDot = document.getElementById('profileStatusDot');
    const statusText = document.getElementById('profileStatusText');
    if (statusDot) statusDot.className = 'db-scan-dot';
    if (statusText) statusText.textContent = 'Saved';
    vscode.postMessage({ command: 'saveProfile', name: name ? name.value : '', email: email ? email.value : '', role: role ? role.value : '', org: org ? org.value : '' });
  });
  const profileClearBtn = document.getElementById('profileClearBtn');
  if (profileClearBtn) profileClearBtn.addEventListener('click', () => {
    const name = document.getElementById('profileName');
    const email = document.getElementById('profileEmail');
    const role = document.getElementById('profileRole');
    const org = document.getElementById('profileOrg');
    const statusDot = document.getElementById('profileStatusDot');
    const statusText = document.getElementById('profileStatusText');
    if (name) name.value = '';
    if (email) email.value = '';
    if (role) role.value = '';
    if (org) org.value = '';
    if (statusDot) statusDot.className = 'db-scan-dot idle';
    if (statusText) statusText.textContent = 'Not saved';
  });
  bindProfileToggle('profileAutoScanToggle', 'updateProfileAutoScan');
  bindProfileToggle('profileNotifyToggle', 'updateProfileNotify');
  bindProfileToggle('profileDarkToggle', 'updateProfileDarkMode');
  const repoHealthRefreshBtn = document.getElementById('repoHealthRefreshBtn');
  if (repoHealthRefreshBtn) repoHealthRefreshBtn.addEventListener('click', () => {
    const dot = document.getElementById('repoHealthStatusDot');
    const status = document.getElementById('repoHealthStatusText');
    if (dot) dot.className = 'db-scan-dot idle';
    if (status) status.textContent = 'Scanning...';
    vscode.postMessage({ command: 'scan' });
  });
  const rhRunBtn = document.getElementById('rhRunBtn');
  if (rhRunBtn) rhRunBtn.addEventListener('click', () => vscode.postMessage({ command: 'scan' }));
  const rhExportBtn = document.getElementById('rhExportBtn');
  if (rhExportBtn) rhExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReport' }));
  const rhViewBtn = document.getElementById('rhViewBtn');
  if (rhViewBtn) rhViewBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
  const rhSettingsBtn = document.getElementById('rhSettingsBtn');
  if (rhSettingsBtn) rhSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
  const teamInviteBtn = document.getElementById('teamInviteBtn');
  if (teamInviteBtn) teamInviteBtn.addEventListener('click', () => {
    const email = document.getElementById('inviteEmail');
    const role = document.getElementById('inviteRole');
    if (email && email.value) {
      vscode.postMessage({ command: 'inviteTeamMember', email: email.value, role: role ? role.value : 'viewer' });
      email.value = '';
    }
  });
  const teamDashboardBtn = document.getElementById('openTeamDashboard');
  if (teamDashboardBtn) teamDashboardBtn.addEventListener('click', () => vscode.postMessage({ command: 'openTeamDashboard' }));
  const previewWindowBtn = document.getElementById('openPreviewWindow');
  if (previewWindowBtn) previewWindowBtn.addEventListener('click', () => vscode.postMessage({ command: 'openPreviewInBrowser' }));
  console.log('[SB] initWelcomeButtons done');
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWelcomeButtons);
} else {
  initWelcomeButtons();
}
const scanDashBtn = document.getElementById('scanFromDashboard');
if (scanDashBtn) scanDashBtn.addEventListener('click', () => vscode.postMessage({ command: 'scan' }));
const rptDashBtn = document.getElementById('openReportFromDashboard');
if (rptDashBtn) rptDashBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const dashExportBtn = document.getElementById('dashExportBtn');
if (dashExportBtn) dashExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportScanReport' }));
const anlDashBtn = document.getElementById('openAnalyzeFromDashboard');
if (anlDashBtn) anlDashBtn.addEventListener('click', () => { addTab('Analyze','analyzePane'); vscode.postMessage({ command: 'openAnalyze' }); });
const stgDashBtn = document.getElementById('openSettingsFromDashboard');
if (stgDashBtn) stgDashBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
function updateSeverityBar(sev) {
  const total = (sev.critical || 0) + (sev.high || 0) + (sev.medium || 0) + (sev.low || 0);
  if (total === 0) return;
  const c = document.getElementById('sevCritical'), h = document.getElementById('sevHigh'), m = document.getElementById('sevMedium'), l = document.getElementById('sevLow');
  if (c) { c.style.width = ((sev.critical || 0) / total * 100) + '%'; c.textContent = (sev.critical || 0) > 0 ? (sev.critical || 0) : ''; }
  if (h) { h.style.width = ((sev.high || 0) / total * 100) + '%'; h.textContent = (sev.high || 0) > 0 ? (sev.high || 0) : ''; }
  if (m) { m.style.width = ((sev.medium || 0) / total * 100) + '%'; m.textContent = (sev.medium || 0) > 0 ? (sev.medium || 0) : ''; }
  if (l) { l.style.width = ((sev.low || 0) / total * 100) + '%'; l.textContent = (sev.low || 0) > 0 ? (sev.low || 0) : ''; }
}
function renderFindings(findings) {
  const list = document.getElementById('findingsList');
  if (!list) return;
  list.textContent = '';
  if (!findings || findings.length === 0) { renderEmpty(list, 'No findings yet. Run a scan to detect issues.'); return; }
  findings.slice(0, 20).forEach(f => list.appendChild(renderFindingRow('db-finding', f)));
}
/* Analyze Pane Interactivity */
function getSelectedAnalyzers() {
  return Array.from(document.querySelectorAll('.analyzer-chip.selected')).map(c => c.dataset.id);
}
function setAnalyzerSelection(ids) {
  document.querySelectorAll('.analyzer-chip').forEach(c => {
    const sel = ids.includes(c.dataset.id);
    c.classList.toggle('selected', sel);
    const check = c.querySelector('.chip-check');
    if (check) check.textContent = sel ? '✓' : '';
  });
}
document.querySelectorAll('.analyzer-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    chip.classList.toggle('selected');
    const check = chip.querySelector('.chip-check');
    if (check) check.textContent = chip.classList.contains('selected') ? '✓' : '';
  });
});
const analyzeTypeSelect = document.getElementById('analyzeTypeSelect');
if (analyzeTypeSelect) {
  const presetMap = {
    gate: ['simplebeacon'],
    complete: ['simplebeacon','consolidation','mock-scan','roadmap','codebase','npm-audit','dependency-vulns','sensitive-data','eval-danger','inner-html-xss','ai-indicators','ai-residue','llm-slop','fiction-kpi','performance','type-safety','test-coverage','complexity'],
    security: ['dependency-vulns','sensitive-data','eval-danger','inner-html-xss','config-drift','prototype-pollution','unvalidated-redirect','missing-rate-limit','insecure-random','logging-secrets'],
    ai: ['ai-indicators','ai-residue','llm-slop','fiction-kpi','hardcoded-confidence','hardcoded-completion','token-bleed','ai-placeholder-comment','ai-placeholder-block','markdown-fence-leak','empty-stub-function','arrow-stub'],
    quality: ['performance','type-safety','documentation','test-coverage','complexity','magic-number','missing-strict-mode','uninitialized-read','unhandled-promise','sync-io'],
    roadmap: ['roadmap','build-readiness','governance','junk-files']
  };
  analyzeTypeSelect.addEventListener('change', () => {
    const preset = presetMap[analyzeTypeSelect.value];
    if (preset) setAnalyzerSelection(preset);
  });
}
const analyzeRunBtn = document.getElementById('analyzeRunBtn');
if (analyzeRunBtn) {
  analyzeRunBtn.addEventListener('click', () => {
    if (analyzeRunBtn.dataset.intervalId) {
      clearInterval(Number(analyzeRunBtn.dataset.intervalId));
      delete analyzeRunBtn.dataset.intervalId;
    }
    const pathInput = document.getElementById('analyzePathInput');
    const path = pathInput ? pathInput.value : '';
    const analyzers = getSelectedAnalyzers();
    const minSev = document.getElementById('analyzeSeveritySelect');
    vscode.postMessage({ command: 'analyze', path: path, analyzers: analyzers, minSeverity: minSev ? minSev.value : 'medium' });
    const wrap = document.getElementById('analyzeProgressWrap');
    const fill = document.getElementById('analyzeProgressFill');
    const label = document.getElementById('analyzeProgressLabel');
    const pct = document.getElementById('analyzeProgressPct');
    if (wrap) wrap.style.display = 'block';
    let p = 0;
    const interval = setInterval(() => {
      p += Math.floor(Math.random() * 12) + 3;
      if (p > 95) p = 95;
      if (fill) fill.style.width = p + '%';
      if (pct) pct.textContent = p + '%';
      const phases = ['Discovering files...','Running analyzers...','Aggregating results...','Building report...'];
      if (label) label.textContent = phases[Math.min(Math.floor(p / 25), 3)];
      if (p >= 95) clearInterval(interval);
    }, 400);
    analyzeRunBtn.dataset.intervalId = String(interval);
  });
}
const analyzeWorkspaceBtn = document.getElementById('analyzeWorkspaceBtn');
if (analyzeWorkspaceBtn) {
  analyzeWorkspaceBtn.addEventListener('click', () => vscode.postMessage({ command: 'scan' }));
}
const analyzeExportBtn = document.getElementById('analyzeExportBtn');
if (analyzeExportBtn) {
  analyzeExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportAnalysis' }));
}
const analyzeBrowseBtn = document.getElementById('analyzeBrowseBtn');
if (analyzeBrowseBtn) {
  analyzeBrowseBtn.addEventListener('click', () => vscode.postMessage({ command: 'browseAnalyzePath' }));
}
const analyzeDetectWorkspaceBtn = document.getElementById('analyzeDetectWorkspaceBtn');
if (analyzeDetectWorkspaceBtn) {
  analyzeDetectWorkspaceBtn.addEventListener('click', () => vscode.postMessage({ command: 'detectWorkspacePath' }));
}
function updateAnalyzeSeverityBar(sev) {
  const total = (sev.critical || 0) + (sev.high || 0) + (sev.medium || 0) + (sev.low || 0);
  if (total === 0) return;
  const c = document.getElementById('analyzeSevCritical'), h = document.getElementById('analyzeSevHigh'), m = document.getElementById('analyzeSevMedium'), l = document.getElementById('analyzeSevLow');
  if (c) { c.style.width = ((sev.critical || 0) / total * 100) + '%'; c.textContent = (sev.critical || 0) > 0 ? (sev.critical || 0) : ''; }
  if (h) { h.style.width = ((sev.high || 0) / total * 100) + '%'; h.textContent = (sev.high || 0) > 0 ? (sev.high || 0) : ''; }
  if (m) { m.style.width = ((sev.medium || 0) / total * 100) + '%'; m.textContent = (sev.medium || 0) > 0 ? (sev.medium || 0) : ''; }
  if (l) { l.style.width = ((sev.low || 0) / total * 100) + '%'; l.textContent = (sev.low || 0) > 0 ? (sev.low || 0) : ''; }
}
function renderCodeMapGraph(canvas, graph, style = 'force') {
  if (!canvas || !graph || !graph.nodes || graph.nodes.length === 0) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const wrap = canvas.parentElement;
  let lastW = 0, lastH = 0;
  function resize() {
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const w = Math.max(1, rect.width);
    const h = Math.max(1, rect.height);
    canvas.width = w;
    canvas.height = h;
    if (lastW === 0 && lastH === 0 && w > 0 && h > 0 && nodes) {
      nodes.forEach((n, i) => { n.x = w / 2 + Math.cos(i * 2.4) * 150; n.y = h / 2 + Math.sin(i * 2.4) * 150; n.vx = 0; n.vy = 0; });
      t = 0;
    }
    lastW = w; lastH = h;
  }
  const colors = {'.js':'#f7df1e','.ts':'#3178c6','.tsx':'#3178c6','.jsx':'#61dafb','.cjs':'#f0db4f','.mjs':'#f0db4f','.py':'#3776ab','.json':'#94a3b8','.html':'#e34c26','.css':'#38bdf8','.md':'#8b5cf6','.yml':'#ef4444','.yaml':'#ef4444','.go':'#00add8','.rs':'#dea584','.java':'#b07219','.cpp':'#f34b7d','.c':'#555555','.sh':'#89e051','.vue':'#41b883','.php':'#4f5d95','.rb':'#701516','.swift':'#f05138','.kt':'#a97bff','Other':'#64748b'};
  const W = () => canvas.width, H = () => canvas.height;
  const nodeMap = {};
  // Compute connection count for each node to size them appropriately
  const connectionCount = {};
  (graph.edges || []).forEach(e => { connectionCount[e.source] = (connectionCount[e.source] || 0) + 1; connectionCount[e.target] = (connectionCount[e.target] || 0) + 1; });
  const maxConn = Math.max(1, ...Object.values(connectionCount));
  const nodes = graph.nodes.map((n, i) => {
    const conn = connectionCount[n.id] || 0;
    const radius = Math.max(3, Math.min(16, 4 + (conn / maxConn) * 12));
    const node = { id: n.id, label: n.label || n.id, group: n.group || '', size: n.size || 1, x: W() / 2 + Math.cos(i * 2.4) * 150, y: H() / 2 + Math.sin(i * 2.4) * 150, vx: 0, vy: 0, radius, connections: conn };
    nodeMap[n.id] = node;
    return node;
  });
  const edges = (graph.edges || []).map(e => ({ source: nodeMap[e.source], target: nodeMap[e.target] })).filter(e => e.source && e.target);
  let dragging = null, hoverNode = null, offset = {x: 0, y: 0}, scale = 1, pan = {x: 0, y: 0};
  let paused = false, showLabels = true, filterText = '';
  let animId = null, timeoutId = null;
  let currentStyle = style;
  let t = 0;
  function getColor(n) { return colors[n.group] || '#64748b'; }
  function worldToScreen(p) { return { x: p.x * scale + pan.x, y: p.y * scale + pan.y }; }
  function screenToWorld(mx, my) { return { x: (mx - pan.x) / scale, y: (my - pan.y) / scale }; }
  function matchesFilter(n) {
    if (!filterText) return true;
    return n.label.toLowerCase().includes(filterText.toLowerCase()) || n.id.toLowerCase().includes(filterText.toLowerCase());
  }
  function classifyLayer(fp) {
    const p = String(fp).toLowerCase().split(String.fromCharCode(92)).join('/');
    const name = p.split('/').pop() || '';
    if (/(?:^|\/)(test|tests|__tests__|__mocks__|spec|e2e|cypress|playwright)(?:\/|$)/.test(p) || /\.(test|spec)\.(js|ts|jsx|tsx|py|go|rs)$/.test(name)) return 'tests';
    if (/^(index|main|app|server|cli|entry|bootstrap|start)\.(js|ts|cjs|mjs|py|go|rs|java)$/.test(name)) return 'entry';
    if (/(?:^|\/)(components?|ui|pages?|views?|templates?|widgets|screens|layouts?)(?:\/|$)/.test(p) || /\.(tsx|jsx|vue|svelte|html|css|scss|less)$/.test(name)) return 'ui';
    if (/(?:^|\/)(services?|controllers?|business|logic|api|routes?|handlers?|middleware|actions?)(?:\/|$)/.test(p) || /(service|controller|route|handler|middleware|action)\.(js|ts|cjs|mjs)$/.test(name)) return 'business';
    if (/(?:^|\/)(db|database|models?|repositories?|stores?|schemas?|migrations?|configs?|settings?|infra|docker|k8s|helm)(?:\/|$)/.test(p) || /(config|model|schema|repository|store|migration|docker|dockerfile|docker-compose|k8s|helm)\.(js|ts|json|yaml|yml|env)$/.test(name)) return 'data';
    if (/(?:^|\/)(utils?|helpers?|lib|common|shared|tools?|scripts?|packages?)(?:\/|$)/.test(p) || /(util|helper|common|shared|tool|lib)\.(js|ts|cjs|mjs)$/.test(name)) return 'utils';
    return 'other';
  }
  resize();
  const resizeObserver = wrap ? new ResizeObserver(resize) : null;
  if (resizeObserver && wrap) resizeObserver.observe(wrap);
  // Ensure the canvas is resized once it becomes visible (e.g., when the Code Map tab is opened after data arrives)
  const intersectionObserver = wrap && typeof IntersectionObserver === 'function' ? new IntersectionObserver((entries) => { if (entries.some(e => e.isIntersecting)) resize(); }, { threshold: 0 }) : null;
  if (intersectionObserver && wrap) intersectionObserver.observe(wrap);
  // Fallback: if the pane was hidden when the graph was first created, resize after it becomes visible
  setTimeout(resize, 0);
  setTimeout(resize, 100);

  function computeRadialLayout() {
    const cx = W() / 2, cy = H() / 2;
    const root = nodes.find(n => !edges.some(e => e.target === n));
    const levels = [];
    function depth(n, visited = new Set()) {
      if (visited.has(n.id)) return 0;
      visited.add(n.id);
      const incoming = edges.filter(e => e.target === n);
      if (incoming.length === 0) return 0;
      return 1 + Math.max(...incoming.map(e => depth(e.source, new Set(visited))));
    }
    const maxDepth = Math.max(1, ...nodes.map(n => depth(n)));
    const byLevel = [];
    for (let i = 0; i <= maxDepth; i++) byLevel.push([]);
    nodes.forEach(n => { const d = depth(n); byLevel[d].push(n); });
    const radiusStep = Math.min(W(), H()) / (2 * (maxDepth + 1.5));
    byLevel.forEach((levelNodes, level) => {
      const r = radiusStep * (level + 1);
      const count = levelNodes.length;
      levelNodes.forEach((n, i) => {
        const angle = (i / count) * Math.PI * 2;
        n.tx = cx + Math.cos(angle) * r;
        n.ty = cy + Math.sin(angle) * r;
      });
    });
  }
  function computeGridLayout() {
    const cols = Math.max(1, Math.ceil(Math.sqrt(nodes.length)));
    const cell = Math.min(W() / cols, 120);
    const groups = {};
    nodes.forEach(n => { const g = n.group || 'Other'; if (!groups[g]) groups[g] = []; groups[g].push(n); });
    const sortedGroups = Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
    let x = 40, y = 40, rowH = 0;
    sortedGroups.forEach(([group, groupNodes]) => {
      const groupStart = x;
      groupNodes.forEach((n, i) => {
        n.tx = groupStart + (i % cols) * cell;
        n.ty = y + Math.floor(i / cols) * cell;
      });
      const rows = Math.ceil(groupNodes.length / cols);
      rowH = Math.max(rowH, rows * cell);
      x += cols * cell + 40;
      if (x > W() - 80) { x = 40; y += rowH + 40; rowH = 0; }
    });
    // Center the grid
    const xs = nodes.map(n => n.tx), ys = nodes.map(n => n.ty);
    const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
    const dx = (W() - (maxX - minX)) / 2 - minX, dy = (H() - (maxY - minY)) / 2 - minY;
    nodes.forEach(n => { n.tx += dx; n.ty += dy; });
  }
  function computeHierarchicalLayout() {
    const tree = {};
    nodes.forEach(n => { tree[n.id] = { n, children: [], depth: 0 }; });
    edges.forEach(e => { if (tree[e.source.id]) tree[e.source.id].children.push(e.target.id); });
    const roots = nodes.filter(n => !edges.some(e => e.target === n)).map(n => n.id);
    if (roots.length === 0) nodes.forEach(n => roots.push(n.id));
    function setDepth(id, d, visited) {
      if (visited.has(id)) return;
      visited.add(id);
      if (tree[id]) tree[id].depth = Math.max(tree[id].depth, d);
      tree[id].children.forEach(cid => setDepth(cid, d + 1, new Set(visited)));
    }
    roots.forEach(rid => setDepth(rid, 0, new Set()));
    const levels = [];
    nodes.forEach(n => {
      const d = tree[n.id].depth;
      if (!levels[d]) levels[d] = [];
      levels[d].push(n);
    });
    const levelHeight = H() / (levels.length + 1);
    levels.forEach((levelNodes, level) => {
      const y = levelHeight * (level + 1);
      const gap = W() / (levelNodes.length + 1);
      levelNodes.forEach((n, i) => { n.tx = gap * (i + 1); n.ty = y; });
    });
  }
  function computeCityLayout() {
    const layerOrder = ['entry', 'ui', 'business', 'data', 'utils', 'tests', 'other'];
    const layerGroups = {};
    nodes.forEach(n => {
      const layer = classifyLayer(n.id);
      (layerGroups[layer] = layerGroups[layer] || []).push(n);
    });
    const usableHeight = H() * 0.85;
    const layerHeight = usableHeight / layerOrder.length;
    const topOffset = H() * 0.08;
    layerOrder.forEach((layer, li) => {
      const layerNodes = layerGroups[layer] || [];
      const y = topOffset + layerHeight * li + layerHeight / 2;
      const cols = Math.max(1, Math.ceil(Math.sqrt(layerNodes.length)));
      const cell = Math.min((W() - 80) / cols, 140);
      layerNodes.forEach((n, i) => {
        n.tx = 40 + (i % cols) * cell;
        n.ty = y;
      });
    });
  }
  function applyLayout(animate) {
    if (currentStyle === 'radial') computeRadialLayout();
    else if (currentStyle === 'grid') computeGridLayout();
    else if (currentStyle === 'hierarchical') computeHierarchicalLayout();
    else if (currentStyle === 'city') computeCityLayout();
    if (currentStyle !== 'force') {
      nodes.forEach(n => { if (animate) { n.vx = (n.tx - n.x) * 0.1; n.vy = (n.ty - n.y) * 0.1; } else { n.x = n.tx; n.y = n.ty; } });
      if (!animate) t = 1000;
    } else {
      t = 0;
    }
  }
  applyLayout(false);
  canvas.addEventListener('mousedown', e => {
    const rect = canvas.getBoundingClientRect();
    const w = screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    for (const n of nodes) {
      if (!matchesFilter(n)) continue;
      const dx = w.x - n.x, dy = w.y - n.y;
      if (dx * dx + dy * dy < (n.radius + 4) ** 2) { dragging = n; offset = {x: dx, y: dy}; return; }
    }
    // Pan on empty space
    const startPan = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
    function onMove(ev) { pan.x = startPan.px + (ev.clientX - startPan.x); pan.y = startPan.py + (ev.clientY - startPan.y); }
    function onUp() { document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); }
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    const w = screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    if (dragging && currentStyle === 'force') { dragging.x = w.x - offset.x; dragging.y = w.y - offset.y; }
    hoverNode = null;
    for (const n of nodes) {
      if (!matchesFilter(n)) continue;
      const dx = w.x - n.x, dy = w.y - n.y;
      if (dx * dx + dy * dy < (n.radius + 4) ** 2) { hoverNode = n; break; }
    }
  });
  canvas.addEventListener('mouseup', () => { dragging = null; });
  canvas.addEventListener('mouseleave', () => { dragging = null; hoverNode = null; });
  canvas.addEventListener('wheel', e => { e.preventDefault(); const rect = canvas.getBoundingClientRect(); const w = screenToWorld(e.clientX - rect.left, e.clientY - rect.top); const factor = e.deltaY > 0 ? 0.9 : 1.1; scale = Math.max(0.2, Math.min(20, scale * factor)); pan.x = (e.clientX - rect.left) - w.x * scale; pan.y = (e.clientY - rect.top) - w.y * scale; }, { passive: false });
  function step() {
    if (!paused && currentStyle === 'force') {
      const k = 0.05, repel = 200, spring = 0.005, damping = 0.85, center = 0.01;
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        if (!matchesFilter(a)) continue;
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j];
          if (!matchesFilter(b)) continue;
          let dx = a.x - b.x, dy = a.y - b.y;
          let dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const f = repel / (dist * dist);
          dx /= dist; dy /= dist;
          a.vx += dx * f; a.vy += dy * f;
          b.vx -= dx * f; b.vy -= dy * f;
        }
      }
      for (const e of edges) {
        if (!matchesFilter(e.source) || !matchesFilter(e.target)) continue;
        let dx = e.target.x - e.source.x, dy = e.target.y - e.source.y;
        let dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (dist - 80) * spring;
        dx /= dist; dy /= dist;
        e.source.vx += dx * f; e.source.vy += dy * f;
        e.target.vx -= dx * f; e.target.vy -= dy * f;
      }
      for (const n of nodes) {
        if (!matchesFilter(n)) continue;
        n.vx += (W() / 2 - n.x) * center;
        n.vy += (H() / 2 - n.y) * center;
        n.vx *= damping; n.vy *= damping;
        n.x += n.vx; n.y += n.vy;
      }
      t++;
      if (t > 300) { for (const n of nodes) { n.vx = 0; n.vy = 0; } }
    } else if (!paused && currentStyle !== 'force') {
      // Animate toward target layout
      for (const n of nodes) {
        if (!matchesFilter(n)) continue;
        n.x += (n.tx - n.x) * 0.08;
        n.y += (n.ty - n.y) * 0.08;
      }
    }
    ctx.clearRect(0, 0, W(), H());
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(scale, scale);
    // Draw edges with distance-based opacity for depth perception
    for (const e of edges) {
      if (!matchesFilter(e.source) || !matchesFilter(e.target)) continue;
      const dx = e.target.x - e.source.x, dy = e.target.y - e.source.y;
      const dist = Math.sqrt(dx * dx + dy * dy) || 1;
      const opacity = Math.max(0.05, Math.min(0.3, 120 / dist));
      ctx.strokeStyle = 'rgba(148,163,184,' + opacity + ')';
      ctx.lineWidth = Math.max(0.5, Math.min(2, opacity * 3));
      ctx.beginPath();
      ctx.moveTo(e.source.x, e.source.y);
      ctx.lineTo(e.target.x, e.target.y);
      ctx.stroke();
    }
    // Draw nodes with glow effect for hovered/important nodes
    for (const n of nodes) {
      if (!matchesFilter(n)) continue;
      const color = getColor(n);
      // Glow for highly connected nodes
      if (n.connections > maxConn * 0.3) {
        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.15;
        ctx.arc(n.x, n.y, n.radius * 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
      ctx.fill();
      // Inner highlight for top-connected nodes
      if (n.connections > maxConn * 0.5) {
        ctx.beginPath();
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.arc(n.x - n.radius * 0.25, n.y - n.radius * 0.25, n.radius * 0.4, 0, Math.PI * 2);
        ctx.fill();
      }
      if (n === hoverNode || n === dragging) {
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2.5;
        ctx.stroke();
      }
    }
    // Draw labels with background to avoid overlap
    if (showLabels) {
      for (const n of nodes) {
        if (!matchesFilter(n)) continue;
        const shouldLabel = n === hoverNode || n === dragging || n.connections > maxConn * 0.15 || n.radius >= 7;
        if (!shouldLabel) continue;
        const text = n.label;
        ctx.font = n === hoverNode ? 'bold 11px sans-serif' : '10px sans-serif';
        const tw = ctx.measureText(text).width;
        const tx = n.x + n.radius + 5, ty = n.y + 3;
        // Label background
        ctx.fillStyle = 'rgba(15,23,42,0.85)';
        ctx.beginPath();
        ctx.roundRect(tx - 2, ty - 9, tw + 6, 13, 3);
        ctx.fill();
        ctx.fillStyle = n === hoverNode ? '#fff' : '#e2e8f0';
        ctx.fillText(text, tx, ty);
      }
    }
    // Hover tooltip
    if (hoverNode) {
      const tip = hoverNode.label + '\n' + hoverNode.connections + ' connections';
      const lines = tip.split('\n');
      const maxTw = Math.max(...lines.map(l => ctx.measureText(l).width));
      const tx = hoverNode.x + hoverNode.radius + 10, ty = hoverNode.y - 20;
      ctx.fillStyle = 'rgba(15,23,42,0.95)';
      ctx.strokeStyle = 'rgba(148,163,184,0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(tx - 6, ty - 6, maxTw + 14, lines.length * 14 + 8, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#e2e8f0';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(lines[0], tx, ty + 10);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px sans-serif';
      if (lines[1]) ctx.fillText(lines[1], tx, ty + 24);
    }
    ctx.restore();
    if (!paused && currentStyle === 'force' && (t < 350 || dragging)) animId = requestAnimationFrame(step);
    else animId = requestAnimationFrame(step);
  }
  animId = requestAnimationFrame(step);
  canvas._graphCleanup = () => { if (resizeObserver && wrap) resizeObserver.disconnect(); if (intersectionObserver && wrap) intersectionObserver.disconnect(); if (animId) cancelAnimationFrame(animId); if (timeoutId) clearTimeout(timeoutId); };
  return {
    resetView() { scale = 1; pan = {x: 0, y: 0}; applyLayout(false); },
    zoomIn() { scale = Math.min(20, scale * 1.2); },
    zoomOut() { scale = Math.max(0.05, scale / 1.2); },
    togglePause() { paused = !paused; },
    isPaused() { return paused; },
    toggleLabels() { showLabels = !showLabels; },
    showLabels() { return showLabels; },
    setFilter(text) { filterText = text || ''; },
    setStyle(s) { currentStyle = s; applyLayout(true); }
  };
}
function renderEmpty(container, message, iconText) {
  const empty = document.createElement('div');
  empty.className = 'db-empty';
  const icon = document.createElement('div');
  icon.className = 'db-empty-icon';
  icon.textContent = iconText || '🔍';
  const msg = document.createElement('div');
  msg.textContent = message;
  empty.appendChild(icon);
  empty.appendChild(msg);
  container.appendChild(empty);
}
function renderFindingRow(classPrefix, f) {
  const sev = (f.severity || 'low').toLowerCase();
  const row = document.createElement('div');
  row.className = classPrefix + '-row';
  const sevEl = document.createElement('div');
  sevEl.className = classPrefix + '-sev ' + sev;
  const titleEl = document.createElement('div');
  titleEl.className = classPrefix + '-text';
  titleEl.textContent = f.title || f.type || f.message || 'Issue';
  const fileEl = document.createElement('div');
  fileEl.className = classPrefix + '-file';
  fileEl.textContent = f.file || 'unknown';
  row.appendChild(sevEl);
  row.appendChild(titleEl);
  row.appendChild(fileEl);
  return row;
}
function renderAnalyzeFindings(findings) {
  const list = document.getElementById('analyzeFindingsList');
  if (!list) return;
  list.textContent = '';
  if (!findings || findings.length === 0) { renderEmpty(list, 'No findings yet. Run a scan to detect issues.'); return; }
  findings.slice(0, 30).forEach(f => list.appendChild(renderFindingRow('analyze-finding', f)));
}
/* Report Pane Interactivity */
let _reportFindings = [];
function updateReportSeverityBar(sev) {
  const total = (sev.critical || 0) + (sev.high || 0) + (sev.medium || 0) + (sev.low || 0);
  if (total === 0) return;
  const c = document.getElementById('reportSevCritical'), h = document.getElementById('reportSevHigh'), m = document.getElementById('reportSevMedium'), l = document.getElementById('reportSevLow');
  if (c) { c.style.width = ((sev.critical || 0) / total * 100) + '%'; c.textContent = (sev.critical || 0) > 0 ? (sev.critical || 0) : ''; }
  if (h) { h.style.width = ((sev.high || 0) / total * 100) + '%'; h.textContent = (sev.high || 0) > 0 ? (sev.high || 0) : ''; }
  if (m) { m.style.width = ((sev.medium || 0) / total * 100) + '%'; m.textContent = (sev.medium || 0) > 0 ? (sev.medium || 0) : ''; }
  if (l) { l.style.width = ((sev.low || 0) / total * 100) + '%'; l.textContent = (sev.low || 0) > 0 ? (sev.low || 0) : ''; }
}
function renderReportFindings(findings) {
  _reportFindings = findings || [];
  const list = document.getElementById('reportFindingsList');
  if (!list) return;
  const searchInput = document.getElementById('reportSearchInput');
  const search = (searchInput && searchInput.value || '').toLowerCase();
  const sevInput = document.getElementById('reportSeverityFilter');
  const sevFilter = (sevInput && sevInput.value) || 'all';
  const catInput = document.getElementById('reportCategoryFilter');
  const catFilter = (catInput && catInput.value) || 'all';
  const filtered = _reportFindings.filter(f => {
    const sev = (f.severity || 'low').toLowerCase();
    const cat = (f.category || '').toLowerCase();
    const title = (f.title || f.type || f.message || '').toLowerCase();
    const file = (f.file || '').toLowerCase();
    if (sevFilter !== 'all' && sev !== sevFilter) return false;
    if (catFilter !== 'all' && !cat.includes(catFilter)) return false;
    if (search && !title.includes(search) && !file.includes(search)) return false;
    return true;
  });
  if (filtered.length === 0) { renderEmpty(list, 'No findings match your filters.', '📄'); return; }
  filtered.slice(0, 50).forEach(f => {
    const sev = (f.severity || 'low').toLowerCase();
    const item = document.createElement('div');
    item.className = 'report-finding-item';
    item.dataset.sev = sev;
    const header = document.createElement('div');
    header.className = 'report-finding-header';
    const sevEl = document.createElement('div');
    sevEl.className = 'report-finding-sev ' + sev;
    const titleEl = document.createElement('div');
    titleEl.className = 'report-finding-title';
    titleEl.textContent = f.title || f.type || f.message || 'Issue';
    header.appendChild(sevEl);
    header.appendChild(titleEl);
    const meta = document.createElement('div');
    meta.className = 'report-finding-meta';
    const fileSpan = document.createElement('span');
    fileSpan.textContent = (f.file || 'unknown') + (f.line ? ':' + f.line : '');
    const catSpan = document.createElement('span');
    catSpan.textContent = f.category || 'General';
    const sevSpan = document.createElement('span');
    sevSpan.textContent = sev.toUpperCase();
    meta.appendChild(fileSpan);
    meta.appendChild(catSpan);
    meta.appendChild(sevSpan);
    item.appendChild(header);
    item.appendChild(meta);
    if (f.description || f.detail) {
      const detail = document.createElement('div');
      detail.className = 'report-finding-detail';
      detail.textContent = f.description || f.detail;
      item.appendChild(detail);
    }
    item.addEventListener('click', () => item.classList.toggle('expanded'));
    list.appendChild(item);
  });
}
function renderReportFiles(files) {
  const grid = document.getElementById('reportFilesGrid');
  if (!grid) return;
  grid.textContent = '';
  if (!files || files.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'db-empty';
    empty.style.gridColumn = '1/-1';
    const icon = document.createElement('div');
    icon.className = 'db-empty-icon';
    icon.textContent = '📄';
    const msg = document.createElement('div');
    msg.textContent = 'No file data available.';
    empty.appendChild(icon);
    empty.appendChild(msg);
    grid.appendChild(empty);
    return;
  }
  files.slice(0, 30).forEach(f => {
    const issues = f.issues || f.issueCount || 0;
    const card = document.createElement('div');
    card.className = 'report-file-card';
    const name = document.createElement('div');
    name.className = 'report-file-name';
    name.textContent = f.name || f.path || 'unknown';
    const meta = document.createElement('div');
    meta.className = 'report-file-meta';
    meta.textContent = (f.language || f.type || 'unknown') + ' · ' + issues + ' issue' + (issues === 1 ? '' : 's');
    card.appendChild(name);
    card.appendChild(meta);
    grid.appendChild(card);
  });
}
function renderReportCategories(findings) {
  const list = document.getElementById('reportCategoryList');
  if (!list) return;
  list.textContent = '';
  if (!findings || findings.length === 0) { renderEmpty(list, 'No category data available.', '📄'); return; }
  const counts = {};
  findings.forEach(f => { const c = f.category || 'General'; counts[c] = (counts[c] || 0) + 1; });
  const total = findings.length;
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  entries.forEach(([cat, count]) => {
    const pct = Math.round((count / total) * 100);
    const item = document.createElement('div');
    item.className = 'report-category-item';
    const header = document.createElement('div');
    header.className = 'report-category-header';
    const name = document.createElement('span');
    name.className = 'report-category-name';
    name.textContent = cat;
    const cnt = document.createElement('span');
    cnt.className = 'report-category-count';
    cnt.textContent = String(count);
    header.appendChild(name);
    header.appendChild(cnt);
    const bar = document.createElement('div');
    bar.className = 'report-category-bar';
    const fill = document.createElement('div');
    fill.className = 'report-category-fill';
    fill.style.width = pct + '%';
    bar.appendChild(fill);
    item.appendChild(header);
    item.appendChild(bar);
    list.appendChild(item);
  });
}
function updateReportTimestamp() {
  const el = document.getElementById('reportTimestamp');
  if (el) el.textContent = 'Last scan: ' + new Date().toLocaleString();
}
document.querySelectorAll('.report-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.report-tab').forEach(t => t.classList.toggle('active', t === tab));
    const sectionId = tab.dataset.section;
    document.querySelectorAll('.report-section').forEach(s => s.classList.toggle('active', s.id === sectionId));
  });
});
const reportSearchInput = document.getElementById('reportSearchInput');
if (reportSearchInput) reportSearchInput.addEventListener('input', () => renderReportFindings(_reportFindings));
const reportSeverityFilter = document.getElementById('reportSeverityFilter');
if (reportSeverityFilter) reportSeverityFilter.addEventListener('change', () => renderReportFindings(_reportFindings));
const reportCategoryFilter = document.getElementById('reportCategoryFilter');
if (reportCategoryFilter) reportCategoryFilter.addEventListener('change', () => renderReportFindings(_reportFindings));
const reportClearFiltersBtn = document.getElementById('reportClearFiltersBtn');
if (reportClearFiltersBtn) {
  reportClearFiltersBtn.addEventListener('click', () => {
    if (reportSearchInput) reportSearchInput.value = '';
    if (reportSeverityFilter) reportSeverityFilter.value = 'all';
    if (reportCategoryFilter) reportCategoryFilter.value = 'all';
    renderReportFindings(_reportFindings);
  });
}
const reportRefreshBtn = document.getElementById('reportRefreshBtn');
if (reportRefreshBtn) reportRefreshBtn.addEventListener('click', () => vscode.postMessage({ command: 'refreshReport' }));
const reportExportBtn = document.getElementById('reportExportBtn');
if (reportExportBtn) reportExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReport' }));
const reportExportJsonBtn = document.getElementById('reportExportJsonBtn');
if (reportExportJsonBtn) reportExportJsonBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReport' }));
const reportExportPdfBtn = document.getElementById('reportExportPdfBtn');
if (reportExportPdfBtn) reportExportPdfBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReportPdf' }));
const reportExportExcelBtn = document.getElementById('reportExportExcelBtn');
if (reportExportExcelBtn) reportExportExcelBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReportExcel' }));
const certGenerateBtn = document.getElementById('certGenerateBtn');
if (certGenerateBtn) certGenerateBtn.addEventListener('click', () => vscode.postMessage({ command: 'generateCertificate' }));
const certExportPdfBtn = document.getElementById('certExportPdfBtn');
if (certExportPdfBtn) certExportPdfBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportReportPdf' }));
const certViewReportBtn = document.getElementById('certViewReportBtn');
if (certViewReportBtn) certViewReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const certSettingsBtn = document.getElementById('certSettingsBtn');
if (certSettingsBtn) certSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const mapGenerateBtn = document.getElementById('mapGenerateBtn');
if (mapGenerateBtn) mapGenerateBtn.addEventListener('click', () => vscode.postMessage({ command: 'generateCodeMap' }));
const mapExportBtn = document.getElementById('mapExportBtn');
if (mapExportBtn) mapExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportCodeMap' }));
const mapOpenHtmlBtn = document.getElementById('mapOpenHtmlBtn');
if (mapOpenHtmlBtn) mapOpenHtmlBtn.addEventListener('click', () => vscode.postMessage({ command: 'openCodeMapHtml' }));
const mapRefreshBtn = document.getElementById('mapRefreshBtn');
if (mapRefreshBtn) mapRefreshBtn.addEventListener('click', () => vscode.postMessage({ command: 'refreshCodeMap' }));
const mapGenerateBtnPreview = document.getElementById('mapGenerateBtnPreview');
if (mapGenerateBtnPreview) mapGenerateBtnPreview.addEventListener('click', () => vscode.postMessage({ command: 'generateCodeMap' }));
const roadTriageBtn = document.getElementById('roadTriageBtn');
if (roadTriageBtn) roadTriageBtn.addEventListener('click', () => focusRoadmapPhase(0));
const roadShortTermBtn = document.getElementById('roadShortTermBtn');
if (roadShortTermBtn) roadShortTermBtn.addEventListener('click', () => focusRoadmapPhase(1));
const roadLongTermBtn = document.getElementById('roadLongTermBtn');
if (roadLongTermBtn) roadLongTermBtn.addEventListener('click', () => focusRoadmapPhase(2));
const roadExportBtn = document.getElementById('roadExportBtn');
if (roadExportBtn) roadExportBtn.addEventListener('click', () => exportRoadmapJson());
const aiScanBtn = document.getElementById('aiScanBtn');
if (aiScanBtn) aiScanBtn.addEventListener('click', () => vscode.postMessage({ command: 'scan', mode: 'workspace' }));
const aiExportBtn = document.getElementById('aiExportBtn');
if (aiExportBtn) aiExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportAiContext' }));
const aiReportBtn = document.getElementById('aiReportBtn');
if (aiReportBtn) aiReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const aiSettingsBtn = document.getElementById('aiSettingsBtn');
if (aiSettingsBtn) aiSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
let _uploadedFiles = [];
function renderUploadStats() {
  const total = document.getElementById('upTotal');
  const valid = document.getElementById('upValid');
  const errors = document.getElementById('upErrors');
  const score = document.getElementById('upScore');
  const badge = document.getElementById('upStatusBadge');
  const validCount = _uploadedFiles.filter(f => f.valid).length;
  const errorCount = _uploadedFiles.filter(f => !f.valid).length;
  const pct = _uploadedFiles.length ? Math.round((validCount / _uploadedFiles.length) * 100) : 0;
  if (total) total.textContent = String(_uploadedFiles.length);
  if (valid) valid.textContent = String(validCount);
  if (errors) errors.textContent = String(errorCount);
  if (score) score.textContent = pct + '%';
  if (badge) {
    badge.textContent = errorCount > 0 ? 'Errors' : _uploadedFiles.length > 0 ? 'Ready' : 'Idle';
    badge.className = 'db-gate-badge ' + (errorCount > 0 ? 'db-gate-fail' : 'db-gate-pass');
  }
}
function renderUploadFiles() {
  const list = document.getElementById('upResultsList');
  if (!list) return;
  list.textContent = '';
  if (_uploadedFiles.length === 0) {
    const item = document.createElement('div');
    item.className = 'up-result-item';
    const icon = document.createElement('span');
    icon.className = 'up-result-icon';
    icon.textContent = '✅';
    const text = document.createElement('span');
    text.className = 'up-result-text';
    text.textContent = 'No files uploaded yet';
    const status = document.createElement('span');
    status.className = 'up-result-status';
    status.textContent = 'Ready';
    item.appendChild(icon);
    item.appendChild(text);
    item.appendChild(status);
    list.appendChild(item);
    return;
  }
  _uploadedFiles.forEach(f => {
    const item = document.createElement('div');
    item.className = 'up-result-item';
    const icon = document.createElement('span');
    icon.className = 'up-result-icon';
    icon.textContent = f.valid ? '✅' : '❌';
    const text = document.createElement('span');
    text.className = 'up-result-text';
    text.textContent = f.name + ' (' + (f.content.length || 0) + ' chars)' + (f.error ? ' — ' + f.error : '');
    const status = document.createElement('span');
    status.className = 'up-result-status';
    status.textContent = f.valid ? 'Valid' : 'Invalid';
    item.appendChild(icon);
    item.appendChild(text);
    item.appendChild(status);
    list.appendChild(item);
  });
}
function validateUploadFiles() {
  _uploadedFiles.forEach(f => {
    const ok = f.content && f.content.length > 0;
    f.valid = ok;
    f.error = ok ? '' : 'Empty file';
  });
  renderUploadFiles();
  renderUploadStats();
  vscode.postMessage({ command: 'validateUpload', fileCount: _uploadedFiles.length });
}
function scanUploadFiles() {
  if (_uploadedFiles.length === 0) {
    vscode.postMessage({ command: 'showInfo', text: 'No files to scan. Please upload files first.' });
    return;
  }
  const progress = document.getElementById('upProgressWrap');
  const fill = document.getElementById('upProgressFill');
  const label = document.getElementById('upProgressLabel');
  const pct = document.getElementById('upProgressPct');
  if (progress) progress.classList.add('active');
  if (fill) fill.style.width = '50%';
  if (label) label.textContent = 'Scanning uploaded files...';
  if (pct) pct.textContent = '50%';
  const payload = _uploadedFiles.map(f => ({ name: f.name, content: f.content }));
  vscode.postMessage({ command: 'scanUploadFiles', files: payload });
}
function clearUploadFiles() {
  _uploadedFiles = [];
  const progress = document.getElementById('upProgressWrap');
  const fill = document.getElementById('upProgressFill');
  if (progress) progress.classList.remove('active');
  if (fill) fill.style.width = '0%';
  renderUploadFiles();
  renderUploadStats();
}
function handleFileSelect(fileList) {
  if (!fileList || fileList.length === 0) return;
  const progress = document.getElementById('upProgressWrap');
  const fill = document.getElementById('upProgressFill');
  const label = document.getElementById('upProgressLabel');
  const pct = document.getElementById('upProgressPct');
  if (progress) progress.classList.add('active');
  if (fill) fill.style.width = '10%';
  if (label) label.textContent = 'Reading files...';
  if (pct) pct.textContent = '10%';
  const files = Array.from(fileList);
  let completed = 0;
  const checkDone = () => {
    completed++;
    if (fill) fill.style.width = Math.round((completed / files.length) * 90) + '%';
    if (pct) pct.textContent = Math.round((completed / files.length) * 90) + '%';
    if (completed === files.length) {
      if (progress) progress.classList.remove('active');
      if (fill) fill.style.width = '0%';
      validateUploadFiles();
    }
  };
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      const existing = _uploadedFiles.findIndex(f => f.name === file.name);
      const entry = { name: file.name, content, valid: content.length > 0, error: content.length > 0 ? '' : 'Empty file' };
      if (existing >= 0) { _uploadedFiles[existing] = entry; } else { _uploadedFiles.push(entry); }
      checkDone();
    };
    reader.onerror = () => {
      const existing = _uploadedFiles.findIndex(f => f.name === file.name);
      const entry = { name: file.name, content: '', valid: false, error: 'Read failed' };
      if (existing >= 0) { _uploadedFiles[existing] = entry; } else { _uploadedFiles.push(entry); }
      checkDone();
    };
    reader.readAsText(file);
  });
}
const upFileInput = document.getElementById('upFileInput');
const upDropzone = document.getElementById('upDropzone');
const upBrowseBtn = document.getElementById('upBrowseBtn');
const upValidateBtn = document.getElementById('upValidateBtn');
const upScanBtn = document.getElementById('upScanBtn');
const upClearBtn = document.getElementById('upClearBtn');
if (upBrowseBtn && upFileInput) upBrowseBtn.addEventListener('click', () => upFileInput.click());
if (upFileInput) upFileInput.addEventListener('change', () => { if (upFileInput.files) handleFileSelect(upFileInput.files); });
if (upDropzone) {
  upDropzone.addEventListener('click', (e) => { if (e.target !== upFileInput) upFileInput.click(); });
  upDropzone.addEventListener('dragover', (e) => { e.preventDefault(); upDropzone.classList.add('dragover'); });
  upDropzone.addEventListener('dragleave', () => { upDropzone.classList.remove('dragover'); });
  upDropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    upDropzone.classList.remove('dragover');
    if (e.dataTransfer && e.dataTransfer.files) handleFileSelect(e.dataTransfer.files);
  });
}
if (upValidateBtn) upValidateBtn.addEventListener('click', validateUploadFiles);
if (upScanBtn) upScanBtn.addEventListener('click', scanUploadFiles);
if (upClearBtn) upClearBtn.addEventListener('click', clearUploadFiles);
const audRunBtn = document.getElementById('audRunBtn');
if (audRunBtn) audRunBtn.addEventListener('click', () => vscode.postMessage({ command: 'openFullAudit' }));
const audExportBtn = document.getElementById('audExportBtn');
if (audExportBtn) audExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportAuditReport' }));
const audReportBtn = document.getElementById('audReportBtn');
if (audReportBtn) audReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const audSettingsBtn = document.getElementById('audSettingsBtn');
if (audSettingsBtn) audSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const secScanBtn = document.getElementById('secScanBtn');
if (secScanBtn) secScanBtn.addEventListener('click', () => {
  addTab('Scan', 'scanPane');
  activateTab('scanPane');
  const pw = document.getElementById('scProgressWrap');
  if (pw) pw.classList.add('active');
  vscode.postMessage({ command: 'scan' });
});
const secExportBtn = document.getElementById('secExportBtn');
if (secExportBtn) secExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportSecurityReport' }));
const secReportBtn = document.getElementById('secReportBtn');
if (secReportBtn) secReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const secSettingsBtn = document.getElementById('secSettingsBtn');
if (secSettingsBtn) secSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const trustVerifyBtn = document.getElementById('trustVerifyBtn');
if (trustVerifyBtn) trustVerifyBtn.addEventListener('click', () => vscode.postMessage({ command: 'verifyTrust' }));
const trustExportBtn = document.getElementById('trustExportBtn');
if (trustExportBtn) trustExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportTrustReport' }));
const trustReportBtn = document.getElementById('trustReportBtn');
if (trustReportBtn) trustReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const trustSettingsBtn = document.getElementById('trustSettingsBtn');
if (trustSettingsBtn) trustSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const qPathInput = document.getElementById('qPathInput');
const qBrowseBtn = document.getElementById('qBrowseBtn');
const qDetectBtn = document.getElementById('qDetectBtn');
const qModeSelect = document.getElementById('qModeSelect');
const qFullTreeCheck = document.getElementById('qFullTreeCheck');
const qRunBtn = document.getElementById('qRunBtn');
if (qBrowseBtn) qBrowseBtn.addEventListener('click', () => vscode.postMessage({ command: 'browseQualityPath' }));
if (qDetectBtn) qDetectBtn.addEventListener('click', () => vscode.postMessage({ command: 'detectQualityPath' }));
if (qRunBtn) qRunBtn.addEventListener('click', () => {
  const path = qPathInput ? qPathInput.value : '';
  const mode = qModeSelect ? qModeSelect.value : 'quality';
  const fullDirectory = qFullTreeCheck ? qFullTreeCheck.checked : true;
  vscode.postMessage({ command: 'runQualityAnalysis', path, mode, fullDirectory });
});
const qAnalyzeBtn = document.getElementById('qAnalyzeBtn');
if (qAnalyzeBtn) qAnalyzeBtn.addEventListener('click', () => {
  const path = qPathInput ? qPathInput.value : '';
  const mode = qModeSelect ? qModeSelect.value : 'quality';
  const fullDirectory = qFullTreeCheck ? qFullTreeCheck.checked : true;
  vscode.postMessage({ command: 'runQualityAnalysis', path, mode, fullDirectory });
});
const qExportBtn = document.getElementById('qExportBtn');
if (qExportBtn) qExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportQualityReport' }));
const qReportBtn = document.getElementById('qReportBtn');
if (qReportBtn) qReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const qSettingsBtn = document.getElementById('qSettingsBtn');
if (qSettingsBtn) qSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const asstRunBtn = document.getElementById('asstRunBtn');
if (asstRunBtn) asstRunBtn.addEventListener('click', () => vscode.postMessage({ command: 'openFullAssessments' }));
const asstExportBtn = document.getElementById('asstExportBtn');
if (asstExportBtn) asstExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportAssessmentsReport' }));
const asstReportBtn = document.getElementById('asstReportBtn');
if (asstReportBtn) asstReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const asstSettingsBtn = document.getElementById('asstSettingsBtn');
if (asstSettingsBtn) asstSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const platRefreshBtn = document.getElementById('platRefreshBtn');
if (platRefreshBtn) platRefreshBtn.addEventListener('click', () => vscode.postMessage({ command: 'refreshPlatform' }));
const platExportBtn = document.getElementById('platExportBtn');
if (platExportBtn) platExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportPlatformReport' }));
const platDocsBtn = document.getElementById('platDocsBtn');
if (platDocsBtn) platDocsBtn.addEventListener('click', () => vscode.postMessage({ command: 'openPlatformDocs' }));
const platSettingsBtn = document.getElementById('platSettingsBtn');
if (platSettingsBtn) platSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const compRunBtn = document.getElementById('compRunBtn');
if (compRunBtn) compRunBtn.addEventListener('click', () => vscode.postMessage({ command: 'runComplianceCheck' }));
const compExportBtn = document.getElementById('compExportBtn');
if (compExportBtn) compExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportComplianceReport' }));
const compReportBtn = document.getElementById('compReportBtn');
if (compReportBtn) compReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const compSettingsBtn = document.getElementById('compSettingsBtn');
if (compSettingsBtn) compSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const anRefreshBtn = document.getElementById('anRefreshBtn');
if (anRefreshBtn) anRefreshBtn.addEventListener('click', () => vscode.postMessage({ command: 'refreshAnalytics' }));
const anExportBtn = document.getElementById('anExportBtn');
if (anExportBtn) anExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportAnalyticsReport' }));
const anReportBtn = document.getElementById('anReportBtn');
if (anReportBtn) anReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const anSettingsBtn = document.getElementById('anSettingsBtn');
if (anSettingsBtn) anSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const tmInviteBtn = document.getElementById('tmInviteBtn');
if (tmInviteBtn) tmInviteBtn.addEventListener('click', () => vscode.postMessage({ command: 'inviteTeamMember' }));
const tmExportBtn = document.getElementById('tmExportBtn');
if (tmExportBtn) tmExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportTeamReport' }));
const tmReportBtn = document.getElementById('tmReportBtn');
if (tmReportBtn) tmReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const tmSettingsBtn = document.getElementById('tmSettingsBtn');
if (tmSettingsBtn) tmSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
const scRunBtn = document.getElementById('scRunBtn');
if (scRunBtn) scRunBtn.addEventListener('click', () => { const pw = document.getElementById('scProgressWrap'); if (pw) pw.classList.add('active'); vscode.postMessage({ command: 'runScan' }); });
const scanPathInput = document.getElementById('scanPathInput');
const scanBrowseBtn = document.getElementById('scanBrowseBtn');
const scanDetectWorkspaceBtn = document.getElementById('scanDetectWorkspaceBtn');
const scanModeSelect = document.getElementById('scanModeSelect');
const scanFullTreeCheck = document.getElementById('scanFullTreeCheck');
const scanStartBtn = document.getElementById('scanStartBtn');
if (scanBrowseBtn) scanBrowseBtn.addEventListener('click', () => vscode.postMessage({ command: 'browseScanPath' }));
if (scanDetectWorkspaceBtn) scanDetectWorkspaceBtn.addEventListener('click', () => vscode.postMessage({ command: 'detectScanWorkspacePath' }));
if (scanStartBtn) scanStartBtn.addEventListener('click', () => {
  const pw = document.getElementById('scProgressWrap');
  if (pw) pw.classList.add('active');
  const path = scanPathInput ? scanPathInput.value : '';
  const mode = scanModeSelect ? scanModeSelect.value : 'full';
  const fullDirectory = scanFullTreeCheck ? scanFullTreeCheck.checked : true;
  vscode.postMessage({ command: 'scan', path, mode, fullDirectory });
});
const scExportBtn = document.getElementById('scExportBtn');
if (scExportBtn) scExportBtn.addEventListener('click', () => vscode.postMessage({ command: 'exportScanReport' }));
const scReportBtn = document.getElementById('scReportBtn');
if (scReportBtn) scReportBtn.addEventListener('click', () => { addTab('Report','reportPane'); vscode.postMessage({ command: 'openReport' }); });
const scSettingsBtn = document.getElementById('scSettingsBtn');
if (scSettingsBtn) scSettingsBtn.addEventListener('click', () => { addTab('Settings','settingsPane'); vscode.postMessage({ command: 'openSettings' }); });
function bindToggle(id, command) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('click', () => {
    const on = el.classList.toggle('on');
    vscode.postMessage({ command: command, value: on });
  });
}
bindToggle('stAutoScanToggle', 'updateAutoScan');
const stDisplaySelect = document.getElementById('stDisplaySelect');
if (stDisplaySelect) stDisplaySelect.addEventListener('change', () => { vscode.postMessage({ command: 'updateDisplayMode', value: stDisplaySelect.value }); });
bindToggle('stBrowserToggle', 'updateBrowserMode');
bindToggle('stNotifyScanToggle', 'updateNotifyScan');
bindToggle('stNotifyGateToggle', 'updateNotifyGate');
const stSaveApiBtn = document.getElementById('stSaveApiBtn');
if (stSaveApiBtn) stSaveApiBtn.addEventListener('click', () => {
  const input = document.getElementById('stApiUrl');
  vscode.postMessage({ command: 'updateApiUrl', value: input ? input.value : '' });
});
const stTestApiBtn = document.getElementById('stTestApiBtn');
if (stTestApiBtn) stTestApiBtn.addEventListener('click', () => {
  const input = document.getElementById('stApiUrl');
  const status = document.getElementById('stApiStatus');
  if (status) { status.textContent = 'Testing...'; status.style.color = 'var(--vscode-editor-foreground)'; }
  vscode.postMessage({ command: 'testApiConnection', value: input ? input.value : '' });
});
const stResetBtn = document.getElementById('stResetBtn');
if (stResetBtn) stResetBtn.addEventListener('click', () => {
  vscode.postMessage({ command: 'resetSettings' });
});
function setSettingsStatus(text, pass) {
  const b = document.getElementById('stStatusBadge');
  if (!b) return;
  b.textContent = text;
  b.className = 'db-gate-badge ' + (pass ? 'db-gate-pass' : 'db-gate-pending');
}
function updateRepoHealthPane(data) {
  const s = document.getElementById('repoHealthScore');
  const g = document.getElementById('repoHealthGate');
  const i = document.getElementById('repoHealthIssues');
  const f = document.getElementById('repoHealthFiles');
  const dot = document.getElementById('repoHealthStatusDot');
  const status = document.getElementById('repoHealthStatusText');
  const list = document.getElementById('repoHealthFindings');
  if (s) s.textContent = data.score || '--';
  if (g) g.textContent = data.gate || '--';
  if (i) i.textContent = data.issues || '0';
  if (f) f.textContent = data.files || '0';
  if (dot) dot.className = 'db-scan-dot';
  if (status) status.textContent = 'Updated';
  const crit = document.getElementById('rhCritCount');
  const high = document.getElementById('rhHighCount');
  const med = document.getElementById('rhMedCount');
  const low = document.getElementById('rhLowCount');
  if (crit) crit.textContent = data.critical || '0';
  if (high) high.textContent = data.high || '0';
  if (med) med.textContent = data.medium || '0';
  if (low) low.textContent = data.low || '0';
  const maintFill = document.getElementById('rhMaintFill');
  const maintVal = document.getElementById('rhMaintVal');
  const relFill = document.getElementById('rhRelFill');
  const relVal = document.getElementById('rhRelVal');
  const compFill = document.getElementById('rhCompFill');
  const compVal = document.getElementById('rhCompVal');
  const dupFill = document.getElementById('rhDupFill');
  const dupVal = document.getElementById('rhDupVal');
  if (maintFill) maintFill.style.width = (data.maintainability || '0') + '%';
  if (maintVal) maintVal.textContent = (data.maintainability || '--') + '%';
  if (relFill) relFill.style.width = (data.reliability || '0') + '%';
  if (relVal) relVal.textContent = (data.reliability || '--') + '%';
  if (compFill) compFill.style.width = (data.complexity || '0') + '%';
  if (compVal) compVal.textContent = (data.complexity || '--') + '%';
  if (dupFill) dupFill.style.width = (data.duplication || '0') + '%';
  if (dupVal) dupVal.textContent = (data.duplication || '--') + '%';
  const critCount = parseInt(data.critical || '0', 10) || 0;
  const highCount = parseInt(data.high || '0', 10) || 0;
  const medCount = parseInt(data.medium || '0', 10) || 0;
  const lowCount = parseInt(data.low || '0', 10) || 0;
  const ccCard = document.getElementById('rhCritCountCard'); if (ccCard) ccCard.textContent = String(critCount);
  const hcCard = document.getElementById('rhHighCountCard'); if (hcCard) hcCard.textContent = String(highCount);
  const mcCard = document.getElementById('rhMedCountCard'); if (mcCard) mcCard.textContent = String(medCount);
  const lcCard = document.getElementById('rhLowCountCard'); if (lcCard) lcCard.textContent = String(lowCount);
  const cl = document.getElementById('rhCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
  const hl = document.getElementById('rhHighLabel'); if (hl) hl.textContent = highCount + ' High';
  const ml = document.getElementById('rhMedLabel'); if (ml) ml.textContent = medCount + ' Med';
  const ll = document.getElementById('rhLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
  const is = document.getElementById('rhInfoScore'); if (is) is.textContent = data.score || data.qualityScore || '--';
  const ii = document.getElementById('rhInfoIssues'); if (ii) ii.textContent = data.issues || '--';
  const ig = document.getElementById('rhInfoGate'); if (ig) ig.textContent = data.gate || '--';
  const recList = document.getElementById('rhRecList');
  if (recList) {
    recList.textContent = '';
    if (data.recommendations && data.recommendations.length) {
      data.recommendations.forEach(r => {
        const item = document.createElement('div');
        item.className = 'rh-rec-item';
        const icon = document.createElement('span');
        icon.className = 'rh-rec-icon';
        icon.textContent = '💡';
        const text = document.createElement('span');
        text.className = 'rh-rec-text';
        text.textContent = (r && r.text) || r || '';
        item.appendChild(icon);
        item.appendChild(text);
        recList.appendChild(item);
      });
    }
  }
  if (list) {
    list.textContent = '';
    if (!data.findings || data.findings.length === 0) {
      const p = document.createElement('p');
      p.className = 'repo-health-empty';
      p.textContent = 'No findings yet. Run a scan to detect issues.';
      list.appendChild(p);
    } else {
      data.findings.slice(0, 10).forEach(f => {
        const sev = (f.severity || 'low').toLowerCase();
        const item = document.createElement('div');
        item.className = 'repo-health-item';
        const sevEl = document.createElement('span');
        sevEl.className = 'repo-health-sev ' + sev;
        const text = document.createElement('div');
        text.className = 'repo-health-text';
        const title = document.createElement('div');
        title.textContent = f.type || f.category || 'Issue';
        const file = document.createElement('div');
        file.className = 'repo-health-file';
        file.textContent = f.file || f.filePath || f.path || '-';
        text.appendChild(title);
        text.appendChild(file);
        item.appendChild(sevEl);
        item.appendChild(text);
        list.appendChild(item);
      });
    }
  }
}
function createRoadmapPhase(title, items, total, completed) {
  const doneCount = completed || 0;
  const phase = document.createElement('div');
  phase.className = 'road-phase';
  const header = document.createElement('div');
  header.className = 'road-phase-header';
  const titleEl = document.createElement('span');
  titleEl.className = 'road-phase-title';
  titleEl.textContent = title;
  const meta = document.createElement('span');
  meta.className = 'road-phase-meta';
  meta.textContent = doneCount + ' / ' + total + ' tasks';
  header.appendChild(titleEl);
  header.appendChild(meta);
  const bar = document.createElement('div');
  bar.className = 'road-phase-bar';
  const fill = document.createElement('div');
  fill.className = 'road-phase-fill';
  fill.style.width = (total > 0 ? Math.round((doneCount / total) * 100) : 0) + '%';
  bar.appendChild(fill);
  const itemsEl = document.createElement('div');
  itemsEl.className = 'road-phase-items';
  items.forEach(f => {
    const sev = (f.severity || 'low').toLowerCase();
    const item = document.createElement('div');
    item.className = 'road-phase-item';
    const sevEl = document.createElement('div');
    sevEl.className = 'road-item-sev ' + sev;
    const text = document.createElement('div');
    text.className = 'road-item-text';
    text.textContent = f.title || f.type || 'Finding';
    const status = document.createElement('div');
    status.className = 'road-item-status';
    status.textContent = 'Open';
    item.appendChild(sevEl);
    item.appendChild(text);
    item.appendChild(status);
    itemsEl.appendChild(item);
  });
  phase.appendChild(header);
  phase.appendChild(bar);
  phase.appendChild(itemsEl);
  return phase;
}
function renderRoadmapPhases(findings) {
  const container = document.getElementById('roadPhases');
  if (!container) return;
  container.textContent = '';
  if (!findings || findings.length === 0) {
    const p = document.createElement('p');
    p.className = 'repo-health-empty';
    p.textContent = 'No findings yet. Run a scan to build the roadmap.';
    container.appendChild(p);
    return;
  }
  const critical = findings.filter(f => (f.severity || '').toLowerCase() === 'critical');
  const high = findings.filter(f => (f.severity || '').toLowerCase() === 'high');
  const medium = findings.filter(f => (f.severity || '').toLowerCase() === 'medium');
  const low = findings.filter(f => (f.severity || '').toLowerCase() === 'low');
  container.appendChild(createRoadmapPhase('Phase 1: Triage & Assessment', critical.concat(high).slice(0, 8), critical.length + high.length, 0));
  container.appendChild(createRoadmapPhase('Phase 2: Short-Term Fixes', medium.slice(0, 5), medium.length, 0));
  container.appendChild(createRoadmapPhase('Phase 3: Long-Term Architecture', low.slice(0, 5), low.length, 0));
}
function focusRoadmapPhase(index) {
  const container = document.getElementById('roadPhases');
  if (!container) return;
  const phases = container.querySelectorAll('.road-phase');
  const phase = phases[index];
  if (!phase) return;
  phase.scrollIntoView({ behavior: 'smooth', block: 'start' });
  phases.forEach(p => p.style.outline = '');
  phase.style.outline = '2px solid var(--vscode-focusBorder)';
  setTimeout(() => { phase.style.outline = ''; }, 1500);
}
function exportRoadmapJson() {
  const open = document.getElementById('roadInfoOpen');
  const risk = document.getElementById('roadInfoRisk');
  const target = document.getElementById('roadInfoTarget');
  const phases = document.querySelectorAll('#roadPhases .road-phase');
  const data = {
    open: open ? open.textContent : '--',
    risk: risk ? risk.textContent : '--',
    target: target ? target.textContent : '--',
    phases: Array.from(phases).map(p => ({
      title: p.querySelector('.road-phase-title') ? p.querySelector('.road-phase-title').textContent : '',
      meta: p.querySelector('.road-phase-meta') ? p.querySelector('.road-phase-meta').textContent : '',
      items: Array.from(p.querySelectorAll('.road-phase-item')).map(i => ({
        severity: (i.querySelector('.road-item-sev') ? i.querySelector('.road-item-sev').className : '').replace('road-item-sev ', ''),
        text: i.querySelector('.road-item-text') ? i.querySelector('.road-item-text').textContent : '',
        status: i.querySelector('.road-item-status') ? i.querySelector('.road-item-status').textContent : ''
      }))
    }))
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'simplebeacon-roadmap.json';
  a.click();
  URL.revokeObjectURL(url);
}
function renderSecurityThreats(findings) {
  const list = document.getElementById('secThreatsList');
  if (!list) return;
  list.textContent = '';
  if (!findings || findings.length === 0) return;
  findings.slice(0, 15).forEach(f => {
    const sev = (f.severity || 'low').toLowerCase();
    const item = document.createElement('div');
    item.className = 'sec-threat-item';
    const sevEl = document.createElement('div');
    sevEl.className = 'sec-threat-sev ' + sev;
    const text = document.createElement('div');
    text.className = 'sec-threat-text';
    text.textContent = f.title || f.type || 'Finding';
    const file = document.createElement('div');
    file.className = 'sec-threat-file';
    file.textContent = f.file || f.filePath || f.path || '-';
    item.appendChild(sevEl);
    item.appendChild(text);
    item.appendChild(file);
    list.appendChild(item);
  });
}
function renderComplianceRules(rules) {
  const container = document.getElementById('compRequirements');
  if (!container) return;
  container.textContent = '';
  const title = document.createElement('div');
  title.className = 'comp-req-title';
  title.textContent = 'Compliance Requirements';
  container.appendChild(title);
  if (!rules || rules.length === 0) {
    const item = document.createElement('div');
    item.className = 'comp-req-item';
    const sev = document.createElement('div');
    sev.className = 'comp-req-sev critical';
    const text = document.createElement('span');
    text.className = 'comp-req-text';
    text.textContent = 'No compliance data available';
    const status = document.createElement('span');
    status.className = 'comp-req-status';
    status.textContent = 'Pending';
    item.appendChild(sev);
    item.appendChild(text);
    item.appendChild(status);
    container.appendChild(item);
    return;
  }
  rules.forEach(r => {
    const sev = (r.severity || 'low').toLowerCase();
    const status = r.pass ? 'Pass' : 'Fail';
    const item = document.createElement('div');
    item.className = 'comp-req-item';
    const sevEl = document.createElement('div');
    sevEl.className = 'comp-req-sev ' + sev;
    const text = document.createElement('span');
    text.className = 'comp-req-text';
    text.textContent = r.text || r.id || 'Rule';
    const statusEl = document.createElement('span');
    statusEl.className = 'comp-req-status';
    statusEl.textContent = status;
    item.appendChild(sevEl);
    item.appendChild(text);
    item.appendChild(statusEl);
    container.appendChild(item);
  });
}
function createTeamMemberItem(m) {
  const avatar = (m.name || 'U').charAt(0).toUpperCase();
  const item = document.createElement('div');
  item.className = 'tm-member-item';
  const av = document.createElement('div');
  av.className = 'tm-member-avatar';
  av.textContent = avatar;
  const info = document.createElement('div');
  info.className = 'tm-member-info';
  const name = document.createElement('div');
  name.className = 'tm-member-name';
  name.textContent = m.name || 'Member';
  const role = document.createElement('div');
  role.className = 'tm-member-role';
  role.textContent = m.role || 'Member';
  info.appendChild(name);
  info.appendChild(role);
  const status = document.createElement('span');
  status.className = 'tm-member-status';
  status.textContent = m.status || 'Active';
  item.appendChild(av);
  item.appendChild(info);
  item.appendChild(status);
  return item;
}
function renderTeamMembers(members) {
  const list = document.getElementById('tmMembersList');
  if (!list) return;
  list.textContent = '';
  const title = document.createElement('div');
  title.className = 'tm-members-title';
  title.textContent = 'Team Members';
  list.appendChild(title);
  if (!members || members.length === 0) {
    const empty = createTeamMemberItem({ name: '-', role: 'Invite team members', status: '--' });
    list.appendChild(empty);
    return;
  }
  members.forEach(m => list.appendChild(createTeamMemberItem(m)));
}
window.addEventListener('message', (event) => {
  const msg = event.data;
  if (!msg || !msg.command) return;
  if (msg.command === 'showDashboardPane') addTab('Dashboard','dashboardPane');
  if (msg.command === 'showAnalyzePane') {
    addTab('Analyze','analyzePane');
    setTimeout(() => {
      const pathInput = document.getElementById('analyzePathInput');
      if (pathInput && !pathInput.value) { vscode.postMessage({ command: 'detectWorkspacePath' }); }
    }, 100);
  }
  if (msg.command === 'showReportPane') addTab('Report','reportPane');
  if (msg.command === 'showCertificatePane') addTab('Certificate','certificatePane');
  if (msg.command === 'showCodeMapPane') addTab('Code Map','codeMapPane');
  if (msg.command === 'showRoadmapPane') addTab('Roadmap','roadmapPane');
  if (msg.command === 'showAiContextPane') addTab('AI Context','aiContextPane');
  if (msg.command === 'showUploadPane') addTab('Upload','uploadPane');
  if (msg.command === 'showAuditPane') addTab('Audit','auditPane');
  if (msg.command === 'showSecurityPane') addTab('Security','securityPane');
  if (msg.command === 'showTrustPane') addTab('Trust','trustPane');
  if (msg.command === 'showQualityPane') {
    addTab('Quality','qualityPane');
    setTimeout(() => {
      const pathInput = document.getElementById('qPathInput');
      if (pathInput && !pathInput.value) { vscode.postMessage({ command: 'detectQualityPath' }); }
    }, 100);
  }
  if (msg.command === 'showAssessmentsPane') addTab('Assessments','assessmentsPane');
  if (msg.command === 'showPlatformPane') addTab('Platform','platformPane');
  if (msg.command === 'showProfilePane') addTab('Profile','profilePane');
  if (msg.command === 'showCompliancePane') addTab('Compliance','compliancePane');
  if (msg.command === 'showRepoHealthPane') addTab('Repo Health','repoHealthPane');
  if (msg.command === 'showAnalyticsPane') addTab('Analytics','analyticsPane');
  if (msg.command === 'showTeamPane') addTab('Team','teamPane');
  if (msg.command === 'showScanPane') {
    addTab('Scan','scanPane');
    setTimeout(() => {
      const pathInput = document.getElementById('scanPathInput');
      if (pathInput && !pathInput.value) { vscode.postMessage({ command: 'detectScanWorkspacePath' }); }
    }, 100);
  }
  if (msg.command === 'updateScanPane') {
    const badge = document.getElementById('scStatusBadge');
    const statusText = document.getElementById('scStatusText');
    const statusDot = document.getElementById('scStatusDot');
    const statusMeta = document.getElementById('scStatusMeta');
    const progressWrap = document.getElementById('scProgressWrap');
    const progressFill = document.getElementById('scProgressFill');
    const progressPct = document.getElementById('scProgressPct');
    const progressLabel = document.getElementById('scProgressLabel');
    const resultsWrap = document.getElementById('scResultsWrap');
    const summary = document.getElementById('scSummary');
    const status = msg.status || 'Idle';
    const scanning = !!msg.scanning;
    const hasResults = !!msg.hasResults;
    const progress = parseInt(msg.progress, 10) || 0;
    if (badge) {
      badge.textContent = status.toUpperCase();
      badge.className = 'db-gate-badge ' + (status === 'Complete' || status === 'Pass' ? 'db-gate-pass' : status === 'Fail' ? 'db-gate-fail' : 'db-gate-pending');
    }
    if (statusText) statusText.textContent = scanning ? 'Scanning...' : status;
    if (statusDot) statusDot.className = 'sc-status-dot ' + (scanning ? 'running' : status === 'Complete' ? 'complete' : status === 'Fail' ? 'error' : '');
    if (statusMeta) statusMeta.textContent = scanning ? (progress + '%') : (status === 'Complete' ? 'Scan complete' : 'No active scan');
    if (progressWrap) progressWrap.className = 'sc-progress' + (scanning || (progress > 0 && progress < 100) ? ' active' : '');
    if (progressFill) progressFill.style.width = progress + '%';
    if (progressPct) progressPct.textContent = progress + '%';
    if (progressLabel) progressLabel.textContent = scanning ? 'Scanning...' : 'Scan progress';
    const totalEl = document.getElementById('scTotal');
    const issuesEl = document.getElementById('scIssues');
    const fixedEl = document.getElementById('scFixed');
    const scoreEl = document.getElementById('scScore');
    if (totalEl) totalEl.textContent = msg.total || '--';
    if (issuesEl) issuesEl.textContent = msg.issues || '--';
    if (fixedEl) fixedEl.textContent = msg.fixed || '--';
    if (scoreEl) scoreEl.textContent = msg.score || msg.qualityScore || '--';
    const critEl = document.getElementById('scCritCount');
    const highEl = document.getElementById('scHighCount');
    const medEl = document.getElementById('scMedCount');
    const lowEl = document.getElementById('scLowCount');
    if (critEl) critEl.textContent = msg.critical || '0';
    if (highEl) highEl.textContent = msg.high || '0';
    if (medEl) medEl.textContent = msg.medium || '0';
    if (lowEl) lowEl.textContent = msg.low || '0';
    const resultsList = document.getElementById('scResultsList');
    if (resultsList && msg.results && Array.isArray(msg.results)) {
      resultsList.textContent = '';
      if (msg.results.length === 0) {
        const empty = document.createElement('div'); empty.className = 'sc-result-item';
        const t1 = document.createElement('span'); t1.className = 'sc-result-type'; t1.textContent = '--';
        const t2 = document.createElement('span'); t2.className = 'sc-result-text'; t2.textContent = 'No scan results yet';
        const t3 = document.createElement('span'); t3.className = 'sc-result-badge pending'; t3.textContent = 'Pending';
        const t4 = document.createElement('span'); t4.className = 'sc-result-file'; t4.textContent = '--';
        empty.append(t1, t2, t3, t4); resultsList.appendChild(empty);
      } else {
        msg.results.forEach((r) => {
          const item = document.createElement('div'); item.className = 'sc-result-item'; item.style.cursor = 'pointer';
          const sev = (r.severity || 'low').toLowerCase();
          const t1 = document.createElement('span'); t1.className = 'sc-result-type'; t1.textContent = r.type || 'Finding';
          const t2 = document.createElement('span'); t2.className = 'sc-result-text'; t2.textContent = r.text || r.message || 'Finding';
          const t3 = document.createElement('span'); t3.className = 'sc-result-badge ' + sev; t3.textContent = r.severity || 'Low';
          const t4 = document.createElement('span'); t4.className = 'sc-result-file'; t4.textContent = (r.file || 'unknown') + (r.line != null ? ':' + r.line : '');
          item.append(t1, t2, t3, t4);
          item.addEventListener('click', () => {
            if (window.vscode) window.vscode.postMessage({ command: 'openFileAtLine', file: r.file, line: r.line != null ? r.line : 1 });
          });
          resultsList.appendChild(item);
        });
      }
    }
    if (resultsWrap) resultsWrap.className = 'sc-results' + (hasResults ? ' active' : '');
    const historyList = document.getElementById('scHistoryList');
    if (historyList && msg.history && Array.isArray(msg.history)) {
      historyList.textContent = '';
      if (msg.history.length === 0) {
        const empty = document.createElement('div'); empty.className = 'sc-history-item';
        const i1 = document.createElement('span'); i1.className = 'sc-history-icon'; i1.textContent = '🔍';
        const i2 = document.createElement('span'); i2.className = 'sc-history-text'; i2.textContent = 'No scan history available';
        const i3 = document.createElement('span'); i3.className = 'sc-history-time'; i3.textContent = '--';
        const i4 = document.createElement('span'); i4.className = 'sc-history-score'; i4.textContent = '--';
        empty.append(i1, i2, i3, i4); historyList.appendChild(empty);
      } else {
        msg.history.forEach((h) => {
          const item = document.createElement('div'); item.className = 'sc-history-item';
          const i1 = document.createElement('span'); i1.className = 'sc-history-icon'; i1.textContent = '🔍';
          const i2 = document.createElement('span'); i2.className = 'sc-history-text'; i2.textContent = h.text || 'Scan';
          const i3 = document.createElement('span'); i3.className = 'sc-history-time'; i3.textContent = h.time || '--';
          const i4 = document.createElement('span'); i4.className = 'sc-history-score'; i4.textContent = h.score || '--';
          item.append(i1, i2, i3, i4); historyList.appendChild(item);
        });
      }
    }
    if (summary) summary.style.display = hasResults ? 'none' : 'block';
  }
  if (msg.command === 'updateAnalyzePane') {
    const results = document.getElementById('analyzeResults');
    const progressWrap = document.getElementById('analyzeProgressWrap');
    const runBtn = document.getElementById('analyzeRunBtn');
    if (runBtn && runBtn.dataset.intervalId) {
      clearInterval(Number(runBtn.dataset.intervalId));
      delete runBtn.dataset.intervalId;
    }
    if (progressWrap) progressWrap.style.display = 'none';
    if (results) results.style.display = 'block';
    const scoreEl = document.getElementById('analyzeMetricScore');
    const gateEl = document.getElementById('analyzeMetricGate');
    const issuesEl = document.getElementById('analyzeMetricIssues');
    const filesEl = document.getElementById('analyzeMetricFiles');
    if (scoreEl) scoreEl.textContent = msg.score || '--';
    if (gateEl) gateEl.textContent = msg.gate || '--';
    if (issuesEl) issuesEl.textContent = msg.issues || '0';
    if (filesEl) filesEl.textContent = msg.files || '0';
    updateAnalyzeSeverityBar(msg.severity || {});
    const findingsList = document.getElementById('analyzeFindingsList');
    if (findingsList) {
      findingsList.textContent = '';
      if (!msg.findings || !Array.isArray(msg.findings) || msg.findings.length === 0) {
        const wrap = document.createElement('div'); wrap.className = 'db-empty';
        const icon = document.createElement('div'); icon.className = 'db-empty-icon'; icon.textContent = '🔍';
        const txt = document.createElement('div'); txt.textContent = 'No findings match the current filters.';
        wrap.append(icon, txt); findingsList.appendChild(wrap);
      } else {
        msg.findings.forEach((f) => {
          const item = document.createElement('div'); item.className = 'db-finding-item';
          const sev = (f.severity || 'low').toLowerCase();
          const sevSpan = document.createElement('span'); sevSpan.className = 'db-finding-severity ' + sev;
          const body = document.createElement('div'); body.className = 'db-finding-body';
          const title = document.createElement('div'); title.className = 'db-finding-title'; title.textContent = f.type || 'Finding';
          const desc = document.createElement('div'); desc.className = 'db-finding-desc'; desc.textContent = f.text || f.message || 'Finding';
          const fileDiv = document.createElement('div'); fileDiv.className = 'db-finding-file'; fileDiv.textContent = f.file || 'unknown';
          body.append(title, desc, fileDiv); item.append(sevSpan, body); findingsList.appendChild(item);
        });
      }
    }
  }
  if (msg.command === 'updateProfilePane') {
    const name = document.getElementById('profileName');
    const email = document.getElementById('profileEmail');
    const role = document.getElementById('profileRole');
    const org = document.getElementById('profileOrg');
    if (name) name.value = msg.name || '';
    if (email) email.value = msg.email || '';
    if (role) role.value = msg.role || '';
    if (org) org.value = msg.org || '';
    const scans = document.getElementById('profileScans');
    const reports = document.getElementById('profileReports');
    const issues = document.getElementById('profileIssues');
    const avgScore = document.getElementById('profileAvgScore');
    if (scans) scans.textContent = msg.scans || '--';
    if (reports) reports.textContent = msg.reports || '--';
    if (issues) issues.textContent = msg.issues || '--';
    if (avgScore) avgScore.textContent = msg.avgScore || '--';
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('profCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('profHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('profMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('profLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('profCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('profHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('profMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('profLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('profInfoScore'); if (is) is.textContent = msg.qualityScore || '--';
    const ii = document.getElementById('profInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const ig = document.getElementById('profInfoGate'); if (ig) ig.textContent = msg.gate || '--';
    const autoScanToggle = document.getElementById('profileAutoScanToggle');
    const notifyToggle = document.getElementById('profileNotifyToggle');
    const darkToggle = document.getElementById('profileDarkToggle');
    if (autoScanToggle) { if (msg.autoScan) autoScanToggle.classList.add('on'); else autoScanToggle.classList.remove('on'); }
    if (notifyToggle) { if (msg.notifications) notifyToggle.classList.add('on'); else notifyToggle.classList.remove('on'); }
    if (darkToggle) { if (msg.darkMode) darkToggle.classList.add('on'); else darkToggle.classList.remove('on'); }
    const activityList = document.getElementById('profileActivityList');
    if (activityList && msg.activity && Array.isArray(msg.activity)) {
      activityList.textContent = '';
      msg.activity.forEach(a => {
        const item = document.createElement('div');
        item.className = 'profile-activity-item';
        const icon = document.createElement('span');
        icon.className = 'profile-activity-icon';
        icon.textContent = a.icon || '🔍';
        const text = document.createElement('span');
        text.className = 'profile-activity-text';
        text.textContent = a.text || '';
        const time = document.createElement('span');
        time.className = 'profile-activity-time';
        time.textContent = a.time || '--';
        item.appendChild(icon);
        item.appendChild(text);
        item.appendChild(time);
        activityList.appendChild(item);
      });
    }
  }
  if (msg.command === 'showSettingsPane') addTab('Settings','settingsPane');
  if (msg.command === 'updateDashboard') {
    const s = document.getElementById('statScore');
    const g = document.getElementById('statGate');
    const i = document.getElementById('statIssues');
    const f = document.getElementById('statFiles');
    const b = document.getElementById('dashGateBadge');
    const dot = document.getElementById('dashScanDot');
    const status = document.getElementById('dashScanStatus');
    const tScore = document.getElementById('trendScore');
    const tGate = document.getElementById('trendGate');
    const tIssues = document.getElementById('trendIssues');
    const tFiles = document.getElementById('trendFiles');
    if (s) s.textContent = msg.score || '--';
    if (g) g.textContent = msg.gate || '--';
    if (i) i.textContent = msg.issues || '0';
    if (f) f.textContent = msg.files || '0';
    if (b) {
      b.textContent = (msg.gate || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.gate === 'Pass' || msg.gate === 'pass') ? 'db-gate-pass' : (msg.gate === 'Fail' || msg.gate === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    if (dot) { dot.className = 'db-scan-dot complete'; }
    if (status) { status.textContent = 'Scan complete'; }
    if (tScore) { tScore.textContent = msg.score ? 'Score updated' : 'No data'; }
    if (tGate) { tGate.textContent = msg.gate ? 'Gate: ' + msg.gate : 'Run a scan'; }
    if (tIssues) { tIssues.textContent = msg.issues ? msg.issues + ' issues found' : 'Waiting...'; }
    if (tFiles) { tFiles.textContent = msg.files ? msg.files + ' files indexed' : 'Indexed'; }
    if (msg.severity) updateSeverityBar(msg.severity);
    if (msg.findings) renderFindings(msg.findings);
    updateRepoHealthPane(msg);
  }
  if (msg.command === 'updateAnalyzePane') {
    const results = document.getElementById('analyzeResults');
    if (results) results.style.display = 'block';
    const s = document.getElementById('analyzeMetricScore');
    const g = document.getElementById('analyzeMetricGate');
    const i = document.getElementById('analyzeMetricIssues');
    const f = document.getElementById('analyzeMetricFiles');
    const gateText = typeof msg.gate === 'object' && msg.gate !== null ? (msg.gate.pass ? 'PASS' : 'FAIL') : (msg.gate || 'PENDING');
    if (s) s.textContent = msg.score || '--';
    if (g) g.textContent = gateText;
    if (i) i.textContent = msg.issues || '0';
    if (f) f.textContent = msg.files || '0';
    if (msg.severity) updateAnalyzeSeverityBar(msg.severity);
    if (msg.findings) renderAnalyzeFindings(msg.findings);
    const wrap = document.getElementById('analyzeProgressWrap');
    const fill = document.getElementById('analyzeProgressFill');
    const pct = document.getElementById('analyzeProgressPct');
    const runBtn = document.getElementById('analyzeRunBtn');
    if (runBtn && runBtn.dataset.intervalId) { clearInterval(Number(runBtn.dataset.intervalId)); delete runBtn.dataset.intervalId; }
    if (wrap) wrap.style.display = 'none';
    if (fill) fill.style.width = '0%';
    if (pct) pct.textContent = '0%';
  }
  if (msg.command === 'updateReportPane') {
    const s = document.getElementById('reportScore');
    const g = document.getElementById('reportGate');
    const i = document.getElementById('reportIssues');
    const f = document.getElementById('reportFiles');
    const b = document.getElementById('reportGateBadge');
    if (s) s.textContent = msg.score || '--';
    if (g) g.textContent = msg.gate || '--';
    if (i) i.textContent = msg.issues || '0';
    if (f) f.textContent = msg.files || '0';
    if (b) {
      b.textContent = (msg.gate || 'Pending').toUpperCase();
      b.className = 'analyze-build-badge ' + ((msg.gate === 'Pass' || msg.gate === 'pass') ? 'db-gate-pass' : (msg.gate === 'Fail' || msg.gate === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('reportCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('reportHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('reportMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('reportLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('reportCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('reportHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('reportMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('reportLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const rf = document.getElementById('reportRepoFiles'); if (rf) rf.textContent = msg.files || '--';
    const gc = document.getElementById('reportGateChecked'); if (gc) gc.textContent = msg.gate || '--';
    const ls = document.getElementById('reportLastScan'); if (ls) ls.textContent = msg.lastAnalysis || new Date().toLocaleString();
    if (msg.severity) updateReportSeverityBar(msg.severity);
    if (msg.findings) {
      renderReportFindings(msg.findings);
      renderReportCategories(msg.findings);
    }
    if (msg.filesList !== undefined) renderReportFiles(msg.filesList);
    updateReportTimestamp();
  }
  if (msg.command === 'updateCertificatePane') {
    const s = document.getElementById('certScore');
    const m = document.getElementById('certModules');
    const d = document.getElementById('certDate');
    const e = document.getElementById('certExpiry');
    const b = document.getElementById('certStatusBadge');
    if (s) s.textContent = msg.score || '--';
    if (m) m.textContent = msg.modules || '--';
    if (d) d.textContent = msg.date || '--';
    if (e) e.textContent = msg.expiry || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('certCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('certHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('certMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('certLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('certCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('certHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('certMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('certLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const rf = document.getElementById('certRepoFiles'); if (rf) rf.textContent = msg.modules || '--';
    const gc = document.getElementById('certGateChecked'); if (gc) gc.textContent = msg.gate || '--';
    const ls = document.getElementById('certLastScan'); if (ls) ls.textContent = msg.date || new Date().toLocaleString();
    if (msg.requirements && Array.isArray(msg.requirements)) {
      const list = document.getElementById('certReqList');
      if (list) {
        list.textContent = '';
        msg.requirements.forEach(req => {
          const status = req.status || 'Pending';
          const icon = status === 'Pass' || status === 'pass' ? '✓' : status === 'Fail' || status === 'fail' ? '✗' : '…';
          const cls = status === 'Pass' || status === 'pass' ? 'pass' : status === 'Fail' || status === 'fail' ? 'fail' : 'pending';
          const item = document.createElement('div');
          item.className = 'cert-req-item';
          const check = document.createElement('div');
          check.className = 'cert-req-check ' + cls;
          check.textContent = icon;
          const text = document.createElement('div');
          text.className = 'cert-req-text';
          text.textContent = req.text || '';
          const statusEl = document.createElement('div');
          statusEl.className = 'cert-req-status';
          statusEl.textContent = status;
          item.appendChild(check);
          item.appendChild(text);
          item.appendChild(statusEl);
          list.appendChild(item);
        });
      }
    }
    if (msg.previewText) {
      const preview = document.querySelector('.cert-preview-text');
      if (preview) preview.textContent = msg.previewText;
    }
  }
  if (msg.command === 'updateCodeMapPane') {
    const f = document.getElementById('mapFiles');
    const l = document.getElementById('mapLanguages');
    const m = document.getElementById('mapModules');
    const d = document.getElementById('mapDeps');
    const b = document.getElementById('mapStatusBadge');
    if (f) f.textContent = msg.files || '--';
    if (l) l.textContent = msg.languages || '--';
    if (m) m.textContent = msg.modules || '--';
    if (d) d.textContent = String(msg.graph?.edges?.length || 0);
    if (b) {
      const status = msg.status || 'Not Generated';
      const state = (status === 'Generated' || status === 'generated') ? 'generated' : (status === 'Fail' || status === 'fail') ? 'fail' : 'pending';
      b.textContent = status.toUpperCase();
      b.className = 'map-status-badge ' + state;
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('mapCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('mapHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('mapMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('mapLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('mapCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('mapHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('mapMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('mapLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const rf = document.getElementById('mapRepoFiles'); if (rf) rf.textContent = msg.repoFiles || msg.files || '--';
    const tl = document.getElementById('mapTotalLines'); if (tl) tl.textContent = msg.totalLines || '--';
    const ls = document.getElementById('mapLastScan'); if (ls) ls.textContent = msg.lastScan || new Date().toLocaleString();
    const treeList = document.getElementById('mapTreeList');
    if (treeList && msg.tree && Array.isArray(msg.tree)) {
      function renderTree(nodes, level) {
        const wrapper = document.createElement('div');
        nodes.forEach(node => {
          const icon = node.type === 'dir' ? '📁' : '📄';
          const meta = node.type === 'dir' ? 'Folder' : (node.ext || 'File');
          const lines = node.lines ? node.lines + ' lines' : '';
          const size = node.size ? (node.size > 1024 ? Math.round(node.size/1024) + ' KB' : node.size + ' B') : '';
          const info = [meta, lines, size].filter(Boolean).join(' · ');
          const cls = 'map-tree-node' + (level > 0 ? ' level-' + (level + 1) : '');
          const item = document.createElement('div');
          item.className = cls;
          const iconEl = document.createElement('span');
          iconEl.className = 'map-tree-icon';
          iconEl.textContent = icon;
          const label = document.createElement('span');
          label.className = 'map-tree-label';
          label.textContent = node.name || '';
          const metaEl = document.createElement('span');
          metaEl.className = 'map-tree-meta';
          metaEl.textContent = info;
          item.appendChild(iconEl);
          item.appendChild(label);
          item.appendChild(metaEl);
          wrapper.appendChild(item);
          if (node.children && node.children.length) wrapper.appendChild(renderTree(node.children, level + 1));
        });
        return wrapper;
      }
      treeList.textContent = '';
      treeList.appendChild(renderTree(msg.tree, 0));
    }
    /* Render dependency analysis */
    const analysisWrap = document.getElementById('mapAnalysisWrap');
    if (analysisWrap) {
      const cycles = msg.cycles || [];
      const entryPoints = msg.entryPoints || [];
      const leafModules = msg.leafModules || [];
      const mostConnected = msg.mostConnected || [];
      const cc = document.getElementById('mapCyclesCount'); if (cc) cc.textContent = String(cycles.length);
      const cl = document.getElementById('mapCyclesList'); if (cl) cl.textContent = cycles.length > 0 ? cycles.slice(0, 3).map(c => c.join(' → ')).join('; ') : 'No cycles detected';
      const ec = document.getElementById('mapEntryCount'); if (ec) ec.textContent = String(entryPoints.length);
      const el = document.getElementById('mapEntryList'); if (el) el.textContent = entryPoints.slice(0, 5).join(', ') || 'None';
      const lc2 = document.getElementById('mapLeafCount'); if (lc2) lc2.textContent = String(leafModules.length);
      const ll2 = document.getElementById('mapLeafList'); if (ll2) ll2.textContent = leafModules.slice(0, 5).join(', ') || 'None';
      const mcc = document.getElementById('mapConnectedCount'); if (mcc) mcc.textContent = String(mostConnected.length);
      const mcl = document.getElementById('mapConnectedList'); if (mcl) mcl.textContent = mostConnected.slice(0, 3).map(c => c.name + ' (' + c.count + ')').join(', ') || 'None';
    }
    /* Render languages bar chart */
    const langGrid = document.getElementById('mapLanguagesGrid');
    const langCount = document.getElementById('mapLangCount');
    if (langGrid && msg.list && Array.isArray(msg.list)) {
      const counts = {};
      msg.list.forEach(f => { const ext = f.ext || 'Other'; counts[ext] = (counts[ext] || 0) + 1; });
      const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8);
      if (entries.length > 0) {
        const max = Math.max(...entries.map(e => e[1]));
        langGrid.textContent = '';
        if (langCount) langCount.textContent = String(entries.length);
        const colors = ['#89d185','#38bdf8','#a78bfa','#f48771','#d7a24c','#007acc','#ec4899','#10b981'];
        entries.forEach(([ext, count], idx) => {
          const row = document.createElement('div');
          row.className = 'map-lang-row';
          const name = document.createElement('span');
          name.className = 'map-lang-name';
          name.textContent = ext;
          const barWrap = document.createElement('div');
          barWrap.className = 'map-lang-bar';
          const bar = document.createElement('div');
          bar.className = 'map-lang-fill';
          bar.style.width = Math.round((count / max) * 100) + '%';
          bar.style.background = colors[idx % colors.length];
          barWrap.appendChild(bar);
          const cnt = document.createElement('span');
          cnt.className = 'map-lang-count';
          cnt.textContent = String(count);
          row.appendChild(name);
          row.appendChild(barWrap);
          row.appendChild(cnt);
          langGrid.appendChild(row);
        });
      }
    }
    const graphCanvas = document.getElementById('codeMapGraphCanvas');
    const graphFrame = graphCanvas ? graphCanvas.closest('.map-graph-frame') : null;
    const graphEmpty = document.getElementById('codeMapGraphEmpty');
    const graphControls = document.getElementById('graphControls');
    if (graphCanvas && msg.graph && msg.graph.nodes && msg.graph.nodes.length > 0) {
      if (graphFrame) graphFrame.classList.add('has-graph');
      if (graphEmpty) graphEmpty.style.display = 'none';
      if (graphControls) graphControls.style.display = '';
      if (graphCanvas && graphCanvas._graphCleanup) { graphCanvas._graphCleanup(); }
      const ctrl = renderCodeMapGraph(graphCanvas, msg.graph);
      const countEl = document.getElementById('graphNodeCount');
      if (countEl && msg.graph.nodes) countEl.textContent = msg.graph.nodes.length + ' nodes';
      const resetBtn = document.getElementById('graphResetBtn');
      if (resetBtn) resetBtn.onclick = () => ctrl && ctrl.resetView && ctrl.resetView();
      const zoomInBtn = document.getElementById('graphZoomInBtn');
      if (zoomInBtn) zoomInBtn.onclick = () => ctrl && ctrl.zoomIn && ctrl.zoomIn();
      const zoomOutBtn = document.getElementById('graphZoomOutBtn');
      if (zoomOutBtn) zoomOutBtn.onclick = () => ctrl && ctrl.zoomOut && ctrl.zoomOut();
      const pauseBtn = document.getElementById('graphPauseBtn');
      if (pauseBtn) {
        pauseBtn.onclick = () => {
          if (!ctrl) return;
          ctrl.togglePause && ctrl.togglePause();
          pauseBtn.textContent = ctrl.isPaused() ? '▶' : '⏸';
        };
        pauseBtn.textContent = ctrl && ctrl.isPaused && ctrl.isPaused() ? '▶' : '⏸';
      }
      const labelsBtn = document.getElementById('graphLabelsBtn');
      if (labelsBtn) {
        labelsBtn.onclick = () => {
          if (!ctrl) return;
          ctrl.toggleLabels && ctrl.toggleLabels();
          labelsBtn.classList.toggle('active', ctrl.showLabels());
        };
        labelsBtn.classList.toggle('active', ctrl && ctrl.showLabels && ctrl.showLabels());
      }
      const searchInput = document.getElementById('graphSearchInput');
      if (searchInput) {
        searchInput.oninput = () => {
          if (ctrl && ctrl.setFilter) ctrl.setFilter(searchInput.value);
        };
      }
      const styleSelect = document.getElementById('graphStyleSelect');
      if (styleSelect) {
        styleSelect.onchange = () => {
          if (ctrl && ctrl.setStyle) ctrl.setStyle(styleSelect.value);
        };
      }
    } else {
      if (graphFrame) graphFrame.classList.remove('has-graph');
      if (graphEmpty) graphEmpty.style.display = 'flex';
      if (graphControls) graphControls.style.display = 'none';
    }
    const preview = document.getElementById('mapPreviewText');
    const previewWrap = document.getElementById('mapPreviewWrap');
    const mapContent = document.getElementById('mapContent');
    if (preview && msg.status === 'Generated') {
      preview.textContent = 'Code map generated successfully. Click Open HTML to view the full interactive map.';
    }
    if (previewWrap && msg.status === 'Generated') {
      previewWrap.style.display = 'none';
    }
    if (mapContent) {
      mapContent.style.display = (msg.status === 'Generated' || msg.status === 'generated') ? 'grid' : 'none';
    }
  }
  if (msg.command === 'showTrustPane') {
    addTab('Trust', 'trustPane');
  }
  if (msg.command === 'updateTrustPane') {
    const s = document.getElementById('trustScore');
    const v = document.getElementById('trustVerified');
    const w = document.getElementById('trustWarnings');
    const la = document.getElementById('trustLastAudit');
    const b = document.getElementById('trustStatusBadge');
    if (s) s.textContent = msg.trustScore || '--';
    if (v) v.textContent = msg.verified || '--';
    if (w) w.textContent = msg.warnings || '0';
    if (la) la.textContent = msg.lastAudit || '--';
    if (b) {
      const status = msg.status || 'Unverified';
      b.textContent = status.toUpperCase();
      b.className = 'db-gate-badge ' + ((status === 'Verified' || status === 'verified') ? 'db-gate-pass' : (status === 'Failed' || status === 'failed') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('trustCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('trustHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('trustMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('trustLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('trustCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('trustHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('trustMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('trustLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('trustInfoScore'); if (is) is.textContent = msg.trustScore || '--';
    const iv = document.getElementById('trustInfoVerified'); if (iv) iv.textContent = msg.verified || '--';
    const iw = document.getElementById('trustInfoWarnings'); if (iw) iw.textContent = msg.warnings || '0';
    const rs = document.getElementById('trustRingScore'); if (rs) rs.textContent = msg.trustScore || '--';
    const ring = document.getElementById('trustRing');
    const trustScoreNum = (msg.trustScore && msg.trustScore !== '--') ? parseInt(msg.trustScore, 10) : null;
    if (ring && trustScoreNum != null && !isNaN(trustScoreNum)) {
      ring.style.borderColor = trustScoreNum >= 80 ? '#89d185' : trustScoreNum >= 50 ? '#f59e0b' : '#f48771';
    }
    const quality = (msg.quality && msg.quality !== '--') ? parseInt(msg.quality, 10) : null;
    const security = (msg.security && msg.security !== '--') ? parseInt(msg.security, 10) : null;
    const compliance = (msg.compliance && msg.compliance !== '--') ? parseInt(msg.compliance, 10) : null;
    const dependencies = (msg.dependencies && msg.dependencies !== '--') ? parseInt(msg.dependencies, 10) : null;
    function setBd(id, valId, val) {
      const fill = document.getElementById(id);
      const valEl = document.getElementById(valId);
      if (fill) fill.style.width = (val != null && !isNaN(val) ? val : 0) + '%';
      if (valEl) valEl.textContent = (val != null && !isNaN(val) ? val : '--') + '%';
    }
    setBd('trustBdQuality', 'trustBdQualityVal', quality);
    setBd('trustBdSecurity', 'trustBdSecurityVal', security);
    setBd('trustBdCompliance', 'trustBdComplianceVal', compliance);
    setBd('trustBdDeps', 'trustBdDepsVal', dependencies);
    const factorsList = document.getElementById('trustFactorsList');
    if (factorsList && msg.factors && Array.isArray(msg.factors)) {
      factorsList.textContent = '';
      msg.factors.forEach(f => {
        const status = f.status || 'Pending';
        const icon = status === 'Pass' || status === 'pass' ? '✓' : status === 'Fail' || status === 'fail' ? '✗' : '…';
        const cls = status === 'Pass' || status === 'pass' ? 'pass' : status === 'Fail' || status === 'fail' ? 'fail' : 'pending';
        const item = document.createElement('div');
        item.className = 'trust-factor-item';
        const iconEl = document.createElement('span');
        iconEl.className = 'trust-factor-icon';
        iconEl.textContent = icon;
        const textEl = document.createElement('span');
        textEl.className = 'trust-factor-text';
        textEl.textContent = f.text || '';
        const statusEl = document.createElement('span');
        statusEl.className = 'trust-factor-status ' + cls;
        statusEl.textContent = status;
        item.appendChild(iconEl);
        item.appendChild(textEl);
        item.appendChild(statusEl);
        factorsList.appendChild(item);
      });
    }
    const badgesGrid = document.getElementById('trustBadgesGrid');
    if (badgesGrid && msg.badges && Array.isArray(msg.badges)) {
      badgesGrid.textContent = '';
      msg.badges.forEach(badge => {
        const item = document.createElement('div');
        item.className = 'trust-badge-item ' + (badge.unlocked ? 'unlocked' : 'locked');
        const iconEl = document.createElement('span');
        iconEl.className = 'trust-badge-icon';
        iconEl.textContent = badge.icon || '✓';
        const nameEl = document.createElement('span');
        nameEl.className = 'trust-badge-name';
        nameEl.textContent = badge.name || '';
        item.appendChild(iconEl);
        item.appendChild(nameEl);
        badgesGrid.appendChild(item);
      });
    }
  }
  if (msg.command === 'updateRoadmapPane') {
    const o = document.getElementById('roadOpen');
    const r = document.getElementById('roadRisk');
    const d = document.getElementById('roadDone');
    const t = document.getElementById('roadTarget');
    const b = document.getElementById('roadStatusBadge');
    if (o) o.textContent = msg.open || '--';
    if (r) r.textContent = msg.risk || '--';
    if (d) d.textContent = msg.done || '--';
    if (t) t.textContent = msg.target || '--';
    if (b) {
      b.textContent = (msg.status || 'Planning').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Active' || msg.status === 'active') ? 'db-gate-pass' : (msg.status === 'Blocked' || msg.status === 'blocked') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('roadCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('roadHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('roadMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('roadLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('roadCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('roadHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('roadMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('roadLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const io = document.getElementById('roadInfoOpen'); if (io) io.textContent = msg.open || '--';
    const ir = document.getElementById('roadInfoRisk'); if (ir) ir.textContent = msg.risk || '--';
    const it = document.getElementById('roadInfoTarget'); if (it) it.textContent = msg.target || '--';
    if (msg.findings) renderRoadmapPhases(msg.findings);
  }
  if (msg.command === 'updateAiContextPane') {
    const m = document.getElementById('aiModels');
    const i = document.getElementById('aiIssues');
    const s = document.getElementById('aiScore');
    const f = document.getElementById('aiFiles');
    const b = document.getElementById('aiStatusBadge');
    if (m) m.textContent = msg.models || '--';
    if (i) i.textContent = msg.issues || '--';
    if (s) s.textContent = msg.score || '--';
    if (f) f.textContent = msg.files || '--';
    if (b) {
      b.textContent = (msg.status || 'Monitoring').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Clear' || msg.status === 'clear') ? 'db-gate-pass' : (msg.status === 'Blocked' || msg.status === 'blocked' || msg.status === 'Issues Found') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('aiCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('aiHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('aiMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('aiLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('aiCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('aiHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('aiMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('aiLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const ii = document.getElementById('aiInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const is = document.getElementById('aiInfoScore'); if (is) is.textContent = msg.score || '--';
    const iff = document.getElementById('aiInfoFiles'); if (iff) iff.textContent = msg.files || '--';
    const modelsList = document.getElementById('aiModelsList');
    if (modelsList && msg.aiModels && Array.isArray(msg.aiModels)) {
      modelsList.textContent = '';
      msg.aiModels.forEach(model => {
        const item = document.createElement('div');
        item.className = 'ai-model-item';
        const icon = document.createElement('div');
        icon.className = 'ai-model-icon';
        icon.textContent = '🤖';
        const info = document.createElement('div');
        info.className = 'ai-model-info';
        const name = document.createElement('div');
        name.className = 'ai-model-name';
        name.textContent = model.name || '';
        const meta = document.createElement('div');
        meta.className = 'ai-model-meta';
        meta.textContent = model.meta || '';
        const status = document.createElement('div');
        status.className = 'ai-model-status';
        status.textContent = model.status || 'Monitoring';
        info.appendChild(name);
        info.appendChild(meta);
        item.appendChild(icon);
        item.appendChild(info);
        item.appendChild(status);
        modelsList.appendChild(item);
      });
    }
    const preview = document.getElementById('aiContextPreviewText');
    const previewWrap = document.getElementById('aiContextPreview');
    if (preview && msg.aiFindings && msg.aiFindings.length > 0) {
      preview.textContent = msg.aiFindings.length + ' AI-related patterns detected in your codebase.';
    }
    if (previewWrap && msg.aiFindings && msg.aiFindings.length > 0) {
      previewWrap.style.display = 'none';
    }
  }
  if (msg.command === 'updateUploadPane') {
    const t = document.getElementById('upTotal');
    const v = document.getElementById('upValid');
    const e = document.getElementById('upErrors');
    const s = document.getElementById('upScore');
    const b = document.getElementById('upStatusBadge');
    if (t) t.textContent = msg.total || '--';
    if (v) v.textContent = msg.valid || '--';
    if (e) e.textContent = msg.errors || '--';
    if (s) s.textContent = msg.score || '--';
    if (b) {
      b.textContent = (msg.status || 'Ready').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Complete' || msg.status === 'complete') ? 'db-gate-pass' : (msg.status === 'Error' || msg.status === 'error') ? 'db-gate-fail' : 'db-gate-pending');
    }
  }
  if (msg.command === 'updateAuditPane') {
    const v = document.getElementById('audVulns');
    const s = document.getElementById('audSecrets');
    const p = document.getElementById('audPassed');
    const sc = document.getElementById('audScore');
    const b = document.getElementById('audStatusBadge');
    if (v) v.textContent = msg.vulnerabilities || '--';
    if (s) s.textContent = msg.secrets || '--';
    if (p) p.textContent = msg.passed || '--';
    if (sc) sc.textContent = msg.score || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const critCount = parseInt(msg.critical || '0', 10);
    const highCount = parseInt(msg.high || '0', 10);
    const medCount = parseInt(msg.medium || '0', 10);
    const lowCount = parseInt(msg.low || '0', 10);
    const crit = document.getElementById('audCritCount');
    const high = document.getElementById('audHighCount');
    const med = document.getElementById('audMedCount');
    const low = document.getElementById('audLowCount');
    if (crit) crit.textContent = msg.critical || '0';
    if (high) high.textContent = msg.high || '0';
    if (med) med.textContent = msg.medium || '0';
    if (low) low.textContent = msg.low || '0';
    const cc2 = document.getElementById('audCritCount2'); if (cc2) cc2.textContent = msg.critical || '0';
    const hc2 = document.getElementById('audHighCount2'); if (hc2) hc2.textContent = msg.high || '0';
    const mc2 = document.getElementById('audMedCount2'); if (mc2) mc2.textContent = msg.medium || '0';
    const lc2 = document.getElementById('audLowCount2'); if (lc2) lc2.textContent = msg.low || '0';
    const cl = document.getElementById('audCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('audHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('audMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('audLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const iv = document.getElementById('audInfoVulns'); if (iv) iv.textContent = msg.vulnerabilities || '--';
    const is = document.getElementById('audInfoSecrets'); if (is) is.textContent = msg.secrets || '--';
    const isc = document.getElementById('audInfoScore'); if (isc) isc.textContent = msg.score || '--';
    const catSec = document.getElementById('audCatSecrets');
    const catVul = document.getElementById('audCatVulns');
    const catSmell = document.getElementById('audCatSmells');
    const catComp = document.getElementById('audCatCompliance');
    if (catSec) catSec.textContent = msg.catSecrets || '--';
    if (catVul) catVul.textContent = msg.catVulns || '--';
    if (catSmell) catSmell.textContent = msg.catSmells || '--';
    if (catComp) catComp.textContent = msg.catCompliance || '--';
    const list = document.getElementById('audFindingsList');
    if (list && msg.findings && Array.isArray(msg.findings)) {
      list.textContent = '';
      msg.findings.forEach(f => {
        const sev = (f.severity || 'low').toLowerCase();
        const cls = sev === 'critical' ? 'critical' : sev === 'high' ? 'high' : sev === 'medium' ? 'medium' : 'low';
        const item = document.createElement('div');
        item.className = 'aud-finding-item';
        const badge = document.createElement('div');
        badge.className = 'aud-finding-badge ' + cls;
        badge.textContent = sev;
        const type = document.createElement('div');
        type.className = 'aud-finding-type';
        type.textContent = f.type || '--';
        const text = document.createElement('div');
        text.className = 'aud-finding-text';
        text.textContent = f.text || f.message || '';
        const file = document.createElement('div');
        file.className = 'aud-finding-file';
        file.textContent = f.file || '--';
        item.appendChild(badge);
        item.appendChild(type);
        item.appendChild(text);
        item.appendChild(file);
        list.appendChild(item);
      });
    }
    const recList = document.getElementById('audRecList');
    if (recList && msg.recommendations && Array.isArray(msg.recommendations)) {
      recList.textContent = '';
      msg.recommendations.forEach(r => {
        const item = document.createElement('div');
        item.className = 'aud-rec-item';
        const icon = document.createElement('span');
        icon.className = 'aud-rec-icon';
        icon.textContent = '💡';
        const text = document.createElement('span');
        text.className = 'aud-rec-text';
        text.textContent = (r && r.text) || r || '';
        item.appendChild(icon);
        item.appendChild(text);
        recList.appendChild(item);
      });
    }
    const summary = document.querySelector('.aud-summary');
    if (summary && msg.findings && msg.findings.length > 0) summary.style.display = 'none';
  }
  if (msg.command === 'updateSecurityPane') {
    const c = document.getElementById('secCritical');
    const h = document.getElementById('secHigh');
    const m = document.getElementById('secMedium');
    const s = document.getElementById('secScore');
    const b = document.getElementById('secStatusBadge');
    if (c) c.textContent = msg.critical || '--';
    if (h) h.textContent = msg.high || '--';
    if (m) m.textContent = msg.medium || '--';
    if (s) s.textContent = msg.score || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const critCount = msg.critical || '0'; const highCount = msg.high || '0'; const medCount = msg.medium || '0'; const lowCount = msg.low || '0';
    const cc = document.getElementById('secCritCount'); if (cc) cc.textContent = critCount;
    const hc = document.getElementById('secHighCount'); if (hc) hc.textContent = highCount;
    const mc = document.getElementById('secMedCount'); if (mc) mc.textContent = medCount;
    const lc = document.getElementById('secLowCount'); if (lc) lc.textContent = lowCount;
    const cl = document.getElementById('secCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('secHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('secMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('secLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const rf = document.getElementById('secRepoFiles'); if (rf) rf.textContent = msg.repoFiles || '--';
    const gc = document.getElementById('secGateChecked'); if (gc) gc.textContent = msg.gateChecked || '--';
    const ls = document.getElementById('secLastScan'); if (ls) ls.textContent = msg.lastScan || '--';
    if (msg.findings && msg.findings.length > 0) {
      const emptyEl = document.getElementById('secThreatsEmpty');
      const listEl = document.getElementById('secThreatsList');
      if (emptyEl) emptyEl.style.display = 'none';
      if (listEl) listEl.style.display = 'block';
      renderSecurityThreats(msg.findings);
    } else {
      const emptyEl = document.getElementById('secThreatsEmpty');
      const listEl = document.getElementById('secThreatsList');
      if (emptyEl) emptyEl.style.display = 'block';
      if (listEl) { listEl.style.display = 'none'; listEl.textContent = ''; }
    }
  }
  if (msg.command === 'updateTrustPane') {
    const s = document.getElementById('trustScore');
    const v = document.getElementById('trustVerified');
    const w = document.getElementById('trustWarnings');
    const l = document.getElementById('trustLastAudit');
    const r = document.getElementById('trustRingScore');
    const b = document.getElementById('trustStatusBadge');
    if (s) s.textContent = msg.trustScore || '--';
    if (v) v.textContent = msg.verified || '--';
    if (w) w.textContent = msg.warnings || '--';
    if (l) l.textContent = msg.lastAudit || '--';
    if (r) r.textContent = msg.trustScore || '--';
    if (b) {
      b.textContent = (msg.status || 'Unverified').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Verified' || msg.status === 'verified') ? 'db-gate-pass' : (msg.status === 'Failed' || msg.status === 'failed') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('trustCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('trustHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('trustMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('trustLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('trustCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('trustHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('trustMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('trustLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('trustInfoScore'); if (is) is.textContent = msg.trustScore || '--';
    const iv = document.getElementById('trustInfoVerified'); if (iv) iv.textContent = msg.verified || '--';
    const iw = document.getElementById('trustInfoWarnings'); if (iw) iw.textContent = msg.warnings || '--';
    const ring = document.getElementById('trustRing');
    if (ring && msg.trustScore) {
      const scoreVal = parseInt(msg.trustScore, 10) || 0;
      const color = scoreVal >= 80 ? '#89d185' : scoreVal >= 50 ? '#d7a24c' : '#c75450';
      ring.style.borderColor = color;
    }
    const bdQuality = document.getElementById('trustBdQuality');
    const bdQualityVal = document.getElementById('trustBdQualityVal');
    const bdSecurity = document.getElementById('trustBdSecurity');
    const bdSecurityVal = document.getElementById('trustBdSecurityVal');
    const bdCompliance = document.getElementById('trustBdCompliance');
    const bdComplianceVal = document.getElementById('trustBdComplianceVal');
    const bdDeps = document.getElementById('trustBdDeps');
    const bdDepsVal = document.getElementById('trustBdDepsVal');
    if (bdQuality) bdQuality.style.width = (msg.quality || '0') + '%';
    if (bdQualityVal) bdQualityVal.textContent = (msg.quality || '--') + '%';
    if (bdSecurity) bdSecurity.style.width = (msg.security || '0') + '%';
    if (bdSecurityVal) bdSecurityVal.textContent = (msg.security || '--') + '%';
    if (bdCompliance) bdCompliance.style.width = (msg.compliance || '0') + '%';
    if (bdComplianceVal) bdComplianceVal.textContent = (msg.compliance || '--') + '%';
    if (bdDeps) bdDeps.style.width = (msg.dependencies || '0') + '%';
    if (bdDepsVal) bdDepsVal.textContent = (msg.dependencies || '--') + '%';
    const factorsList = document.getElementById('trustFactorsList');
    if (factorsList && msg.factors && Array.isArray(msg.factors)) {
      factorsList.textContent = '';
      msg.factors.forEach(f => {
        const status = f.status || 'Pending';
        const icon = status === 'Pass' || status === 'pass' ? '✅' : status === 'Fail' || status === 'fail' ? '✗' : '⏳';
        const item = document.createElement('div');
        item.className = 'trust-factor-item';
        const iconEl = document.createElement('span');
        iconEl.className = 'trust-factor-icon';
        iconEl.textContent = icon;
        const text = document.createElement('span');
        text.className = 'trust-factor-text';
        text.textContent = f.text || '';
        const statusEl = document.createElement('span');
        statusEl.className = 'trust-factor-status';
        statusEl.textContent = status;
        item.appendChild(iconEl);
        item.appendChild(text);
        item.appendChild(statusEl);
        factorsList.appendChild(item);
      });
    }
    const badgesGrid = document.getElementById('trustBadgesGrid');
    if (badgesGrid && msg.badges && Array.isArray(msg.badges)) {
      badgesGrid.textContent = '';
      msg.badges.forEach(badge => {
        const item = document.createElement('div');
        item.className = 'trust-badge-item ' + (badge.unlocked ? 'unlocked' : 'locked');
        const icon = document.createElement('span');
        icon.className = 'trust-badge-icon';
        icon.textContent = badge.icon || '✓';
        const name = document.createElement('span');
        name.className = 'trust-badge-name';
        name.textContent = badge.name || '';
        item.appendChild(icon);
        item.appendChild(name);
        badgesGrid.appendChild(item);
      });
    }
    const summary = document.querySelector('.trust-summary');
    if (summary && msg.trustScore && msg.trustScore !== '--') summary.style.display = 'none';
  }
  if (msg.command === 'updateQualityPane') {
    const scoreNum = parseInt(msg.qualityScore, 10);
    const scoreEl = document.getElementById('qScore');
    const scoreFg = document.getElementById('qScoreFg');
    if (scoreEl) scoreEl.textContent = msg.qualityScore || '--';
    if (scoreFg) {
      const pct = isNaN(scoreNum) ? 0 : Math.min(100, Math.max(0, scoreNum));
      scoreFg.setAttribute('stroke-dasharray', pct + ', 100');
      scoreFg.style.stroke = pct >= 80 ? '#89d185' : pct >= 50 ? '#f59e0b' : '#f48771';
    }
    const i = document.getElementById('qIssues');
    const c = document.getElementById('qCoverage');
    const f = document.getElementById('qFiles');
    const g = document.getElementById('qGate');
    const b = document.getElementById('qStatusBadge');
    if (i) i.textContent = msg.issues || '--';
    if (c) c.textContent = msg.coverage || '--';
    if (f) f.textContent = msg.files || '--';
    if (g) g.textContent = msg.gate || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const metrics = [
      { id: 'qMaint', fill: 'qMaintFill', value: msg.maintainability },
      { id: 'qRel', fill: 'qRelFill', value: msg.reliability },
      { id: 'qComplex', fill: 'qComplexFill', value: msg.complexity },
      { id: 'qDup', fill: 'qDupFill', value: msg.duplication }
    ];
    for (const m of metrics) {
      const el = document.getElementById(m.id);
      const fill = document.getElementById(m.fill);
      if (el) el.textContent = m.value || '--';
      if (fill) {
        const num = parseInt(m.value, 10) || 0;
        fill.style.width = num + '%';
        fill.style.background = num >= 80 ? '#89d185' : num >= 50 ? '#f59e0b' : '#f48771';
      }
    }
    const summary = document.querySelector('.q-summary');
    if (summary && msg.qualityScore && msg.qualityScore !== '--') summary.style.display = 'none';
  }
  if (msg.command === 'updateAssessmentsPane') {
    const c = document.getElementById('asstCompleted');
    const p = document.getElementById('asstPending');
    const r = document.getElementById('asstProgress');
    const t = document.getElementById('asstTotal');
    const b = document.getElementById('asstStatusBadge');
    if (c) c.textContent = msg.completed || '--';
    if (p) p.textContent = msg.pending || '--';
    if (r) r.textContent = msg.progress || '--';
    if (t) t.textContent = msg.total || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('asstCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('asstHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('asstMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('asstLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('asstCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('asstHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('asstMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('asstLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const ic = document.getElementById('asstInfoCompleted'); if (ic) ic.textContent = msg.completed || '--';
    const ip = document.getElementById('asstInfoPending'); if (ip) ip.textContent = msg.pending || '--';
    const ir = document.getElementById('asstInfoProgress'); if (ir) ir.textContent = msg.progress ? msg.progress + '%' : '--';
    const pv = document.getElementById('asstProgressVal');
    const pf = document.getElementById('asstProgressFill');
    if (pv) pv.textContent = (msg.progress || '0') + '%';
    if (pf) pf.style.width = (msg.progress || '0') + '%';
    const catSec = document.getElementById('asstCatSecurity');
    const catSecFill = document.getElementById('asstCatSecurityFill');
    const catQual = document.getElementById('asstCatQuality');
    const catQualFill = document.getElementById('asstCatQualityFill');
    const catComp = document.getElementById('asstCatCompliance');
    const catCompFill = document.getElementById('asstCatComplianceFill');
    const catDocs = document.getElementById('asstCatDocs');
    const catDocsFill = document.getElementById('asstCatDocsFill');
    if (catSec) catSec.textContent = msg.security || '--';
    if (catSecFill) catSecFill.style.width = (msg.security || '0') + '%';
    if (catQual) catQual.textContent = msg.quality || '--';
    if (catQualFill) catQualFill.style.width = (msg.quality || '0') + '%';
    if (catComp) catComp.textContent = msg.compliance || '--';
    if (catCompFill) catCompFill.style.width = (msg.compliance || '0') + '%';
    if (catDocs) catDocs.textContent = msg.documentation || '--';
    if (catDocsFill) catDocsFill.style.width = (msg.documentation || '0') + '%';
    const items = document.getElementById('asstChecklistItems');
    if (items && msg.checklist && Array.isArray(msg.checklist)) {
      items.textContent = '';
      msg.checklist.forEach(item => {
        const status = item.status || (item.checked ? 'Pass' : 'Pending');
        const row = document.createElement('div');
        row.className = 'asst-check-item';
        const box = document.createElement('span');
        box.className = 'asst-check-box' + (item.checked ? ' checked' : '');
        box.textContent = item.checked ? '✓' : '';
        const text = document.createElement('span');
        text.className = 'asst-check-text';
        text.textContent = item.text || '';
        const statusEl = document.createElement('span');
        statusEl.className = 'asst-check-status';
        statusEl.textContent = status;
        row.appendChild(box);
        row.appendChild(text);
        row.appendChild(statusEl);
        items.appendChild(row);
      });
    }
    const summary = document.querySelector('.asst-summary');
    if (summary && msg.status && msg.status !== 'Pending') summary.style.display = 'none';
  }
  if (msg.command === 'updatePlatformPane') {
    const v = document.getElementById('platVersion');
    const e = document.getElementById('platEngine');
    const u = document.getElementById('platUptime');
    const s = document.getElementById('platStatus');
    const o = document.getElementById('platOs');
    const n = document.getElementById('platNode');
    const x = document.getElementById('platExt');
    const w = document.getElementById('platWorkspace');
    const b = document.getElementById('platStatusBadge');
    if (v) v.textContent = msg.version || '--';
    if (e) e.textContent = msg.engine || '--';
    if (u) u.textContent = msg.uptime || '--';
    if (s) s.textContent = msg.status || '--';
    if (o) o.textContent = msg.os || '--';
    if (n) n.textContent = msg.node || '--';
    if (x) x.textContent = msg.ext || '--';
    if (w) w.textContent = msg.workspace || '--';
    if (b) {
      b.textContent = (msg.badge || 'Online').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.badge === 'Online' || msg.badge === 'online') ? 'db-gate-pass' : (msg.badge === 'Offline' || msg.badge === 'offline') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('platCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('platHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('platMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('platLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('platCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('platHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('platMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('platLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('platInfoScore'); if (is) is.textContent = msg.qualityScore || '--';
    const ii = document.getElementById('platInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const ig = document.getElementById('platInfoGate'); if (ig) ig.textContent = msg.gate || '--';
    const summary = document.getElementById('platSummary');
    if (summary && msg.version && msg.version !== '--') summary.style.display = 'none';
  }
  if (msg.command === 'updateCompliancePane') {
    const p = document.getElementById('compPassed');
    const f = document.getElementById('compFailed');
    const r = document.getElementById('compProgress');
    const t = document.getElementById('compTotal');
    const b = document.getElementById('compStatusBadge');
    if (p) p.textContent = msg.passed || '--';
    if (f) f.textContent = msg.failed || '--';
    if (r) r.textContent = msg.progress || '--';
    if (t) t.textContent = msg.total || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Pass' || msg.status === 'pass') ? 'db-gate-pass' : (msg.status === 'Fail' || msg.status === 'fail') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('compCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('compHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('compMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('compLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('compCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('compHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('compMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('compLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const ip = document.getElementById('compInfoPassed'); if (ip) ip.textContent = msg.passed || '--';
    const ifd = document.getElementById('compInfoFailed'); if (ifd) ifd.textContent = msg.failed || '--';
    const ir = document.getElementById('compInfoProgress'); if (ir) ir.textContent = msg.progress || '--';
    if (msg.rules) renderComplianceRules(msg.rules);
    const summary = document.getElementById('compSummary');
    if (summary && msg.status && msg.status !== 'Pending') summary.style.display = 'none';
  }
  if (msg.command === 'updateAnalyticsPane') {
    const s = document.getElementById('anScans');
    const i = document.getElementById('anIssues');
    const a = document.getElementById('anAvgScore');
    const l = document.getElementById('anLastScan');
    const t = document.getElementById('anTrend');
    const it = document.getElementById('anIssueTrend');
    const b = document.getElementById('anStatusBadge');
    if (s) s.textContent = msg.scans || '--';
    if (i) i.textContent = msg.issues || '--';
    if (a) a.textContent = msg.avgScore || '--';
    if (l) l.textContent = msg.lastScan || '--';
    if (t) t.textContent = msg.trend || '--';
    if (it) it.textContent = msg.issueTrend || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Ready' || msg.status === 'ready') ? 'db-gate-pass' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('anCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('anHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('anMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('anLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('anCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('anHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('anMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('anLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('anInfoScans'); if (is) is.textContent = msg.scans || '--';
    const ii = document.getElementById('anInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const ia = document.getElementById('anInfoScore'); if (ia) ia.textContent = msg.avgScore || '--';
    const summary = document.getElementById('anSummary');
    if (summary && msg.status && msg.status !== 'Pending') summary.style.display = 'none';
  }
  if (msg.command === 'updateTeamPane') {
    const m = document.getElementById('tmMembers');
    const s = document.getElementById('tmScans');
    const r = document.getElementById('tmResolved');
    const sc = document.getElementById('tmScore');
    const b = document.getElementById('tmStatusBadge');
    if (m) m.textContent = msg.members || '--';
    if (s) s.textContent = msg.scans || '--';
    if (r) r.textContent = msg.resolved || '--';
    if (sc) sc.textContent = msg.score || '--';
    if (b) {
      b.textContent = (msg.status || 'Pending').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Active' || msg.status === 'active') ? 'db-gate-pass' : 'db-gate-pending');
    }
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('tmCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('tmHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('tmMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('tmLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('tmCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('tmHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('tmMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('tmLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('tmInfoScore'); if (is) is.textContent = msg.qualityScore || '--';
    const ii = document.getElementById('tmInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const ig = document.getElementById('tmInfoGate'); if (ig) ig.textContent = msg.gate || '--';
    if (msg.membersList) renderTeamMembers(msg.membersList);
    const summary = document.getElementById('tmSummary');
    if (summary && msg.status && msg.status !== 'Pending') summary.style.display = 'none';
  }
  if (msg.command === 'updateScanPane') {
    const t = document.getElementById('scTotal');
    const i = document.getElementById('scIssues');
    const f = document.getElementById('scFixed');
    const s = document.getElementById('scScore');
    const b = document.getElementById('scStatusBadge');
    const pf = document.getElementById('scProgressFill');
    const pp = document.getElementById('scProgressPct');
    const pw = document.getElementById('scProgressWrap');
    const rw = document.getElementById('scResultsWrap');
    if (t) t.textContent = msg.total || '--';
    if (i) i.textContent = msg.issues || '--';
    if (f) f.textContent = msg.fixed || '--';
    if (s) s.textContent = msg.score || '--';
    if (pf) pf.style.width = (msg.progress || '0') + '%';
    if (pp) pp.textContent = (msg.progress || '0') + '%';
    if (pw) { if (msg.scanning) pw.classList.add('active'); else pw.classList.remove('active'); }
    if (rw) { if (msg.hasResults) rw.classList.add('active'); else rw.classList.remove('active'); }
    if (b) {
      b.textContent = (msg.status || 'Idle').toUpperCase();
      b.className = 'db-gate-badge ' + ((msg.status === 'Complete' || msg.status === 'complete') ? 'db-gate-pass' : (msg.status === 'Error' || msg.status === 'error') ? 'db-gate-fail' : 'db-gate-pending');
    }
    const crit = document.getElementById('scCritCount');
    const high = document.getElementById('scHighCount');
    const med = document.getElementById('scMedCount');
    const low = document.getElementById('scLowCount');
    if (crit) crit.textContent = msg.critical || '0';
    if (high) high.textContent = msg.high || '0';
    if (med) med.textContent = msg.medium || '0';
    if (low) low.textContent = msg.low || '0';
    const critCount = parseInt(msg.critical || '0', 10) || 0;
    const highCount = parseInt(msg.high || '0', 10) || 0;
    const medCount = parseInt(msg.medium || '0', 10) || 0;
    const lowCount = parseInt(msg.low || '0', 10) || 0;
    const summary = document.getElementById('scSummary');
    if (summary && msg.status && msg.status !== 'Idle') summary.style.display = 'none';
    const resultsList = document.getElementById('scResultsList');
    if (resultsList && msg.results && Array.isArray(msg.results)) {
      resultsList.textContent = '';
      msg.results.forEach(r => {
        const sev = (r.severity || 'low').toLowerCase();
        const cls = sev === 'critical' ? 'critical' : sev === 'high' ? 'high' : sev === 'medium' ? 'medium' : 'low';
        const item = document.createElement('div');
        item.className = 'sc-result-item';
        const type = document.createElement('span');
        type.className = 'sc-result-type';
        type.textContent = r.type || '--';
        const text = document.createElement('span');
        text.className = 'sc-result-text';
        text.textContent = r.text || r.message || '';
        const badge = document.createElement('span');
        badge.className = 'sc-result-badge ' + cls;
        badge.textContent = sev;
        const file = document.createElement('span');
        file.className = 'sc-result-file';
        file.textContent = r.file || '--';
        item.appendChild(type);
        item.appendChild(text);
        item.appendChild(badge);
        item.appendChild(file);
        resultsList.appendChild(item);
      });
    }
    const historyList = document.getElementById('scHistoryList');
    if (historyList && msg.history && Array.isArray(msg.history)) {
      historyList.textContent = '';
      msg.history.forEach(h => {
        const item = document.createElement('div');
        item.className = 'sc-history-item';
        const icon = document.createElement('span');
        icon.className = 'sc-history-icon';
        icon.textContent = '🔍';
        const text = document.createElement('span');
        text.className = 'sc-history-text';
        text.textContent = h.text || 'Scan';
        const time = document.createElement('span');
        time.className = 'sc-history-time';
        time.textContent = h.time || '--';
        const score = document.createElement('span');
        score.className = 'sc-history-score';
        score.textContent = h.score || '--';
        item.appendChild(icon);
        item.appendChild(text);
        item.appendChild(time);
        item.appendChild(score);
        historyList.appendChild(item);
      });
    }
  }
  if (msg.command === 'updateSettingsPane') {
    const toggles = { stAutoScanToggle: msg.autoScan, stBrowserToggle: msg.browserMode, stNotifyScanToggle: msg.notifyScan, stNotifyGateToggle: msg.notifyGate };
    for (const [id, on] of Object.entries(toggles)) {
      const el = document.getElementById(id);
      if (el) { if (on) el.classList.add('on'); else el.classList.remove('on'); }
    }
    const displaySelect = document.getElementById('stDisplaySelect');
    if (displaySelect && msg.displayMode) displaySelect.value = msg.displayMode;
    const apiInput = document.getElementById('stApiUrl');
    if (apiInput && msg.apiUrl) apiInput.value = msg.apiUrl;
    const sev = msg.severity || {};
    const critCount = sev.critical || 0; const highCount = sev.high || 0; const medCount = sev.medium || 0; const lowCount = sev.low || 0;
    const cc = document.getElementById('stCritCount'); if (cc) cc.textContent = String(critCount);
    const hc = document.getElementById('stHighCount'); if (hc) hc.textContent = String(highCount);
    const mc = document.getElementById('stMedCount'); if (mc) mc.textContent = String(medCount);
    const lc = document.getElementById('stLowCount'); if (lc) lc.textContent = String(lowCount);
    const cl = document.getElementById('stCritLabel'); if (cl) cl.textContent = critCount + ' Critical';
    const hl = document.getElementById('stHighLabel'); if (hl) hl.textContent = highCount + ' High';
    const ml = document.getElementById('stMedLabel'); if (ml) ml.textContent = medCount + ' Med';
    const ll = document.getElementById('stLowLabel'); if (ll) ll.textContent = lowCount + ' Low';
    const is = document.getElementById('stInfoScore'); if (is) is.textContent = msg.qualityScore || '--';
    const ii = document.getElementById('stInfoIssues'); if (ii) ii.textContent = msg.issues || '--';
    const ig = document.getElementById('stInfoGate'); if (ig) ig.textContent = msg.gate || '--';
    setSettingsStatus('Saved', true);
  }
  if (msg.command === 'apiConnectionResult') {
    const status = document.getElementById('stApiStatus');
    if (status) {
      status.textContent = msg.ok ? 'Connected' : 'Connection failed';
      status.style.color = msg.ok ? '#89d185' : '#f48771';
    }
  }
  if (msg.command === 'setAnalyzePath') {
    const pathInput = document.getElementById('analyzePathInput');
    if (pathInput && msg.path) pathInput.value = msg.path;
  }
  if (msg.command === 'setScanPath') {
    const pathInput = document.getElementById('scanPathInput');
    if (pathInput && msg.path) pathInput.value = msg.path;
  }
  if (msg.command === 'setQualityPath') {
    const pathInput = document.getElementById('qPathInput');
    if (pathInput && msg.path) pathInput.value = msg.path;
  }
});


vscode.postMessage({ command: 'ready' });
