const fs = require('fs');

const jsFile = 'C:/Users/Trevor/CascadeProjects/simplebeacon-vscode-merged/out/extension.js';
const js = fs.readFileSync(jsFile, 'utf8');

// Find buildCodeMapHtml function
const start = js.indexOf('function buildCodeMapHtml(options) {');
if (start === -1) {
  console.log('buildCodeMapHtml not found');
  process.exit(1);
}

// Find the end of the function - look for the next top-level function
let braceDepth = 0;
let funcStart = -1;
for (let i = start; i < js.length; i++) {
  if (js[i] === '{') {
    if (braceDepth === 0) funcStart = i;
    braceDepth++;
  } else if (js[i] === '}') {
    braceDepth--;
    if (braceDepth === 0) {
      const body = js.substring(start, i + 1);
      
      // Find the return statement with the template string
      const retIdx = body.indexOf('return `');
      if (retIdx === -1) {
        console.log('No return template found');
        process.exit(1);
      }
      
      // Find the matching closing backtick for the return statement
      let btDepth = 0;
      let inStr = false;
      let strChar = '';
      let escaped = false;
      let templateStart = -1;
      let templateEnd = -1;
      
      for (let j = retIdx; j < body.length; j++) {
        const ch = body[j];
        const prev = j > 0 ? body[j-1] : '';
        
        if (escaped) { escaped = false; continue; }
        if (ch === '\\') { escaped = true; continue; }
        
        if (ch === '`' && !inStr) {
          if (btDepth === 0) {
            btDepth = 1;
            templateStart = j;
          } else {
            templateEnd = j;
            break;
          }
        } else if (ch === "'" && !inStr) {
          inStr = true; strChar = "'";
        } else if (ch === '"' && !inStr) {
          inStr = true; strChar = '"';
        } else if (inStr && ch === strChar && prev !== '\\') {
          inStr = false;
        }
      }
      
      if (templateStart === -1 || templateEnd === -1) {
        console.log('Could not find template bounds');
        process.exit(1);
      }
      
      const template = body.substring(templateStart, templateEnd + 1);
      console.log('Template length:', template.length);
      
      // Extract the JS portion from the template
      // The template contains HTML with embedded JS. We need to find the <script> tags.
      const scriptOpen = template.indexOf('\\n<script>\\n');
      if (scriptOpen === -1) {
        // Try without leading newline
        const alt = template.indexOf('<script>\\n');
        if (alt === -1) {
          console.log('No <script> found in template');
          // Show surrounding context
          const ctx = template.substring(template.indexOf('script') - 20, template.indexOf('script') + 50);
          console.log('Context:', ctx);
          process.exit(1);
        }
      }
      
      const scriptClose = template.lastIndexOf('\\n</script>\\n');
      if (scriptClose === -1) {
        console.log('No </script> found in template');
        process.exit(1);
      }
      
      const inlineJs = template.substring(scriptOpen + 12, scriptClose); // skip '\\n<script>\\n'
      const lines = inlineJs.split('\\n');
      console.log('Inline JS lines:', lines.length);
      
      // Check for unclosed strings
      let foundError = false;
      for (let k = 0; k < lines.length; k++) {
        const line = lines[k];
        let inSingle = false;
        let inDouble = false;
        let esc = false;
        
        for (let m = 0; m < line.length; m++) {
          const ch = line[m];
          if (esc) { esc = false; continue; }
          if (ch === '\\') { esc = true; continue; }
          
          if (ch === "'" && !inDouble) {
            inSingle = !inSingle;
          } else if (ch === '"' && !inSingle) {
            inDouble = !inDouble;
          }
        }
        
        if (inSingle || inDouble) {
          foundError = true;
          console.log(`Line ${k+1}: Unclosed ${inSingle ? "'" : '"'} string`);
          console.log('  ', line.substring(0, 100));
          if (k+1 < lines.length) {
            console.log('  next:', lines[k+1].substring(0, 100));
          }
        }
      }
      
      if (!foundError) {
        console.log('No unclosed strings found');
        
        // Try to parse the JS
        const fullJs = lines.join('\n');
        try {
          new Function(fullJs);
          console.log('JS syntax: OK');
        } catch (e) {
          console.log('JS syntax ERROR:', e.message);
        }
      }
      
      break;
    }
  }
}
