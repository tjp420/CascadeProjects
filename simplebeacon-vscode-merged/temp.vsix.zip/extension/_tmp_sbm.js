"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerSidebarView = registerSidebarView;
exports.postSidebarMessage = postSidebarMessage;
exports.openTeamDashboardPanel = openTeamDashboardPanel;
const vscode = __importStar(require("vscode"));
const dataServer_1 = require("./dataServer");
let _sidebarView;
/**
 * Register the sidebar webview view for messenger operations.
 */
function registerSidebarView(view) {
    _sidebarView = view;
}
/**
 * Post a message to the sidebar webview.
 */
function postSidebarMessage(message) {
    if (_sidebarView) {
        try {
            _sidebarView.webview.postMessage(message);
        }
        catch { /* ignore */ }
    }
}
/**
 * Open the team dashboard in VS Code:'s Simple Browser.
 * @param route Dashboard route (e.g. /dashboard).
 * @param baseUrl Optional host origin. Defaults to the local data server.
 */
function openTeamDashboardPanel(_extUri, route = '/dashboard', _panelTitle = 'Team Dashboard', baseUrl) {
    const dataServerPort = (0, dataServer_1.getDataServerPort)();
    const isRemote = !!baseUrl && !/^(https?:\/\/)?(127\.0\.0\.1|localhost)(:\d+)?\/?$/i.test(baseUrl);
    let normalizedRoute = route;
    if (isRemote) {
        normalizedRoute = normalizedRoute.replace(/^\/dashboard\/?$/, '/dashboard/dashboard');
        if (!normalizedRoute.startsWith('/dashboard/')) {
            normalizedRoute = '/dashboard' + (normalizedRoute.startsWith('/') ? normalizedRoute : '/' + normalizedRoute);
        }
    }
    let dashboardUrl = baseUrl
        ? `${baseUrl.replace(/\/$/, '')}${normalizedRoute.startsWith('/') ? normalizedRoute : '/' + normalizedRoute}`
        : `http://127.0.0.1:${dataServerPort}${normalizedRoute}`;
    // Append a cache-buster to force the browser to fetch the latest index.html/module graph.
    const cacheBuster = `_=${Date.now()}`;
    dashboardUrl += dashboardUrl.includes('?') ? `&${cacheBuster}` : `?${cacheBuster}`;
    Promise.resolve(vscode.commands.executeCommand('simpleBrowser.show', dashboardUrl)).catch(() => { });
}
//# sourceMappingURL=sidebarMessenger.js.map
