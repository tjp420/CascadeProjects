const crypto = require('crypto');

const SECRET = 'fb578fe0edf57520edd3b1b53477fbafb20a43ee3d0162feb02974ca990cca54';

function generateLicenseToken(payload, secret, expiresInMinutes) {
  const issuedAt = Date.now();
  const expiresAt = issuedAt + (expiresInMinutes * 60 * 1000);
  const tokenPayload = {
    email: payload.email || '',
    tier: payload.tier || 'executive',
    features: payload.features || [],
    clientName: payload.clientName || payload.email || 'Client',
    projectName: payload.projectName || 'Project',
    iat: issuedAt,
    exp: expiresAt
  };
  const data = Buffer.from(JSON.stringify(tokenPayload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

const token = generateLicenseToken(
  { email: 'dev@simplebeacon.ai', tier: 'executive', clientName: 'Developer', projectName: 'Local Dev' },
  SECRET,
  365 * 24 * 60
);

const certUrl = `http://127.0.0.1:58624/certificate-upload.html?token=${encodeURIComponent(token)}`;

console.log('Token:', token);
console.log('');
console.log('Certificate Upload URL:');
console.log(certUrl);
