const fs = require('fs');
const html = fs.readFileSync('C:/Users/Trevor/CascadeProjects/simplebeacon-vscode-merged/.simplebeacon/codemap.html', 'utf8');

// Find the main script tag content
const scriptMatch = html.match(/<script[^>]*>([\s\S]*?)<\/script>/gi);
if (!scriptMatch) {
  console.log('No script tags found');
  process.exit(1);
}

scriptMatch.forEach((script, idx) => {
  // Skip JSON script tags
  if (script.includes('type="application/json"')) return;

  const js = script.replace(/<script[^>]*>/, '').replace(/<\/script>/, '');
  const lines = js.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let inString = false;
    let strChar = '';

    for (let j = 0; j < line.length; j++) {
      const ch = line[j];
      const prev = j > 0 ? line[j - 1] : '';

      if (!inString && (ch === "'" || ch === '"')) {
        inString = true;
        strChar = ch;
      } else if (inString && ch === strChar && prev !== '\\') {
        inString = false;
      }
    }

    if (inString) {
      console.log(`Script #${idx}: Unclosed ${strChar} string at line ${i + 1}`);
      console.log('  Line content:', line.substring(0, 120));
      if (i + 1 < lines.length) {
        console.log('  Next line:', lines[i + 1].substring(0, 120));
      }
    }
  }
});
