const fs = require('fs');
const lines = fs.readFileSync('src/welcomeDashboard.ts', 'utf8').split('\n');
let start = lines.findIndex(l => l.includes('<script nonce='));
let end = lines.findIndex((l, i) => i > start && l.includes('</script>'));
console.log('Script section: lines', start + 1, 'to', end + 1);
for (let i = start; i < end && i < lines.length; i++) {
  const line = lines[i];
  const clean = line.replace(/\\/g, '');
  const sq = (clean.match(/'/g) || []).length;
  const dq = (clean.match(/"/g) || []).length;
  if (sq % 2 === 1 || dq % 2 === 1) {
    console.log('Line', i + 1, '- sq:', sq, 'dq:', dq, '-', line.trim().substring(0, 100));
  }
}
