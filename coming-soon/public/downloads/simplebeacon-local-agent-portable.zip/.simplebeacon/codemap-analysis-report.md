# CascadeProjects Codemap Analysis Report

**Generated:** 2026-07-01T06:56:58.899Z  
**Source:** cascadeprojects-codemap-analysis-2026-07-01(2).json  
**Version:** 3.0.315

## Summary Statistics

| Metric | Value |
|--------|-------|
| Total Files (Nodes) | 1608 |
| Total Dependencies (Edges) | 2553 |
| Average Degree | 3.18 |
| Orphaned Files (0 connections) | 384 |
| Test Files | 245 (15.2%) |
| Largest Connected Component | 601 files |
| Circular Dependencies | 0 cycles |

## Extension Breakdown

| Extension | Count | Percentage |
|-----------|-------|------------|
| .js | 1168 | 72.6% |
| .cjs | 347 | 21.6% |
| .ts | 80 | 5.0% |
| .mjs | 13 | 0.8% |

## Top 10 Most Connected Files

| Rank | File | Total Degree | Out | In |
|------|------|-------------|-----|-----|
| 1 | `ai-platform/server/config/constants.cjs` | 112 | 18 | 94 |
| 2 | `false-positive-audit/express/index.js` | 104 | 1 | 103 |
| 3 | `simplebeacon-vscode-merged/dashboard-web/js-es2018/utils.js` | 75 | 19 | 56 |
| 4 | `ai-platform/web/simplebeacon-dashboard/js-es2018/utils.js` | 63 | 19 | 44 |
| 5 | `ai-platform/server/routes/flexible-analyze-api.cjs` | 58 | 54 | 4 |
| 6 | `simplebeacon-vscode-merged/dashboard-web/js/utils.js` | 56 | 0 | 56 |
| 7 | `packages/simplebeacon-cli/src/index.js` | 55 | 48 | 7 |
| 8 | `ai-platform/web/simplebeacon-dashboard/js/utils.js` | 52 | 11 | 41 |
| 9 | `packages/simplebeacon-cli/src/scan.js` | 51 | 41 | 10 |
| 10 | `ai-platform/server/lib/simplebeacon-proxy.cjs` | 49 | 29 | 20 |

## Top Packages by File Count

| Package | Files |
|---------|-------|
| ai-platform | 554 |
| simplebeacon-vscode-merged | 361 |
| packages | 267 |
| false-positive-audit | 213 |
| coming-soon | 116 |
| scripts | 49 |
| api-server | 9 |
| simplebeacon-rule-tests | 9 |
| ai-agent | 7 |
| sales | 5 |

## Circular Dependencies

No cycles detected.
