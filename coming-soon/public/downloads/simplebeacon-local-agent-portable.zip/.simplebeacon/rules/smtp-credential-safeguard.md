# SMTP Credential Safeguard

## Operational rule

If `node tools/send-test-smtp-email.cjs --verify` returns a `535 Authentication Failed` error:

- Do NOT rewrite the SMTP transport logic in `coming-soon/tools/send-test-smtp-email.cjs`.
- Treat this as an external operational blocker caused by invalid or stale Zoho Mail credentials.
- Stop the current task and escalate to the live deployment environment for credential rotation and host-manager update.
- Log the issue as `environmental_smtp_auth_failure` and continue only after the fresh Zoho app-specific password is installed.

## Required actions

1. Generate a fresh Zoho Mail app-specific password for `admin@simplebeacon.ai`.
2. Update the production environment variables in the deployment host manager or runtime environment.
3. Re-run the verification command only after the new password is live.
4. If verification passes, flush the queued outbound email backlog via the email retry worker.

## Do not do

- Do not edit the SMTP host/port/secure logic unless the failure is clearly not authentication-related.
- Do not hardcode secrets into repository files.
- Do not commit production `.env.production` or `.env.prod` values.

## Verification gate

Use the following sequence after the environment is updated:

```bash
cd "c:\Users\user\CascadeProjects\coming-soon"
node -c tools/send-test-smtp-email.cjs
node tools/send-test-smtp-email.cjs --verify
node tools/trigger-queue-flush.cjs
```

Expected end state:

- `node -c` exits cleanly with code 0
- `--verify` exits cleanly with code 0 and prints: `SMTP Connection successfully verified for production deployment!`
- queue flush completes without remaining pending SMTP messages
