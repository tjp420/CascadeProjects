#!/usr/bin/env node
/**
 * Secret Rotation Script
 * Replaces hardcoded secrets in .env files with cryptographically secure values.
 * Creates a backup of old secrets for safekeeping.
 *
 * Usage: node .simplebeacon/rotate-secrets.js [--dry-run]
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DRY_RUN = process.argv.includes('--dry-run');

// ─── Helper: generate secure values ───
const genHex = (bytes = 32) => crypto.randomBytes(bytes).toString('hex');
const genJWT = () => 'sb-jwt-' + genHex(24);
const genLicense = (prefix = 'sb-master') => `${prefix}-${genHex(32)}`;
const genPassword = () => 'sb-pass-' + genHex(12);

// ─── Files to rotate ───
const targets = [
  {
    file: path.resolve('C:\\Users\\Trevor\\CascadeProjects\\.env'),
    replacements: [
      {
        key: 'SIMPLEBEACON_LICENSE_SECRET',
        value: genLicense(),
        oldValue: 'sb-master-568d81d7938a5d1a549941e0566569317bd0d94b677d611467622dc7b3b6da6b'
      },
      {
        key: 'ADMIN_SECRET',
        value: genPassword(),
        oldValue: 'change-me-in-production'
      }
    ]
  },
  {
    file: path.resolve('C:\\Users\\Trevor\\CascadeProjects\\ai-platform\\.env'),
    replacements: [
      {
        key: 'SIMPLEBEACON_LICENSE_SECRET',
        value: genLicense(),
        oldValue: 'sb-master-568d81d7938a5d1a549941e0566569317bd0d94b677d611467622dc7b3b6da6b'
      },
      {
        key: 'DASHBOARD_VAULT_PASSWORD',
        value: genPassword(),
        oldValue: 'dev'
      },
      {
        key: 'JWT_SECRET',
        value: genJWT(),
        oldValue: 'dev-jwt-secret-change-in-production'
      },
      {
        key: 'JWT_REFRESH_SECRET',
        value: genJWT(),
        oldValue: 'dev-jwt-refresh-secret-change-in-production'
      }
    ]
  },
  {
    file: path.resolve('C:\\Users\\Trevor\\CascadeProjects\\ai-platform\\.env.production'),
    replacements: [
      {
        key: 'JWT_SECRET',
        value: genJWT(),
        oldValue: 'sb-prod-2026-a7f3k9m2p5q8r1t4u7w0x3y6z9b2c5d8e1f4g7h0j3k6m9n2p5q8r1t4'
      },
      {
        key: 'JWT_REFRESH_SECRET',
        value: genJWT(),
        oldValue: 'sb-refresh-2026-x4y7z0a3b6c9d2e5f8g1h4j7k0m3n6p9q2r5t8u1w4'
      },
      {
        key: 'POSTGRES_PASSWORD',
        value: genPassword(),
        oldValue: 'prod-postgres-password-change-this'
      }
    ]
  },
  {
    file: path.resolve('C:\\Users\\Trevor\\CascadeProjects\\ai-platform\\.env.v1-internal'),
    replacements: [
      {
        key: 'JWT_SECRET',
        value: genJWT(),
        oldValue: 'dev-jwt-secret-key-for-v1-internal-development-32chars-min'
      },
      {
        key: 'JWT_REFRESH_SECRET',
        value: genJWT(),
        oldValue: 'dev-jwt-refresh-secret-key-for-v1-internal-32chars-min'
      },
      {
        key: 'POSTGRES_PASSWORD',
        value: genPassword(),
        oldValue: 'dev-postgres-password-v1internal'
      },
      {
        key: 'SIMPLEBEACON_LICENSE_SECRET',
        value: genLicense('sb-v1'),
        oldValue: 'simplebeacon-dev-insecure'
      },
      {
        key: 'DASHBOARD_VAULT_PASSWORD',
        value: genPassword(),
        oldValue: 'dev-vault-password'
      }
    ]
  },
  {
    file: path.resolve('C:\\Users\\Trevor\\CascadeProjects\\coming-soon\\.env'),
    replacements: [
      {
        key: 'SIMPLEBEACON_LICENSE_SECRET',
        value: genLicense(),
        oldValue: 'fb578fe0edf57520edd3b1b53477fbafb20a43ee3d0162feb02974ca990cca54'
      }
    ]
  }
];

// ─── Execute ───
const backupEntries = [];
let changedCount = 0;
let skippedCount = 0;

for (const target of targets) {
  if (!fs.existsSync(target.file)) {
    console.log(`SKIP  (missing) ${target.file}`);
    skippedCount++;
    continue;
  }

  let content = fs.readFileSync(target.file, 'utf8');
  let modified = false;

  for (const r of target.replacements) {
    const regex = new RegExp(`^(${r.key}=).*`, 'gm');
    const match = content.match(regex);
    if (match) {
      const oldFull = match[0];
      const newFull = `${r.key}=${r.value}`;
      content = content.replace(regex, newFull);
      modified = true;
      backupEntries.push({
        file: target.file,
        key: r.key,
        oldValue: r.oldValue,
        newValue: r.value
      });
      console.log(`${DRY_RUN ? '[DRY-RUN] ' : ''}ROTATE ${r.key} in ${path.basename(path.dirname(target.file))}/${path.basename(target.file)}`);
    }
  }

  if (modified) {
    if (!DRY_RUN) {
      fs.writeFileSync(target.file, content, 'utf8');
    }
    changedCount++;
  } else {
    console.log(`SKIP  (no match) ${target.file}`);
    skippedCount++;
  }
}

// ─── Save backup ───
if (backupEntries.length > 0) {
  const backupPath = path.resolve('C:\\Users\\Trevor\\CascadeProjects\\.simplebeacon\\secret-backup.json');
  const backupData = {
    rotatedAt: new Date().toISOString(),
    mode: DRY_RUN ? 'dry-run' : 'live',
    secrets: backupEntries
  };
  if (!DRY_RUN) {
    fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
    console.log(`\nBackup saved: ${backupPath}`);
    console.log('WARNING: Delete this backup file after you have stored secrets in your secrets manager.');
  }
}

// ─── Summary ───
console.log(`\n${'='.repeat(50)}`);
console.log(`Files changed : ${changedCount}`);
console.log(`Secrets rotated: ${backupEntries.length}`);
console.log(`Files skipped  : ${skippedCount}`);
console.log(`Mode           : ${DRY_RUN ? 'DRY RUN (no files modified)' : 'LIVE'}`);
console.log(`${'='.repeat(50)}`);

if (!DRY_RUN) {
  console.log('\nNext steps:');
  console.log('1. Review the backup file and store secrets in a secrets manager');
  console.log('2. Delete .simplebeacon/secret-backup.json when done');
  console.log('3. Restart services to pick up new env values');
  console.log('4. Purge old secrets from git history with:');
  console.log('   git filter-repo --replace-text replacements.txt');
  console.log('   (or use BFG Repo-Cleaner: https://rtyley.github.io/bfg-repo-cleaner/)');
}
