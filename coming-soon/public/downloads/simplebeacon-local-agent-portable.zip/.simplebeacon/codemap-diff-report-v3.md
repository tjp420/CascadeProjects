# Codemap Export Diff Report

**v1 Exported:** 2026-07-01T06:35:26.378Z  
**v2 Exported:** 2026-07-01T06:54:59.661Z  

## Node Changes

| Metric | v1 | v2 | Change |
|--------|-----|-----|--------|
| Total Nodes | 1605 | 1608 | 3 |
| Total Edges | 2532 | 2553 | 21 |

**Added Nodes (3):**
- `ai-platform/server/lib/codebase-analyzer-helpers.cjs`
- `scripts/analyze-scan-report.js`
- `scripts/diff-codemap-exports.js`

**Removed Nodes (0):**
_None_

## Edge Changes

**Added Edges (21):**
- `ai-platform/server/lib/codebase-analyzer.cjs → ai-platform/server/lib/codebase-analyzer-helpers.cjs`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/config.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/project-detect.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/config-schema.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/scan.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/file-reduction-orchestrator.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/gate.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/reporters/json.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/assessment.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/rules/ai-fiction-detection.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/report-sanitizer.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/complete-scan-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/public-summary-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/assessment-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/re-attestation-note-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/roadmap-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/simplebeacon-report-export-sanitize.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/eu-ai-act-export-guard.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/eu-ai-act-legal-attestation.js`
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/lib/init-simplebeacon.cjs`

_... and 1 more_

**Removed Edges (1):**
- `ai-platform/server/lib/simplebeacon-proxy.cjs → packages/simplebeacon-cli/src/index.js`


## Summary

The two exports are **structurally different**. 
