const fs = require('fs');
const path = require('path');

const downloadsDir = 'C:/Users/Trevor/Downloads';
const completeScanFile = path.join(downloadsDir, 'complete-scan-c-users-trevor-cascadeprojects-2026-06-19.json');
const reportFile = path.join(downloadsDir, 'report.json');

let completeScan = null;
let report = null;

try {
  completeScan = JSON.parse(fs.readFileSync(completeScanFile, 'utf8'));
} catch (e) {
  console.error('Complete scan not found:', e.message);
}

try {
  report = JSON.parse(fs.readFileSync(reportFile, 'utf8'));
} catch (e) {
  console.error('Report not found:', e.message);
}

const timestamp = new Date().toISOString();
let md = '# AI Context -- SimpleBeacon Scan Consolidation\n\n';
md += '**Generated:** ' + timestamp + '\n';
md += '**Sources:** Dashboard (port 58977), Roadmap (port 3000), Audit (port 3000)\n\n';

if (report) {
  md += '## SimpleBeacon Gate Report\n\n';
  md += '- **Quality Score:** ' + (report.qualityScore ?? 'N/A') + '/100\n';
  md += '- **Gate Pass:** ' + (report.scan_summary?.status ?? 'N/A') + '\n';
  md += '- **Total Issues:** ' + (report.issueCount ?? 0) + '\n';
  md += '- **Files Analyzed:** ' + (report.filesAnalyzed ?? 0) + '\n';
  md += '- **Repository Files:** ' + (report.repositoryFilesTotal ?? 0) + '\n\n';

  if (report.detectedIssues?.length) {
    md += '### Top Detected Issues\n\n';
    for (const issue of report.detectedIssues.slice(0, 10)) {
      md += '- **[' + (issue.severity || 'info').toUpperCase() + ']** ' + (issue.type || 'Issue') + ': ' + (issue.count || 1) + ' occurrence(s)\n';
      if (issue.findings?.length) {
        for (const f of issue.findings.slice(0, 2)) {
          const file = f.file || 'N/A';
          const line = f.matches?.[0]?.line || '';
          md += '  - `' + file + (line ? ':' + line : '') + '`\n';
        }
      }
    }
    md += '\n';
  }

  if (report.rawIssues?.length) {
    const types = {};
    for (const i of report.rawIssues) {
      types[i.type] = (types[i.type] || 0) + (i.count || 1);
    }
    md += '### Issue Types\n\n';
    for (const [type, count] of Object.entries(types).sort((a, b) => b[1] - a[1]).slice(0, 15)) {
      md += '- ' + type + ': ' + count + '\n';
    }
    md += '\n';
  }
}

if (completeScan) {
  md += '## Complete Scan Results\n\n';
  md += '- **Engines Run:** ' + (completeScan.enginesRun?.length ?? 0) + '\n';
  md += '- **Steps Completed:** ' + (completeScan.steps?.length ?? 0) + '\n';
  md += '- **Scan Duration:** ' + (completeScan.scanDurationMs ? (completeScan.scanDurationMs / 1000).toFixed(1) + 's' : 'N/A') + '\n\n';

  const stepsWithFindings = (completeScan.steps || []).filter(s => s.findingsCount > 0 || (s.findings?.length > 0));
  if (stepsWithFindings.length) {
    md += '### Steps with Findings\n\n';
    for (const step of stepsWithFindings) {
      const fcount = step.findingsCount ?? (step.findings?.length ?? 0);
      md += '- **' + step.id + '**: ' + fcount + ' findings' + (step.severity ? ' (' + step.severity + ')' : '') + '\n';
      if (step.findings?.length) {
        for (const f of step.findings.slice(0, 3)) {
          md += '  - `' + (f.filePath || 'N/A') + ':' + (f.line || 1) + '` -- ' + (f.description || f.type || '').slice(0, 100) + '\n';
        }
      }
    }
    md += '\n';
  }

  if (completeScan.summary) {
    const s = completeScan.summary;
    md += '### Summary Metrics\n\n';
    if (s.codebaseHealthScore !== null && s.codebaseHealthScore !== undefined) md += '- **Codebase Health Score:** ' + s.codebaseHealthScore + '\n';
    if (s.codebaseFindings !== null && s.codebaseFindings !== undefined) md += '- **Codebase Findings:** ' + s.codebaseFindings + '\n';
    if (s.fileReductionFindings !== null && s.fileReductionFindings !== undefined) md += '- **File Reduction Findings:** ' + s.fileReductionFindings + '\n';
    if (s.dataQualityFindings !== null && s.dataQualityFindings !== undefined) md += '- **Data Quality Findings:** ' + s.dataQualityFindings + '\n';
    if (s.npmVulnerabilities !== null && s.npmVulnerabilities !== undefined) md += '- **npm Vulnerabilities:** ' + s.npmVulnerabilities + '\n';
    if (s.compliancePassed !== null && s.compliancePassed !== undefined) md += '- **Compliance Passed:** ' + s.compliancePassed + '/' + (s.compliancePassed + s.complianceFailed) + '\n';
    md += '\n';
  }
}

md += '## Next Steps\n\n';
md += '1. Review critical and high-severity issues first\n';
md += '2. Address committed .env files and exposed secrets\n';
md += '3. Fix eval-danger and innerHTML XSS vulnerabilities\n';
md += '4. Run `npx simplebeacon scan --fix` for auto-remediation\n';
md += '5. Re-scan to verify gate pass\n';

const projectRoot = 'C:/Users/Trevor/CascadeProjects';
const sbDir = path.join(projectRoot, '.simplebeacon');
if (!fs.existsSync(sbDir)) fs.mkdirSync(sbDir, { recursive: true });
const contextPath = path.join(sbDir, 'ai-context.md');
fs.writeFileSync(contextPath, md, 'utf8');
console.log('AI context written to:', contextPath);
console.log('File size:', md.length, 'bytes');
