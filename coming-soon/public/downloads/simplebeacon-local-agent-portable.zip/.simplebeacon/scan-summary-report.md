# SimpleBeacon Scan Summary Report

**Generated:** 2026-07-01T06:34:45.239Z  
**Scan ID:** sb_scan_d52d04dd3363  
**Status:** PASSED  
**Quality Score:** 100  

## Executive Summary

| Metric | Value |
|--------|-------|
| Total Files Scanned | 35521 |
| Total Lines | 9,028,859 |
| Total Risks Found | 3656 |
| High Severity | 0 |
| Medium Severity | 3 |
| Low Severity | 3 |
| Critical | 0 |

| Previous Scan | 22 findings |
| Resolved | 22 |
| New | 6 |
| Persistent | 0 |

## Issue Breakdown by Category

| Category | Count |
|----------|-------|
| Hardcoded URL | 2 |
| Dead Code | 2 |
| Memory Leak | 2 |

## Top 10 Most Affected Files

| File | Issues |
|------|--------|
| `SettingsView.js` | 1 |
| `lucide.min.js` | 1 |
| `main.js` | 1 |
| `AnalyzeView.js` | 1 |
| `AssessmentView.js` | 1 |
| `RemediationRoadmapView.js` | 1 |

## Top 10 Most Triggered Rules

| Rule ID | Count | Description |
|---------|-------|-------------|
| SB-SEC-005b | 1 | Hardcoded URL |
| SB-SEC-005 | 1 | Hardcoded URL |
| SB-QUAL-001c | 1 | Dead Code |
| SB-QUAL-001 | 1 | Dead Code |
| SB-PERF-002 | 1 | Memory Leak |
| SB-PERF-002d | 1 | Memory Leak |

## Medium+ Severity Unique Findings (3)

- **[MEDIUM]** `SB-SEC-005` in `lucide.min.js` (line 11): Hardcoded URL — d:"M17 13v-3h4"}],["path",{d:"M17 17.7c.4.2.8.3 1.3.3 1.5 0 2.7-1.1 2.7-2.5S19.8 13 18.
- **[MEDIUM]** `SB-PERF-002` in `AssessmentView.js` (line 130): Memory Leak — === null || _b === void 0 ? void 0 : _b.addEventListener('submit', (e) => this.onSubmit(e)); el.q
- **[MEDIUM]** `SB-PERF-002d` in `RemediationRoadmapView.js` (line 66): Memory Leak — ry(issues) { const groups = {}; for (const issue of issues) { const plan = getRemediationPlan(issue); const cat = plan.c

## Recommendations

1. **Address medium+ findings first:** 3 unique medium+ issues need attention.
2. **Focus on top affected files:** SettingsView.js, lucide.min.js, main.js contain the highest concentration of issues.
3. **Dead code cleanup:** 2 dead code findings suggest opportunity for refactoring.
4. **Memory leak review:** 2 potential memory leaks detected in event listener patterns.
