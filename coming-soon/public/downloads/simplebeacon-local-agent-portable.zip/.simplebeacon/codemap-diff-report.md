# Codemap Export Diff Report

**v1 Exported:** 2026-07-01T06:13:44.517Z  
**v2 Exported:** 2026-07-01T06:35:26.378Z  

## Node Changes

| Metric | v1 | v2 | Change |
|--------|-----|-----|--------|
| Total Nodes | 1601 | 1605 | 4 |
| Total Edges | 2532 | 2532 | 0 |

**Added Nodes (4):**
- `scripts/analyze-codemap.js`
- `scripts/check-codemap.js`
- `scripts/inject-codemap-graph.js`
- `scripts/verify-codemap.js`

**Removed Nodes (0):**
_None_

## Edge Changes

**Added Edges (0):**
_None_


**Removed Edges (0):**
_None_


## Summary

The two exports are **structurally different**. 
