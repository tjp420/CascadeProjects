## SimpleBeacon AI Context

- **Project:** c:\Users\Trevor\CascadeProjects
- **Report type:** scan-summary
- **Sent at:** 2026-07-06T17:21:04.018Z


### Summary

- gatePass: true
- qualityScore: 100
- totalIssues: 231
- filesScanned: 860
- reportType: simplebeacon-report

### Findings

- [low] Duplicate Data: 3 files share identical JSON content
- [low] Duplicate Data: 3 files share identical JSON content
- [low] Duplicate Data: 5 files share identical JSON content
- [low] workspace-health: ai-platform/server/lib/central-data-config.cjs:6 workspace-health pattern detected
- [low] test-coverage: ai-platform/server/utils/data-processor.cjs: Source file (239 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/lib/production-logger.cjs: Source file (64 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/api/build-from-path-route.cjs: Source file (232 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/api/dashboard-stub-api.cjs: Source file (723 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/api/roadmap-analysis-history.cjs: Source file (185 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/api/optimization-api.cjs: Source file (230 lines) has no corresponding test file
- [low] test-coverage: ai-platform/src/api/trust-api.cjs: Source file (300 lines) has no corresponding test file
- [low] governance: ai-platform/packages/simplebeacon-intelligence/src/constants.js:1 governance pattern detected
- [low] governance-marker: ai-platform/packages/simplebeacon-intelligence/src/constants.js:1 governance-marker pattern detected
- [low] governance: ai-platform/packages/simplebeacon-intelligence/src/index.js:1 governance pattern detected
- [low] governance-marker: ai-platform/packages/simplebeacon-intelligence/src/index.js:1 governance-marker pattern detected
- [low] workspace-health: ai-platform/packages/simplebeacon-intelligence/src/slm-bridge.js:29 workspace-health pattern detected
- [low] test-coverage: ai-platform/packages/simplebeacon-intelligence/src/slm-bridge.js: Source file (305 lines) has no corresponding test file
- [low] test-coverage: ai-platform/packages/simplebeacon-intelligence/src/structural-intent-scanner.js: Source file (317 lines) has no corresponding test file
- [low] test-coverage: ai-platform/packages/simplebeacon-intelligence/src/tree-sitter-loader.js: Source file (161 lines) has no corresponding test file
- [low] test-coverage: ai-platform/packages/simplebeacon-intelligence/src/vector-cache.js: Source file (198 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/api/assessment/AssessmentController.cjs: Source file (230 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/api/metrics/path-health.cjs: Source file (131 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/routes/lib/flexible-analyze-roadmap.cjs: Source file (79 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/analyze-export-bundle/engines.cjs: Source file (101 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/analyze-export-bundle/split.cjs: Source file (226 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/analyze-export-bundle/validation.cjs: Source file (98 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-remediation-recipes/classify.cjs: Source file (137 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-remediation-recipes/data.cjs: Source file (83 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-remediation-recipes/normalize.cjs: Source file (86 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-remediation-recipes/paths.cjs: Source file (134 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-report/executive.cjs: Source file (328 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-report/html-renderer.cjs: Source file (243 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-report/html-sections.cjs: Source file (231 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-report/sample-report.cjs: Source file (102 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/audit-report/__tests__.cjs: Source file (302 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/auth/login-service.cjs: Source file (89 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/auth/token-service.cjs: Source file (98 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/business-logic-patterns.cjs: Source file (121 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/code-understanding-engine.cjs: Source file (202 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/contextual-analyzer.cjs: Source file (144 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/expert-review-store.cjs: Source file (93 lines) has no corresponding test file
- [low] workspace-health: ai-platform/server/lib/code-understanding/ml-pattern-detector.cjs:11 workspace-health pattern detected
- [low] test-coverage: ai-platform/server/lib/code-understanding/ml-pattern-detector.cjs: Source file (549 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/semantic-analyzer.cjs: Source file (166 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/zscript-cvar-analyzer.cjs: Source file (307 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/zscript-mod-report.cjs: Source file (125 lines) has no corresponding test file
- [low] test-coverage: ai-platform/server/lib/code-understanding/zscript-structure-analyzer.cjs: Source file (374 lines) has no corresponding test file
- [low] workspace-health: ai-platform/src/api/billing/validate-project-token.cjs:3 workspace-health pattern detected
- [low] workspace-health: ai-platform/src/api/billing/report-bundle-builder.cjs:11 workspace-health pattern detected
- [low] test-coverage: ai-platform/src/api/billing/report-bundle-builder.cjs: Source file (309 lines) has no corresponding test file

_Paste this into your AI coding agent for remediation guidance._