#Requires -Version 5.1
<#
.SYNOPSIS
    Purge leaked secrets from git history using BFG Repo-Cleaner.

.DESCRIPTION
    This script:
    1. Verifies BFG Repo-Cleaner is available
    2. Runs BFG with the replacement text file
    3. Expires reflog and garbage collects to fully remove old commits

    WARNING: This rewrites git history. All collaborators must re-clone.
    Make a full backup of your repo before running.

    Prerequisites:
    - BFG Repo-Cleaner: https://rtyley.github.io/bfg-repo-cleaner/
    - Java installed (BFG is a Java jar)

.EXAMPLE
    .simplebeacon\run-bfg-cleanup.ps1
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$BfgPath = "bfg",
    [string]$ReplacementsFile = ".simplebeacon\bfg-replacements.txt"
)

$ErrorActionPreference = "Stop"
$repoRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Push-Location $repoRoot

try {
    # ── Verify prerequisites ──
    Write-Host "=== Secret History Cleanup ===" -ForegroundColor Cyan
    Write-Host "Repo root: $repoRoot" -ForegroundColor Gray

    # Check git repo
    if (-not (Test-Path ".git")) {
        throw "Not a git repository. Run from repo root."
    }

    # Check BFG
    try {
        $bfgVersion = & $BfgPath --version 2>$null
        Write-Host "BFG found: $bfgVersion" -ForegroundColor Green
    } catch {
        Write-Host "BFG Repo-Cleaner not found in PATH." -ForegroundColor Yellow
        Write-Host "Download from: https://rtyley.github.io/bfg-repo-cleaner/" -ForegroundColor Yellow
        Write-Host "Or install with: scoop install bfg  (or choco install bfg-repo-cleaner)" -ForegroundColor Yellow
        throw "BFG not available"
    }

    # Check replacements file
    $replacementsPath = Resolve-Path $ReplacementsFile -ErrorAction Stop
    $lineCount = (Get-Content $replacementsPath | Where-Object { $_ -notmatch '^\s*#|^\s*$' }).Count
    Write-Host "Replacements file: $replacementsPath ($lineCount rules)" -ForegroundColor Green

    # ── Safety checks ──
    Write-Host "`nWARNING: This will REWRITE GIT HISTORY." -ForegroundColor Red
    Write-Host "All collaborators must re-clone after this operation." -ForegroundColor Red
    Write-Host "Ensure you have a FULL BACKUP of the repository before proceeding." -ForegroundColor Red
    Write-Host ""

    $confirm = Read-Host "Type 'PURGE' to confirm and proceed"
    if ($confirm -ne 'PURGE') {
        Write-Host "Aborted. No changes made." -ForegroundColor Yellow
        return
    }

    # ── Run BFG ──
    Write-Host "`nRunning BFG Repo-Cleaner..." -ForegroundColor Cyan
    & $BfgPath --replace-text $replacementsPath
    if ($LASTEXITCODE -ne 0) {
        throw "BFG failed with exit code $LASTEXITCODE"
    }

    # ── Clean up git objects ──
    Write-Host "`nExpiring reflog and pruning objects..." -ForegroundColor Cyan
    git reflog expire --expire=now --all
    git gc --prune=now --aggressive

    Write-Host "`n=== Cleanup Complete ===" -ForegroundColor Green
    Write-Host "`nNext steps:" -ForegroundColor White
    Write-Host "1. Force push to remote: git push --force --all" -ForegroundColor Yellow
    Write-Host "2. Tell all collaborators to re-clone the repository" -ForegroundColor Yellow
    Write-Host "3. Run the secret rotation script: node .simplebeacon\rotate-secrets.js" -ForegroundColor Yellow
    Write-Host "4. Delete .simplebeacon\bfg-replacements.txt when done" -ForegroundColor Yellow

} finally {
    Pop-Location
}
