#!/bin/sh
"$(dirname "$0")/node" "$(dirname "$0")/agent.cjs"
