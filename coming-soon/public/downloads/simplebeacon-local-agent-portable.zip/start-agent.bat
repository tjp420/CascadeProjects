@echo off
start "" "node.exe" "%~dp0agent.cjs"
