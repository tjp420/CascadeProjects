"use strict";

/**
 * MCP agent workflow handlers — supercharge_agent, handoff_check,
 * scan_staged, agent_status, code_suggestions, install_agent_plugin.
 *
 * These tools implement the agent supercharge workflow referenced in
 * .cursor/rules/simplebeacon-ai-workflow.mdc but previously missing
 * from the MCP TOOL_DEFINITIONS.
 *
 * All operations are local-first (no upload).
 */

const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");
const { readFile, writeFile, mkdir } = fs.promises;
const pda = require("../../agent-pda");
const { readGateStatus } = require("../../lib/snippet-scanner");

const SCANNABLE_EXT =
  /\.(js|cjs|mjs|ts|tsx|jsx|json|yml|yaml|xml|sh|bat|ps1|py|go|rs|java|rb|php|cs|env|ini|cfg|conf|toml|md)$/i;

function createAgentHandlers({
  withGuard,
  resolveProjectRoot,
  formatToolResult,
  formatMarkdownResult,
  getCachedReport,
}) {
  // ─── Helper: load report from cache or disk ───
  async function loadReport(root, reportPath) {
    let report = getCachedReport ? getCachedReport(root) : null;
    if (report) return report;
    const rp = reportPath
      ? path.resolve(root, reportPath)
      : path.join(root, ".simplebeacon", "report.json");
    try {
      report = JSON.parse(await readFile(rp, "utf8"));
      return report;
    } catch {
      return null;
    }
  }

  // ─── Helper: compact issue summary ───
  function compactIssues(issues, max = 10) {
    return (issues || [])
      .slice(0, max)
      .map((i) => ({
        severity: i.severity || "low",
        type: i.type || i.rule || i.pattern || "issue",
        file: i.filePath || i.path || i.file || "",
        line: i.line || null,
        description: String(i.description || i.message || i.impact || "").slice(
          0,
          200,
        ),
      }));
  }

  return {
    // ─── supercharge_agent ───
    supercharge_agent: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);
      const report = await loadReport(root, args?.reportPath);

      // Auto-register the agent
      const agent = pda.autoRegister(root);

      // Read any existing handoff brief
      let handoff = null;
      try {
        const agents = pda.listAgents(root);
        for (const a of agents) {
          const mem = pda.recallLatest(root, a.id, "handoff-brief", "handoff");
          if (mem && (!handoff || mem.updatedAt > handoff.updatedAt)) {
            handoff = mem;
          }
        }
      } catch {
        // ignore
      }

      // Build mission from gate state
      let mission = "No scan report found — run scan_project with gate:true";
      let gateSummary = null;
      let topIssues = [];

      if (report) {
        const gate = report.gate || {};
        const pass = gate.pass === true;
        const blocking = gate.blockingCount || 0;
        gateSummary = {
          pass,
          blockingCount: blocking,
          warningCount: gate.warningCount || 0,
          qualityScore: report.qualityScore ?? null,
        };

        if (pass) {
          mission = "Gate passed — run handoff_check before claiming done";
        } else if (blocking > 0) {
          mission = `Fix ${blocking} gate-blocking issue(s) before anything else`;
        } else {
          mission = "Run scan_project with gate:true to establish gate state";
        }

        const allIssues =
          report.detectedIssues || report.rawIssues || report.findings || [];
        const blocking_issues = allIssues.filter((i) => {
          const s = String(i.severity || "").toLowerCase();
          return s === "critical" || s === "high";
        });
        topIssues = compactIssues(
          blocking_issues.length > 0 ? blocking_issues : allIssues,
          8,
        );
      }

      // Read code suggestions if available
      let suggestions = [];
      if (report) {
        try {
          const allIssues =
            report.detectedIssues || report.rawIssues || [];
          const blocking = allIssues.filter((i) => {
            const s = String(i.severity || "").toLowerCase();
            return s === "critical" || s === "high";
          });
          suggestions = blocking.slice(0, 5).map((issue, idx) => ({
            priority: idx + 1,
            severity: issue.severity,
            type: issue.type || issue.rule || "unknown",
            file: issue.filePath || issue.path || "",
            fix:
              issue.fix ||
              issue.recommendedAction ||
              issue.recommendation ||
              "Manual review required",
          }));
        } catch {
          // ignore
        }
      }

      // Write the supercharge brief to disk if requested
      let diskPath = null;
      if (args?.writeDisk === true) {
        try {
          const briefDir = path.join(root, ".simplebeacon");
          await mkdir(briefDir, { recursive: true });
          diskPath = path.join(briefDir, "agent-supercharge.md");
          const briefLines = [
            "# SimpleBeacon Agent Supercharge",
            "",
            `> Mission: **${mission}**`,
            "",
            `Agent: ${agent.id} (${agent.name || "auto-detected"})`,
            "",
            "## Gate state",
            gateSummary
              ? `- **Pass:** ${gateSummary.pass}\n- **Blocking:** ${gateSummary.blockingCount}\n- **Warnings:** ${gateSummary.warningCount}\n- **Quality score:** ${gateSummary.qualityScore ?? "N/A"}`
              : "- No scan report found. Run `scan_project` with `gate: true`.",
            "",
            "## Top issues to fix",
            topIssues.length > 0
              ? topIssues
                  .map(
                    (i) =>
                      `- [${i.severity}] ${i.type}${i.file ? ` @ ${i.file}` : ""}: ${i.description}`,
                  )
                  .join("\n")
              : "- None",
            "",
            "## Suggested fixes",
            suggestions.length > 0
              ? suggestions
                  .map(
                    (s) =>
                      `${s.priority}. **${s.type}**${s.file ? ` @ ${s.file}` : ""}: ${s.fix}`,
                  )
                  .join("\n")
              : "- None",
            "",
            handoff
              ? `## Previous handoff\n\n${handoff.value || "No handoff content"}`
              : "## Previous handoff\n\n- No previous handoff found",
            "",
            "---",
            "Workflow: scan_snippet → code_suggestions → handoff_check",
          ];
          await writeFile(diskPath, briefLines.join("\n"), "utf8");
        } catch {
          // ignore disk write errors
        }
      }

      return formatToolResult({
        agentId: agent.id,
        agentName: agent.name,
        mission,
        gate: gateSummary,
        topIssues,
        suggestedFixes: suggestions,
        previousHandoff: handoff
          ? (() => {
              try {
                return JSON.parse(handoff.value);
              } catch {
                return { raw: String(handoff.value).slice(0, 500) };
              }
            })()
          : null,
        diskPath,
        workflow: [
          "scan_snippet before applying edits",
          "scan_file after saving changes",
          "code_suggestions for deterministic fix hints",
          "handoff_check before claiming done",
        ],
        localOnly: true,
      });
    }),

    // ─── handoff_check ───
    handoff_check: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);
      const agent = pda.autoRegister(root);

      // Check gate status
      let gateResult = null;
      try {
        gateResult = readGateStatus(root, { limit: 12 });
      } catch {
        // no report
      }

      const canFinalize =
        gateResult && gateResult.gate && gateResult.gate.pass === true;
      const blockingCount = gateResult?.gate?.blockingCount || 0;
      const warningCount = gateResult?.gate?.warningCount || 0;

      // Check for open tasks
      let openTasks = [];
      try {
        const tasks = pda.listTasks(root, agent.id, "pending");
        openTasks = tasks.slice(0, 10).map((t) => ({
          id: t.id,
          title: t.title,
          priority: t.priority,
        }));
      } catch {
        // ignore
      }

      const ready = canFinalize && blockingCount === 0 && openTasks.length === 0;

      // Write handoff brief if requested
      let handoffWritten = false;
      if (args?.writeHandoff === true || ready) {
        try {
          const brief = {
            summary: args?.summary || "Session complete",
            completedTasks: args?.completedTasks || [],
            pendingTasks: openTasks.map((t) => t.title),
            notes: args?.notes || "",
            filesChanged: args?.filesChanged || [],
            writtenAt: Date.now(),
            fromAgent: agent.id,
          };
          pda.remember(
            root,
            agent.id,
            "handoff-brief",
            JSON.stringify(brief),
            "handoff",
          );
          handoffWritten = true;
        } catch {
          // ignore
        }
      }

      return formatToolResult({
        ready,
        agentId: agent.id,
        gate: gateResult
          ? {
              pass: gateResult.gate?.pass ?? false,
              blockingCount,
              warningCount,
              qualityScore: gateResult.gate?.qualityScore ?? null,
            }
          : null,
        openTasks,
        openTaskCount: openTasks.length,
        handoffWritten,
        nextAction: ready
          ? "All clear — safe to claim done"
          : blockingCount > 0
            ? `Fix ${blockingCount} blocking issue(s) first`
            : openTasks.length > 0
              ? `Complete ${openTasks.length} open task(s) first`
              : "Run scan_project with gate:true to verify",
      });
    }),

    // ─── scan_staged ───
    scan_staged: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);

      // Get staged files
      let stagedFiles = [];
      try {
        const output = execSync(
          "git diff --cached --name-only --diff-filter=ACM",
          {
            cwd: root,
            encoding: "utf8",
            timeout: 5000,
          },
        );
        stagedFiles = output
          .split("\n")
          .map((f) => f.trim().replace(/\\/g, "/"))
          .filter((f) => f && SCANNABLE_EXT.test(f));
      } catch {
        return formatToolResult({
          error: "Failed to get staged files. Is this a git repository?",
          projectRoot: root,
        });
      }

      if (stagedFiles.length === 0) {
        return formatToolResult({
          pass: true,
          blockingCount: 0,
          stagedFiles: [],
          message: "No staged scannable files — nothing to check",
        });
      }

      // Copy staged files to temp dir and scan
      const tmpDir = path.join(
        os.tmpdir(),
        `sb-staged-${process.pid}-${Date.now()}`,
      );
      try {
        fs.mkdirSync(path.join(tmpDir, ".simplebeacon"), { recursive: true });

        for (const relFile of stagedFiles) {
          const src = path.join(root, relFile);
          const dst = path.join(tmpDir, relFile);
          if (!fs.existsSync(src)) continue;
          fs.mkdirSync(path.dirname(dst), { recursive: true });
          fs.copyFileSync(src, dst);
        }

        // Write minimal config
        const configPath = path.join(tmpDir, ".simplebeacon", "config.json");
        const realConfigPath = path.join(root, ".simplebeacon", "config.json");
        let config = {
          profile: "minimal",
          productionPaths: ["."],
          ignore: ["node_modules/**", ".git/**"],
        };
        try {
          const real = JSON.parse(fs.readFileSync(realConfigPath, "utf8"));
          if (real.allowlist) config.allowlist = real.allowlist;
          if (real.ignore) config.ignore = [...(real.ignore || []), "node_modules/**", ".git/**"];
        } catch {
          // use defaults
        }
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2), "utf8");

        // Run scan
        const { runScan } = require("../../scan");
        const report = runScan({
          projectRoot: tmpDir,
          config,
          gate: true,
          format: "json",
        });

        const blocking =
          (report.detectedIssues || report.rawIssues || []).filter((i) => {
            const s = String(i.severity || "").toLowerCase();
            return s === "critical" || s === "high";
          }) || [];

        return formatToolResult({
          pass: blocking.length === 0,
          blockingCount: blocking.length,
          stagedFiles,
          stagedFileCount: stagedFiles.length,
          blockingIssues: compactIssues(blocking, 12),
          qualityScore: report.qualityScore ?? null,
          localOnly: true,
          methodology: "Staged-files-only gate scan — no code uploaded",
        });
      } catch (err) {
        return formatToolResult({
          error: err.message || "Staged scan failed",
          stagedFiles,
          stagedFileCount: stagedFiles.length,
        });
      } finally {
        // Cleanup temp dir
        try {
          fs.rmSync(tmpDir, { recursive: true, force: true });
        } catch {
          // ignore
        }
      }
    }),

    // ─── agent_status ───
    agent_status: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);
      const agent = pda.autoRegister(root);

      // Gate status
      let gate = null;
      try {
        const gs = readGateStatus(root, { limit: 5 });
        gate = gs?.gate
          ? {
              pass: gs.gate.pass,
              blockingCount: gs.gate.blockingCount,
              warningCount: gs.gate.warningCount,
              qualityScore: gs.gate.qualityScore ?? null,
            }
          : null;
      } catch {
        // no report
      }

      // Open tasks
      let tasks = [];
      try {
        tasks = pda
          .listTasks(root, agent.id, "pending")
          .slice(0, 10)
          .map((t) => ({
            id: t.id,
            title: t.title,
            priority: t.priority,
          }));
      } catch {
        // ignore
      }

      // Recent memories
      let recentMemories = [];
      try {
        const mems = pda.recall(root, agent.id, null, null, {
          allAgents: false,
        });
        recentMemories = mems.slice(-5).map((m) => ({
          key: m.key,
          category: m.category,
          updatedAt: m.updatedAt,
        }));
      } catch {
        // ignore
      }

      // Determine next action
      let nextAction = "Run scan_project to establish gate state";
      if (gate) {
        if (!gate.pass && gate.blockingCount > 0) {
          nextAction = `Fix ${gate.blockingCount} blocking issue(s)`;
        } else if (tasks.length > 0) {
          nextAction = `Complete ${tasks.length} open task(s)`;
        } else if (gate.pass) {
          nextAction = "Gate passed — run handoff_check before claiming done";
        }
      }

      return formatToolResult({
        agentId: agent.id,
        agentName: agent.name,
        gate,
        openTasks: tasks,
        openTaskCount: tasks.length,
        recentMemories,
        nextAction,
        localOnly: true,
      });
    }),

    // ─── code_suggestions ───
    code_suggestions: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);
      const report = await loadReport(root, args?.reportPath);

      if (!report) {
        return formatToolResult({
          error:
            "No scan report found. Run scan_project first, or pass reportPath.",
        });
      }

      const allIssues = report.detectedIssues || report.rawIssues || [];
      const blocking = allIssues.filter((i) => {
        const s = String(i.severity || "").toLowerCase();
        return s === "critical" || s === "high";
      });

      if (blocking.length === 0) {
        return formatToolResult({
          totalSuggestions: 0,
          suggestions: [],
          message: "No blocking issues — no fix suggestions needed",
        });
      }

      // Cross-project pattern learning: collect false-positive patterns
      // from all projects on this machine and suppress matching findings.
      let learnedPatterns = [];
      let crossProjectSuppressed = 0;
      try {
        const crossProjectLearner = require("../../agent-pda/cross-project-learner");
        const homeDir = os.homedir();
        const searchRoots = [path.join(homeDir, "CascadeProjects")];
        const projects = crossProjectLearner.collectProjectData(searchRoots, { maxDepth: 3 });
        if (projects.length > 1) {
          const { patterns } = crossProjectLearner.extractPatterns(projects);
          learnedPatterns = patterns.slice(0, 10).map((p) => ({
            id: p.id,
            title: p.title,
          }));

          // Suppress findings that match known false-positive patterns
          // (e.g. archived files, test fixtures, scanner pattern definitions)
          const suppressiblePatterns = patterns.filter(
            (p) => p.id === "archived-files-block-gate" || p.id === "test-fixture-false-positives",
          );
          if (suppressiblePatterns.length > 0) {
            const before = blocking.length;
            // Don't actually remove from blocking (gate still needs them),
            // but mark them as cross-project suppressed for the agent to see
            for (const issue of blocking) {
              const filePath = String(issue.filePath || issue.path || issue.file || "");
              if (
                filePath.includes("simplebeacon-ignore") ||
                filePath.includes(".test.") ||
                filePath.includes("__tests__") ||
                filePath.includes("test-fixture") ||
                filePath.includes("/archive/") ||
                filePath.endsWith(".bak") ||
                filePath.startsWith("DISABLED_")
              ) {
                issue._crossProjectSuppressed = true;
                crossProjectSuppressed++;
              }
            }
          }
        }
      } catch {
        // Cross-project learning is optional — don't fail if unavailable
      }

      // Build deterministic before/after suggestions
      const { explainFinding } = require("../rule-catalog");
      const suggestions = blocking
        .slice(0, args?.maxSuggestions ? Number(args.maxSuggestions) : 10)
        .map((issue, idx) => {
          const patternId = issue.pattern || issue.rule || issue.type || "";
          let explanation = null;
          try {
            explanation = explainFinding(patternId, { type: issue.type });
          } catch {
            // ignore
          }

          return {
            priority: idx + 1,
            severity: issue.severity,
            type: issue.type || issue.rule || "unknown",
            patternId,
            file: issue.filePath || issue.path || "",
            line: issue.line || null,
            whatItMeans:
              explanation?.description ||
              issue.description ||
              issue.impact ||
              "Review required",
            howToFix:
              issue.fix ||
              issue.recommendedAction ||
              issue.recommendation ||
              explanation?.fixHint ||
              "Manual review required",
            beforeExample: explanation?.beforeExample || null,
            afterExample: explanation?.afterExample || null,
            verificationCommand: explanation?.verifyCommand || null,
          };
        });

      return formatToolResult({
        totalSuggestions: suggestions.length,
        totalBlocking: blocking.length,
        suggestions,
        methodology: "Deterministic rule catalog — no LLM inference",
        learnedPatterns: learnedPatterns.length,
        crossProjectSuppressed,
        crossProjectPatterns: learnedPatterns,
      });
    }),

    // ─── install_agent_plugin ───
    install_agent_plugin: withGuard(async (args) => {
      const root = resolveProjectRoot(args?.projectRoot);
      const hosts = args?.hosts || "universal";

      try {
        const {
          installDeveloperStack,
        } = require("../../lib/developer-onboarding");

        const hostList = String(hosts)
          .split(",")
          .map((h) => h.trim())
          .filter(Boolean);

        const results = [];

        for (const host of hostList) {
          try {
            const stack = installDeveloperStack(root, {
              withMcp: true,
              withCursorRule:
                host === "cursor" ||
                host === "windsurf" ||
                host === "all" ||
                host === "universal",
              withCi: false,
              force: args?.force === true,
              host,
            });
            results.push({
              host,
              mcp: stack.mcp
                ? { created: !!stack.mcp.created, path: stack.mcp.path }
                : null,
              cursorRule: stack.cursorRule
                ? {
                    created: !!stack.cursorRule.created,
                    path: stack.cursorRule.path,
                  }
                : null,
            });
          } catch (err) {
            results.push({
              host,
              error: err.message,
            });
          }
        }

        return formatToolResult({
          success: true,
          projectRoot: root,
          hosts: hostList,
          results,
          nextSteps: [
            "Reload your IDE to pick up the new MCP configuration",
            "Start a new session and call supercharge_agent",
          ],
        });
      } catch (err) {
        return formatToolResult({
          error: err.message || "Plugin installation failed",
          projectRoot: root,
        });
      }
    }),
  };
}

module.exports = { createAgentHandlers };
