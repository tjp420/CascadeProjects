const fs = require('fs');
const p = 'c:\\Users\\Trevor\\CascadeProjects\\coming-soon\\js\\dashboard\\main.js';
let c = fs.readFileSync(p, 'utf8');

// Update the for loop
const oldLoop = 'for (let i = 1; i <= 13; i++) {';
const newLoop = 'for (let i = 1; i <= 15; i++) {';
if (c.includes(oldLoop)) {
    c = c.replace(oldLoop, newLoop);
    console.log('Updated loop');
} else {
    console.log('Loop not found');
}

// Update moduleKeyMap
const oldMap = "'13': ['fileList', 'repositoryInventory']";
const newMap = "'13': ['fileList', 'repositoryInventory'],\n        '14': ['aiIndicators', 'aiSystemIndicators'],\n        '15': ['governance']";
if (c.includes(oldMap)) {
    c = c.replace(oldMap, newMap);
    console.log('Updated moduleKeyMap');
} else {
    console.log('moduleKeyMap not found');
}

fs.writeFileSync(p, c);
console.log('Done');
