const jwt = require('jsonwebtoken');
const secret = process.env.SIMPLEBEACON_LICENSE_SECRET;
if (!secret) {
    process.stderr.write('Set SIMPLEBEACON_LICENSE_SECRET env var\n');
    process.exit(1);
}

const tier = process.argv[2] || 'instant';
const tierConfig = {
    instant: { projectName: 'Instant Code Hygiene Report', label: 'Instant Code Hygiene Report Token' },
    executive: { projectName: 'Executive Risk Certificate', label: 'Executive Risk Certificate Token' },
    euai: { projectName: 'EU AI Act Sprint', label: 'EU AI Act Sprint Token' },
    universal: { projectName: 'Universal Shield', label: 'Universal Shield Token' },
    custom: { projectName: 'Custom Plan', label: 'Custom Plan Token', features: ['gate','consolidation','mock','roadmap','codebase','reduction','data-quality','debug','npm','compliance','euai','build'] }
};

const cfg = tierConfig[tier] || tierConfig.instant;
const payload = {
    email: 'user@simplebeacon.ai',
    tier: tier,
    features: cfg.features || [],
    clientName: 'User',
    projectName: cfg.projectName
};
const token = jwt.sign(payload, secret, { expiresIn: 7 * 24 * 60 * 60 });

