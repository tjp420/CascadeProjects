/**
 * Upload Routes
 * 
 * Handles codebase uploads via multiple methods:
 * - File uploads (single/multiple, zip archives)
 * - Git repository cloning
 * - Directory monitoring
 * - API integrations
 */

const logger = require('../lib/app-logger.cjs');

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const crypto = require('crypto');
const chokidar = require('chokidar');
const simpleGit = require('simple-git');
const router = express.Router();

/** In-memory upload history (persisted per process; sufficient for dashboard wiring). */
const uploadHistory = [];

function recordUpload(entry) {
    uploadHistory.unshift(entry);
    if (uploadHistory.length > 50) uploadHistory.length = 50;
}

/**
 * Upload history for dashboard recent-uploads list.
 * GET /api/upload/history
 */
router.get('/history', (_req, res) => {
    res.json({ success: true, uploads: uploadHistory });
});

// Upload configuration
const uploadConfig = {
    maxFileSize: process.env.UPLOAD_MAX_SIZE || '100MB',
    allowedTypes: (process.env.UPLOAD_ALLOWED_TYPES || 'js,ts,jsx,tsx,py,html,json,md,txt').split(','),
    tempDir: process.env.UPLOAD_TEMP_DIR || path.join(process.cwd(), 'temp'),
    cleanupInterval: process.env.UPLOAD_CLEANUP_INTERVAL || 3600000, // 1 hour
    maxConcurrentUploads: process.env.UPLOAD_MAX_CONCURRENT || 5
};

// Ensure temp directory exists
async function ensureTempDir() {
    try {
        await fs.access(uploadConfig.tempDir);
    } catch (error) {
        await fs.mkdir(uploadConfig.tempDir, { recursive: true });
    }
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        await ensureTempDir();
        const userDir = path.join(uploadConfig.tempDir, req.user?.id || 'anonymous', Date.now().toString());
        await fs.mkdir(userDir, { recursive: true });
        cb(null, userDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = crypto.randomBytes(16).toString('hex');
        cb(null, `${uniqueSuffix}-${file.originalname}`);
    }
});

const fileFilter = (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().substring(1);
    if (uploadConfig.allowedTypes.includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error(`File type .${ext} not allowed. Allowed types: ${uploadConfig.allowedTypes.join(', ')}`), false);
    }
};

const upload = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: parseSize(uploadConfig.maxFileSize),
        files: 50 // Maximum 50 files per upload
    }
});

// Parse size string to bytes
function parseSize(sizeStr) {
    const units = { B: 1, KB: 1024, MB: 1024 * 1024, GB: 1024 * 1024 * 1024 };
    const match = sizeStr.match(/^(\d+(?:\.\d+)?)\s*(B|KB|MB|GB)$/i);
    if (!match) throw new Error('Invalid size format');
    return parseFloat(match[1]) * units[match[2].toUpperCase()];
}

// Generate unique upload ID
function generateUploadId() {
    return crypto.randomUUID();
}

// Clean up temporary files
async function cleanupTempDir(dirPath, delay = uploadConfig.cleanupInterval) {
    setTimeout(async () => {
        try {
            await fs.rmdir(dirPath, { recursive: true });
            logger.debug(`[Upload] Cleaned up temporary directory: ${dirPath}`);
        } catch (error) {
            logger.warn(`[Upload] Failed to cleanup ${dirPath}:`, error.message);
        }
    }, delay);
}

/**
 * File Upload Endpoint
 * POST /api/upload/files
 */
router.post('/files', upload.array('files'), async (req, res) => {
    const uploadId = generateUploadId();
    const startTime = Date.now();
    
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'No files uploaded'
            });
        }

        const uploadedFiles = req.files.map(file => ({
            id: crypto.randomUUID(),
            originalName: file.originalname,
            filename: file.filename,
            size: file.size,
            type: file.mimetype,
            path: file.path,
            uploadId
        }));

        // Process uploaded files
        const analysis = await processUploadedFiles(uploadedFiles, req.user);

        // Schedule cleanup
        const uploadDir = path.dirname(req.files[0].path);
        cleanupTempDir(uploadDir);

        const processingTime = Date.now() - startTime;

        const responsePayload = {
            success: true,
            uploadId,
            files: uploadedFiles,
            analysis,
            processingTime,
            timestamp: new Date().toISOString()
        };

        recordUpload({
            id: uploadId,
            uploadId,
            name: req.body?.name || uploadedFiles[0]?.originalName || uploadId,
            fileCount: uploadedFiles.length,
            files: uploadedFiles.length,
            size: uploadedFiles.reduce((sum, file) => sum + (file.size || 0), 0),
            status: 'completed',
            uploadDate: responsePayload.timestamp,
            timestamp: responsePayload.timestamp,
            analysis
        });

        res.json(responsePayload);

    } catch (error) {
        console.error('[Upload] File upload error:', error);
        
        // Cleanup on error
        if (req.files && req.files.length > 0) {
            const uploadDir = path.dirname(req.files[0].path);
            cleanupTempDir(uploadDir, 0); // Immediate cleanup
        }

        res.status(500).json({
            success: false,
            error: error.message,
            uploadId
        });
    }
});

/**
 * Git Repository Clone Endpoint
 * POST /api/upload/git
 */
router.post('/git', async (req, res) => {
    const uploadId = generateUploadId();
    const startTime = Date.now();
    
    try {
        const { 
            repoUrl, 
            branch = 'main', 
            accessToken, 
            includeSubmodules = false,
            includeHistory = false 
        } = req.body;

        if (!repoUrl) {
            return res.status(400).json({
                success: false,
                error: 'Repository URL is required'
            });
        }

        // Create temporary directory
        await ensureTempDir();
        const tempDir = path.join(uploadConfig.tempDir, 'git', uploadId);
        await fs.mkdir(tempDir, { recursive: true });

        // Clone repository
        const git = simpleGit();
        const cloneOptions = {
            branch,
            '--depth': includeHistory ? undefined : 1
        };

        if (accessToken) {
            // Add authentication for private repositories
            const authenticatedUrl = repoUrl.replace('https://', `https://${accessToken}@`);
            await git.clone(authenticatedUrl, tempDir, cloneOptions);
        } else {
            await git.clone(repoUrl, tempDir, cloneOptions);
        }

        // Initialize git in the cloned directory for further operations
        const repoGit = simpleGit(tempDir);
        
        if (includeSubmodules) {
            await repoGit.submoduleUpdate();
        }

        // Get repository information
        const repoInfo = await getRepositoryInfo(tempDir, repoGit);

        // Analyze codebase
        const analysis = await analyzeGitRepository(tempDir, repoInfo, req.user);

        // Schedule cleanup
        cleanupTempDir(tempDir);

        const processingTime = Date.now() - startTime;

        res.json({
            success: true,
            uploadId,
            repository: {
                url: repoUrl,
                branch,
                info: repoInfo
            },
            analysis,
            processingTime,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('[Upload] Git clone error:', error);
        
        // Cleanup on error
        const tempDir = path.join(uploadConfig.tempDir, 'git', uploadId);
        cleanupTempDir(tempDir, 0);

        res.status(500).json({
            success: false,
            error: error.message,
            uploadId
        });
    }
});

/**
 * Directory Monitoring Endpoint
 * POST /api/upload/watch
 */
router.post('/watch', async (req, res) => {
    try {
        const { directory, watchSubdirectories = true } = req.body;

        if (!directory) {
            return res.status(400).json({
                success: false,
                error: 'Directory path is required'
            });
        }

        // Validate directory exists and is accessible
        try {
            const stats = await fs.stat(directory);
            if (!stats.isDirectory()) {
                throw new Error('Path is not a directory');
            }
        } catch (error) {
            return res.status(400).json({
                success: false,
                error: `Directory not accessible: ${error.message}`
            });
        }

        // Start file system watcher
        const watcher = chokidar.watch(directory, {
            ignored: /(^|[/\\])\../, // ignore dotfiles
            persistent: true,
            ignoreInitial: false,
            followSymlinks: false,
            depth: watchSubdirectories ? undefined : 0
        });

        const watchId = crypto.randomUUID();
        const watchedFiles = new Set();

        watcher.on('add', async (filePath) => {
            if (shouldWatchFile(filePath)) {
                watchedFiles.add(filePath);
                const analysis = await analyzeFile(filePath, req.user);
                
                // Emit real-time update via WebSocket
                if (req.io) {
                    req.io.emit('file-added', {
                        watchId,
                        filePath,
                        analysis,
                        timestamp: new Date().toISOString()
                    });
                }
            }
        });

        watcher.on('change', async (filePath) => {
            if (watchedFiles.has(filePath)) {
                const analysis = await analyzeFile(filePath, req.user);
                
                // Emit real-time update via WebSocket
                if (req.io) {
                    req.io.emit('file-changed', {
                        watchId,
                        filePath,
                        analysis,
                        timestamp: new Date().toISOString()
                    });
                }
            }
        });

        watcher.on('unlink', (filePath) => {
            watchedFiles.delete(filePath);
            
            // Emit real-time update via WebSocket
            if (req.io) {
                req.io.emit('file-removed', {
                    watchId,
                    filePath,
                    timestamp: new Date().toISOString()
                });
            }
        });

        // Store watcher for cleanup
        if (!global.activeWatchers) {
            global.activeWatchers = new Map();
        }
        global.activeWatchers.set(watchId, {
            watcher,
            directory,
            userId: req.user?.id,
            startedAt: new Date().toISOString()
        });

        res.json({
            success: true,
            watchId,
            directory,
            watching: true,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('[Upload] Directory watch error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * Stop Directory Monitoring
 * DELETE /api/upload/watch/:watchId
 */
router.delete('/watch/:watchId', async (req, res) => {
    try {
        const { watchId } = req.params;

        if (!global.activeWatchers || !global.activeWatchers.has(watchId)) {
            return res.status(404).json({
                success: false,
                error: 'Watch session not found'
            });
        }

        const watchSession = global.activeWatchers.get(watchId);
        await watchSession.watcher.close();
        global.activeWatchers.delete(watchId);

        res.json({
            success: true,
            message: 'Directory monitoring stopped',
            watchId
        });

    } catch (error) {
        console.error('[Upload] Stop watch error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * API Integration Endpoint
 * POST /api/upload/api/:provider
 */
router.post('/api/:provider', async (req, res) => {
    try {
        const { provider } = req.params;
        const { repositoryUrl, accessToken } = req.body;

        if (!repositoryUrl) {
            return res.status(400).json({
                success: false,
                error: 'Repository URL is required'
            });
        }

        // Provider-specific integration
        let analysis;
        switch (provider.toLowerCase()) {
            case 'github':
                analysis = await handleGitHubIntegration(repositoryUrl, accessToken, req.user);
                break;
            case 'gitlab':
                analysis = await handleGitLabIntegration(repositoryUrl, accessToken, req.user);
                break;
            case 'bitbucket':
                analysis = await handleBitbucketIntegration(repositoryUrl, accessToken, req.user);
                break;
            default:
                return res.status(400).json({
                    success: false,
                    error: `Unsupported provider: ${provider}`
                });
        }

        res.json({
            success: true,
            provider,
            repository: repositoryUrl,
            analysis,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('[Upload] API integration error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Helper functions

async function processUploadedFiles(files, _user) {
    // This would integrate with your existing GGUF analysis pipeline
    const analysis = {
        totalFiles: files.length,
        totalSize: files.reduce((sum, file) => sum + file.size, 0),
        fileTypes: {},
        issues: [],
        recommendations: [],
        processingTime: 0
    };

    // Analyze file types
    files.forEach(file => {
        const name = file.originalName || file.originalname || '';
        const ext = path.extname(name).toLowerCase();
        analysis.fileTypes[ext] = (analysis.fileTypes[ext] || 0) + 1;
    });

    // Mock analysis results (replace with real GGUF integration)
    analysis.issues = [
        { type: 'warning', message: 'Large file detected', file: files[0]?.originalName },
        { type: 'info', message: 'Code analysis complete', count: files.length }
    ];

    analysis.recommendations = [
        'Consider splitting large files',
        'Add unit tests for critical components',
        'Review code quality metrics'
    ];

    return analysis;
}

async function getRepositoryInfo(tempDir, git) {
    try {
        const log = await git.log({ maxCount: 1 });
        const remotes = await git.getRemotes(true);
        const status = await git.status();

        return {
            latestCommit: log.latest,
            remotes: remotes.map(remote => ({
                name: remote.name,
                url: remote.refs.fetch || remote.refs.push
            })),
            status: status,
            isClean: status.isClean()
        };
    } catch (error) {
        logger.warn('[Upload] Failed to get repository info:', error.message);
        return {};
    }
}

async function analyzeGitRepository(tempDir, repoInfo, _user) {
    // Scan directory for files
    const files = await scanDirectory(tempDir);
    
    const analysis = {
        repository: repoInfo,
        totalFiles: files.length,
        fileTypes: {},
        languages: {},
        size: await getDirectorySize(tempDir),
        issues: [],
        recommendations: [],
        metrics: {
            complexity: 'medium',
            quality: 'good',
            maintainability: 'high'
        }
    };

    // Analyze file types and languages
    files.forEach(file => {
        const ext = path.extname(file).toLowerCase();
        analysis.fileTypes[ext] = (analysis.fileTypes[ext] || 0) + 1;
        
        // Language detection
        const language = detectLanguage(ext);
        analysis.languages[language] = (analysis.languages[language] || 0) + 1;
    });

    // Mock analysis results (replace with real GGUF integration)
    analysis.issues = [
        { type: 'info', message: 'Repository analysis complete', count: files.length },
        { type: 'warning', message: 'Large repository size detected', size: analysis.size }
    ];

    analysis.recommendations = [
        'Optimize repository structure',
        'Add comprehensive documentation',
        'Implement automated testing'
    ];

    return analysis;
}

async function analyzeFile(filePath, _user) {
    try {
        const stats = await fs.stat(filePath);
        const content = await fs.readFile(filePath, 'utf8');
        
        return {
            file: filePath,
            size: stats.size,
            lines: content.split('\n').length,
            language: detectLanguage(path.extname(filePath)),
            lastModified: stats.mtime,
            issues: [
                { type: 'info', message: 'File analyzed successfully' }
            ]
        };
    } catch (error) {
        return {
            file: filePath,
            error: error.message,
            issues: [
                { type: 'error', message: 'Failed to analyze file' }
            ]
        };
    }
}

function shouldWatchFile(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    return uploadConfig.allowedTypes.includes(ext.substring(1));
}

async function scanDirectory(dirPath, files = []) {
    const items = await fs.readdir(dirPath, { withFileTypes: true });
    
    for (const item of items) {
        const fullPath = path.join(dirPath, item.name);
        
        if (item.isDirectory() && !item.name.startsWith('.')) {
            await scanDirectory(fullPath, files);
        } else if (item.isFile() && shouldWatchFile(fullPath)) {
            files.push(fullPath);
        }
    }
    
    return files;
}

async function getDirectorySize(dirPath) {
    let totalSize = 0;
    
    try {
        const items = await fs.readdir(dirPath, { withFileTypes: true });
        
        for (const item of items) {
            const fullPath = path.join(dirPath, item.name);
            
            if (item.isDirectory()) {
                totalSize += await getDirectorySize(fullPath);
            } else if (item.isFile()) {
                const stats = await fs.stat(fullPath);
                totalSize += stats.size;
            }
        }
    } catch (error) {
        logger.warn(`[Upload] Failed to calculate directory size for ${dirPath}:`, error.message);
    }
    
    return totalSize;
}

function detectLanguage(ext) {
    const languageMap = {
        '.js': 'JavaScript',
        '.ts': 'TypeScript',
        '.jsx': 'JavaScript',
        '.tsx': 'TypeScript',
        '.py': 'Python',
        '.html': 'HTML',
        '.json': 'JSON',
        '.md': 'Markdown',
        '.txt': 'Text',
        '.css': 'CSS',
        '.scss': 'SCSS',
        '.less': 'Less',
        '.xml': 'XML',
        '.yaml': 'YAML',
        '.yml': 'YAML',
        '.sql': 'SQL',
        '.sh': 'Shell',
        '.bat': 'Batch',
        '.java': 'Java',
        '.cpp': 'C++',
        '.c': 'C',
        '.cs': 'C#',
        '.php': 'PHP',
        '.rb': 'Ruby',
        '.go': 'Go',
        '.rs': 'Rust',
        '.swift': 'Swift',
        '.kt': 'Kotlin'
    };
    
    return languageMap[ext] || 'Unknown';
}

// API Integration Handlers (placeholders for now)
async function handleGitHubIntegration(_repoUrl, _accessToken, _user) {
    // GitHub API integration implementation
    return {
        provider: 'GitHub',
        integration: 'connected',
        features: ['issues', 'pull requests', 'actions'],
        analysis: 'GitHub repository connected successfully'
    };
}

async function handleGitLabIntegration(_repoUrl, _accessToken, _user) {
    // GitLab API integration implementation
    return {
        provider: 'GitLab',
        integration: 'connected',
        features: ['merge requests', 'pipelines', 'issues'],
        analysis: 'GitLab repository connected successfully'
    };
}

async function handleBitbucketIntegration(_repoUrl, _accessToken, _user) {
    // Bitbucket API integration implementation
    return {
        provider: 'Bitbucket',
        integration: 'connected',
        features: ['pull requests', 'pipelines', 'issues'],
        analysis: 'Bitbucket repository connected successfully'
    };
}

module.exports = router;
