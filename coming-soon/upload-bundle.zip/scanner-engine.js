// ============================================================================
// SimpleBeacon Universal Scanner — Language Plugin Architecture (Phase 1)
// ============================================================================

/**
 * Extract up to `max` regex matches from text with line numbers and context.
 * Module-level utility for use by all language analyzers.
 */
function extractMatches(text, pattern, maxMatches = 5, redact = false) {
    const matches = [];
    const lines = text.split('\n');
    const regex = new RegExp(pattern.source || pattern, pattern.flags || 'i');
    for (let li = 0; li < lines.length && matches.length < maxMatches; li++) {
        const line = lines[li];
        if (regex.test(line)) {
            let snippet = line.trim().slice(0, 120);
            if (redact) {
                snippet = snippet.replace(/(=\s*['"]?)[A-Za-z0-9_\-]{8,}(['"]?)/g, '$1***REDACTED***$2')
                    .replace(/(:\s*['"]?)[A-Za-z0-9_\-]{8,}(['"]?)/g, '$1***REDACTED***$2');
            }
            matches.push({
                line: li + 1,
                snippet: snippet,
                context: [
                    lines[Math.max(0, li - 1)]?.trim().slice(0, 100) || null,
                    snippet,
                    lines[Math.min(lines.length - 1, li + 1)]?.trim().slice(0, 100) || null
                ].filter(Boolean)
            });
        }
    }
    return matches;
}

/**
 * Build a prioritized list of suggested fixes from all finding collections.
 * Each fix includes file, line, action, estimated effort, current/replacement code,
 * surrounding context, suggested patch, and verification command for AI agents.
 */
function buildSuggestedFixes(collections) {
    const severityRank = { critical: 0, high: 1, medium: 2, low: 3 };
    const fixes = [];
    const typeToSeverity = {
        'Credential Pattern': 'medium',
        'Sensitive Data Exposure': 'high',
        'Database Anti-Pattern': 'high',
        'Missing Security Header': 'medium',
        'Configuration Drift': 'medium',
        'Accessibility Gap': 'medium',
        'Debug Artifact': 'low',
        'AI Residue': 'low',
        'Performance Anti-Pattern': 'low',
        'Type Safety Gap': 'low',
        'Documentation Gap': 'low',
        'Missing Test Coverage': 'low',
        'i18n Issue': 'low',
        'Framework Practice Issue': 'low',
        'Workspace Health Issue': 'low',
        'Unused Dependency': 'low',
        'API Contract Drift': 'low',
        'High Complexity': 'low',
        'License/Governance Marker': 'low',
        'AI System Indicator': 'low'
    };
    const typeToFix = {
        'Credential Pattern': 'Replace hardcoded secrets with environment variables',
        'Sensitive Data Exposure': 'Sanitize logs && remove PII from source',
        'Database Anti-Pattern': 'Use parameterized queries && add LIMIT/OFFSET',
        'Missing Security Header': 'Add helmet middleware or reverse-proxy headers',
        'Configuration Drift': 'Move secrets to .env && inject URLs via env vars',
        'Accessibility Gap': 'Add alt text, aria-labels, && associate labels with inputs',
        'Debug Artifact': 'Remove console.log, debugger, && alert statements',
        'AI Residue': 'Replace stubs with real implementations && modernize deprecated APIs',
        'Performance Anti-Pattern': 'Optimize nested loops && debounce event handlers',
        'Type Safety Gap': 'Replace any with specific types && add PropTypes',
        'Documentation Gap': 'Add JSDoc/docstrings to exported functions',
        'Missing Test Coverage': 'Implement skipped tests && remove empty placeholders',
        'i18n Issue': 'Wrap UI strings in t()/i18n() functions',
        'Framework Practice Issue': 'Add useEffect dependency arrays && unsubscribe properly',
        'Workspace Health Issue': 'Refactor shared code into common packages',
        'Unused Dependency': 'Remove unused packages from package.json',
        'API Contract Drift': 'Sync OpenAPI spec with implementation',
        'High Complexity': 'Extract helper functions && reduce nesting with early returns',
        'License/Governance Marker': 'Review license compatibility with distribution model',
        'AI System Indicator': 'Review AI SDK usage for EU AI Act compliance'
    };
    const typeToAutoFixable = {
        'Debug Artifact': true,
        'AI Residue': true,
        'Unused Dependency': true,
        'i18n Issue': true,
        'Documentation Gap': true,
        'Missing Test Coverage': false,
        'Credential Pattern': false,
        'Sensitive Data Exposure': false,
        'Database Anti-Pattern': false,
        'Missing Security Header': true,
        'Configuration Drift': false,
        'Accessibility Gap': true,
        'Performance Anti-Pattern': false,
        'Type Safety Gap': true,
        'Framework Practice Issue': true,
        'Workspace Health Issue': false,
        'API Contract Drift': false,
        'High Complexity': false,
        'License/Governance Marker': false,
        'AI System Indicator': false
    };
    const typeToVerification = {
        'Debug Artifact': 'npm run lint && grep -r "console\\.log\\|debugger" src/ || echo "Clean"',
        'AI Residue': 'npm run build && npm test',
        'Unused Dependency': 'npx depcheck --json',
        'i18n Issue': 'npm run extract-i18n && npm run test:i18n',
        'Documentation Gap': 'npx jsdoc -c jsdoc.json || npx eslint --ext .js,.ts src/',
        'Missing Test Coverage': 'npm test -- --coverage && npx jest --coverage --collectCoverageFrom="src/**/*.js"',
        'Credential Pattern': 'npx secretlint "**/*" || grep -r "password\\|secret\\|api_key" src/ || echo "Clean"',
        'Sensitive Data Exposure': 'npm run audit:sensitive',
        'Database Anti-Pattern': 'npm test -- db.test.js',
        'Missing Security Header': 'npm run test:security',
        'Configuration Drift': 'node -e "require(\'dotenv\').config()" && npm run config:validate',
        'Accessibility Gap': 'npx pa11y --reporter json $APP_URL || npx axe-core --exit',
        'Performance Anti-Pattern': 'npm run benchmark || npm run test:perf',
        'Type Safety Gap': 'npx tsc --noEmit',
        'Framework Practice Issue': 'npm run lint:hooks && npm test',
        'Workspace Health Issue': 'npm run lint:circular && npm audit',
        'API Contract Drift': 'npx swagger-codegen validate || npm run test:api',
        'High Complexity': 'npx complexity-report src/ || npm run lint:complexity',
        'License/Governance Marker': 'npm run license:check',
        'AI System Indicator': 'npm run compliance:eu-ai-act'
    };
    const seen = new Set();
    Object.entries(collections).forEach(([collectionName, findings]) => {
        if (!Array.isArray(findings)) return;
        findings.forEach(f => {
            const file = f.file || (Array.isArray(f.filePath) ? f.filePath[0] : f.filePath) || 'unknown';
            const matches = f.matches || [];
            const lines = matches.map(m => m.line).filter(Boolean);
            const line = lines[0] || 0;
            const type = f.type || collectionName.replace(/Findings$/, '');
            const key = `${file}:${line}:${type}`;
            if (seen.has(key)) return;
            seen.add(key);
            const severity = f.severity || typeToSeverity[type] || 'low';
            const firstMatch = matches[0] || {};
            const snippet = firstMatch.snippet || '';
            const context = firstMatch.context || [];
            // Build 5-line surrounding context if available
            const surrounding = context.length >= 3 ? context : [snippet];
            // Generate suggested patch (unified diff format)
            let suggestedPatch = '';
            let replacement = '';
            if (type === 'Debug Artifact') {
                replacement = '// REMOVED: debug artifact';
                suggestedPatch = `--- a/${file}\n+++ b/${file}\n@@ -${line},1 +${line},0 @@\n-${snippet}`;
            } else if (type === 'Credential Pattern') {
                replacement = 'const API_KEY = process.env.API_KEY;';
                suggestedPatch = `--- a/${file}\n+++ b/${file}\n@@ -${line},1 +${line},1 @@\n-${snippet}\n+${replacement}`;
            } else if (type === 'i18n Issue') {
                const wrapped = snippet.replace(/['"]([^'"]+)['"]/g, "t('$1')");
                replacement = wrapped;
                suggestedPatch = `--- a/${file}\n+++ b/${file}\n@@ -${line},1 +${line},1 @@\n-${snippet}\n+${replacement}`;
            }
            fixes.push({
                file,
                line,
                type,
                severity,
                severityRank: severityRank[severity] || 99,
                action: f.fix || typeToFix[type] || 'Review && remediate',
                confidence: f.confidence || 0.75,
                snippet: snippet.slice(0, 120),
                currentCode: snippet,
                replacement,
                context: surrounding.slice(0, 5),
                suggestedPatch,
                autoFixable: typeToAutoFixable[type] || false,
                verificationCommand: typeToVerification[type] || 'npm test'
            });
        });
    });
    fixes.sort((a, b) => a.severityRank - b.severityRank || b.confidence - a.confidence);
    return fixes.slice(0, 50);
}

/**
 * Dedupe files requiring changes across all finding collections.
 * Returns a map of file -> array of change descriptions.
 */
function dedupeFileChanges(collections) {
    const files = {};
    Object.entries(collections).forEach(([collectionName, findings]) => {
        if (!Array.isArray(findings)) return;
        findings.forEach(f => {
            const filePaths = Array.isArray(f.filePath) ? f.filePath : [f.file || f.filePath].filter(Boolean);
            const type = f.type || collectionName.replace(/Findings$/, '');
            const action = f.fix || 'Review && remediate';
            filePaths.forEach(fp => {
                if (!fp) return;
                if (!files[fp]) files[fp] = [];
                if (!files[fp].some(e => e.type === type)) {
                    files[fp].push({ type, action, severity: f.severity || 'low' });
                }
            });
        });
    });
    return files;
}

/**
 * Registry of supported languages and their ecosystem metadata.
 * Each entry maps file extensions to root/build artifacts.
 */
const LANGUAGE_REGISTRY = {
    javascript: {
        name: 'JavaScript / Node.js',
        extensions: ['js', 'cjs', 'mjs', 'ts', 'tsx', 'jsx'],
        rootFiles: ['package.json', 'server.cjs'],
        buildChecks: [
            { name: 'package.json', regex: /package\.json$/, critical: true },
            { name: 'Lockfile', regex: /package-lock\.json|yarn\.lock|pnpm-lock\.yaml/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'CHANGELOG', regex: /changelog|changes|history/i, critical: false },
            { name: 'Tests', regex: /test|spec|\.test\.|\.spec\.|__tests__|jest\.config|vitest\.config|cypress/i, critical: true },
            { name: 'CI/CD', regex: /\.github\/workflows|\.gitlab-ci|jenkins|\.circleci|\.travis|azure-pipelines|build\.yml|deploy\.yml/i, critical: true },
            { name: 'Docker', regex: /dockerfile|docker-compose|\.dockerignore/i, critical: false },
            { name: 'Linting/Formatting', regex: /eslint|prettier|\.editorconfig|lint-staged|husky/i, critical: false },
            { name: 'TypeScript Config', regex: /tsconfig|\.ts$/i, critical: false },
            { name: 'Build Tool Config', regex: /(webpack|rollup|vite|esbuild|parcel|babel|gulpfile|gruntfile)/i, critical: false },
            { name: 'Dev Server / HMR', regex: /vite\.config|webpack\.dev|nodemon|live-reload|hmr/i, critical: false },
            { name: '.env.example', regex: /\.env\.example|\.env\.sample|\.env\.template/i, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true },
            { name: 'Build artifacts ignored', regex: null, customCheck: (paths) => !paths.some(p => /\/(dist|build|\.next|out)\//.test(p) && !/node_modules\//.test(p)), critical: true },
            { name: 'Git LFS config', regex: /\.gitattributes/, critical: false },
            { name: 'Build cache config', regex: /\.eslintcache|\.parcel-cache|\.next\/cache/i, critical: false },
            { name: '.npmignore', regex: /\.npmignore/, critical: false }
        ]
    },
    python: {
        name: 'Python',
        extensions: ['py', 'pyw', 'pyi'],
        rootFiles: ['pyproject.toml', 'setup.py', 'requirements.txt'],
        buildChecks: [
            { name: 'pyproject.toml / setup.py', regex: /pyproject\.toml|setup\.py/, critical: true },
            { name: 'requirements.txt', regex: /requirements.*\.txt/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /test|spec|pytest|unittest|tox\.ini/, critical: true },
            { name: 'CI/CD', regex: /\.github\/workflows|\.gitlab-ci|jenkins|\.circleci|\.travis/i, critical: true },
            { name: 'Docker', regex: /dockerfile|docker-compose|\.dockerignore/i, critical: false },
            { name: 'Linting/Formatting', regex: /flake8|pylint|black|isort|mypy/, critical: false },
            { name: '.gitignore', regex: /\.gitignore/, critical: true },
            { name: 'Virtual env config', regex: /\.python-version|Pipfile|poetry\.lock/, critical: false }
        ]
    },
    java: {
        name: 'Java / JVM',
        extensions: ['java', 'kt', 'scala', 'groovy'],
        rootFiles: ['pom.xml', 'build.gradle'],
        buildChecks: [
            { name: 'pom.xml / build.gradle', regex: /pom\.xml|build\.gradle/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /test|spec|junit|testng/, critical: true },
            { name: 'CI/CD', regex: /\.github\/workflows|\.gitlab-ci|jenkins|\.circleci/i, critical: true },
            { name: 'Docker', regex: /dockerfile|docker-compose/i, critical: false },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    },
    go: {
        name: 'Go',
        extensions: ['go'],
        rootFiles: ['go.mod'],
        buildChecks: [
            { name: 'go.mod', regex: /go\.mod/, critical: true },
            { name: 'go.sum', regex: /go\.sum/, critical: true },
            { name: 'Makefile', regex: /makefile/i, critical: false },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /_test\.go$/, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    },
    rust: {
        name: 'Rust',
        extensions: ['rs'],
        rootFiles: ['Cargo.toml'],
        buildChecks: [
            { name: 'Cargo.toml', regex: /Cargo\.toml/, critical: true },
            { name: 'Cargo.lock', regex: /Cargo\.lock/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /#\[test\]|#\[cfg\(test\)\]/, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    },
    php: {
        name: 'PHP',
        extensions: ['php'],
        rootFiles: ['composer.json'],
        buildChecks: [
            { name: 'composer.json', regex: /composer\.json/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /test|spec|phpunit/, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    },
    ruby: {
        name: 'Ruby',
        extensions: ['rb'],
        rootFiles: ['Gemfile'],
        buildChecks: [
            { name: 'Gemfile', regex: /Gemfile/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /test|spec|rspec/, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    },
    dotnet: {
        name: '.NET',
        extensions: ['cs', 'vb'],
        rootFiles: ['.csproj', '.sln'],
        buildChecks: [
            { name: '.csproj / .sln', regex: /\.csproj|\.sln/, critical: true },
            { name: 'README', regex: /readme\.?/i, critical: true },
            { name: 'Tests', regex: /test|spec|xunit|nunit|mstest/, critical: true },
            { name: '.gitignore', regex: /\.gitignore/, critical: true }
        ]
    }
};

/**
 * Registry of analyzer patterns keyed by analyzer ID.
 * Each entry declares which languages it applies to and its detection rules.
 */
const PATTERN_REGISTRY = {
    aiIndicators: {
        id: 'aiIndicators',
        name: 'AI System Indicator',
        appliesTo: ['javascript'],
        severity: 'low',
        pattern: /\bnew\s+openai\b|\brequire\s*\(\s*['"]openai['"]\s*\)|\bimport\s+.*\bopenai\b|\bfrom\s+['"]openai['"]\b|\bfrom\s+['"]@anthropic\/[^'"]+['"]\b|\bnew\s+anthropic\b|\bimport\s+.*\blangchain\b|\bfrom\s+['"]langchain['"]\b|\brequire\s*\(\s*['"]langchain['"]\s*\)|\bfrom\s+['"]huggingface_hub['"]\b|\bimport\s+.*\bhuggingface_hub\b|\brequire\s*\(\s*['"]huggingface_hub['"]\s*\)|\b\.create\s*\(\s*\{\s*model\s*:\s*['"]gpt|\b\.create\s*\(\s*\{\s*model\s*:\s*['"]claude|\bcreateChatCompletion\s*\(|\bopenai\.chat\.completions\b|\banthropic\.messages\.create\b|\bazure\.openai\b/i,
        maxMatches: 5,
        selfReferenceFilter: /(?:const|let|var)\s+aiPattern\b/,
        message: 'AI SDK usage detected. Review EU AI Act Article 6 applicability.'
    },
    credentials: {
        id: 'credentials',
        name: 'Credential Pattern',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'medium',
        pattern: /password\s*=\s*['"][^'"]{6,}|api[_-]?key\s*=\s*['"][a-z0-9]{12,}|secret[_-]?key\s*=\s*['"][a-z0-9]{12,}|private_key\s*=\s*['"][^'"]{8,}|aws_access_key_id\s*=\s*['"][A-Z0-9]{16,}|API_KEY\s*=\s*['"][A-Za-z0-9_\-]{16,}|SECRET\s*=\s*['"][A-Za-z0-9_\-]{12,}|AUTH_TOKEN\s*=\s*['"][A-Za-z0-9_\-]{12,}/i,
        maxMatches: 3,
        redact: true,
        selfReferenceFilter: /PATTERN_REGISTRY|TEST_CASES|shouldMatch|shouldNotMatch|test.*password|test.*api_key|mockFileContent|REDACTED|trello-board|test-all-patterns/i,
        message: 'Potential hardcoded secret detected. Move to environment variables or secret manager.'
    },
    debugArtifacts: {
        id: 'debugArtifacts',
        name: 'Debug Artifact',
        appliesTo: ['javascript'],
        severity: 'low',
        pattern: /\bconsole\.(log|warn|error|info|debug|table|trace|dir|group)\s*\(|\bdebugger\b|\balert\s*\(|\bprompt\s*\(|\bconfirm\s*\(/i,
        maxMatches: 3,
        selfReferenceFilter: /console\.error\(['"]\s*(?:Failed|Unhandled|Uncaught|Error|❌|⚠️)|console\.warn\(`?⚠️|console\.log\(['"]\[[Simplebeacon]|console\.log\(`?\[Simplebeacon\]|process\.on\(|Unhandled Rejection|Uncaught Exception|SIMPLEBEACON_LANDING|Auto-enabled|Auto-detected|Found|Scanning|Filtering|Excluding|Discovery|Progress|Stage|Hash|Token|Report|Certificate|Module|Dashboard|Audit|Copy|Upload|Export|Download|Generate|Restore|Clear|Reset|Loading|Done|Complete|Success|Pass|Fail|Error|Warn|Info|Debug|Todo|Fix|Note|Skip|Ignore|Merge|Split|Move|Rename|Delete|Create|Update|Insert|Append|Prepend|Push|Pop|Shift|Unshift|Sort|Filter|Map|Reduce|Find|Index|Slice|Splice|Join|Split|Trim|Replace|Match|Search|Test|Exec|Compile|Build|Deploy|Release|Version|Tag|Branch|Commit|Push|Pull|Fetch|Clone|Checkout|Reset|Revert|Stash|Apply|Drop|Clean|Status|Log|Diff|Blame|Show|Grep|Branch|Merge|Rebase|Cherry|Revert|Tag|Remote|Submodule|Worktree|Sparse|Index|Pack|Unpack|GC|FSCK|Reflog|Hook|Config|Attribute|Ignore|Mailmap|Repl|Bisect|Bugreport|Verify|Maintenance/i,
        message: 'Development-only debug artifact. Remove before production builds.'
    },
    governance: {
        id: 'governance',
        name: 'License/Governance Marker',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /SPDX-License-Identifier|MIT License|Apache License|GNU General Public License|All rights reserved|Copyright \(c\)|License: /i,
        maxMatches: 3,
        message: 'License or copyright marker detected. Verify open-source compatibility.'
    },
    pythonDebug: {
        id: 'pythonDebug',
        name: 'Python Debug Artifact',
        appliesTo: ['python'],
        severity: 'low',
        pattern: /\bprint\s*\(|\bpprint\s*\(|\blogging\.debug\s*\(|\bbreakpoint\s*\(/i,
        maxMatches: 3,
        message: 'Python debug artifact (print, pprint, breakpoint) detected. Remove before production builds.'
    },
    javaDebug: {
        id: 'javaDebug',
        name: 'Java Debug Artifact',
        appliesTo: ['java'],
        severity: 'low',
        pattern: /\bSystem\.(out|err)\.(print|println)\s*\(|\be\.printStackTrace\s*\(|\bjava\.util\.logging\./i,
        maxMatches: 3,
        message: 'Java debug artifact (System.out.print, e.printStackTrace) detected. Use logging framework in production.'
    },
    pythonFramework: {
        id: 'pythonFramework',
        name: 'Python Framework Config Issue',
        appliesTo: ['python'],
        severity: 'low',
        pattern: /\bDEBUG\s*=\s*True\b|\bapp\.run\s*\(\s*[^)]*debug\s*=\s*True/i,
        maxMatches: 3,
        message: 'Python framework running in debug mode (DEBUG=True). Disable before production deployment.'
    },
    javaFramework: {
        id: 'javaFramework',
        name: 'Java Framework Config Issue',
        appliesTo: ['java'],
        severity: 'medium',
        pattern: /spring\.datasource\.(password|url)\s*=\s*['"][^'"]{4,}|log4j.*CVE|log4shell|jndi:ldap/i,
        maxMatches: 3,
        redact: true,
        message: 'Java framework configuration issue: hardcoded datasource or log4j vulnerability reference detected.'
    },
    goDebug: {
        id: 'goDebug',
        name: 'Go Debug Artifact',
        appliesTo: ['go'],
        severity: 'low',
        pattern: /\bfmt\.Print(?:ln|f)?\s*\(|\blog\.Print(?:ln|f)?\s*\(|\blog\.Fatal(?:f|ln)?\s*\(|\bpanic\s*\(/i,
        maxMatches: 3,
        message: 'Go debug artifact (fmt.Print, log.Println, panic) detected. Use structured logging in production.'
    },
    goFramework: {
        id: 'goFramework',
        name: 'Go Framework Config Issue',
        appliesTo: ['go'],
        severity: 'low',
        pattern: /\bgin\.SetMode\s*\(\s*gin\.DebugMode|http\.ListenAndServe\s*\(\s*["'][^"']+["']\s*,\s*nil\s*\)/i,
        maxMatches: 3,
        message: 'Go framework config issue: debug mode or bare ListenAndServe without handler detected.'
    },
    rustDebug: {
        id: 'rustDebug',
        name: 'Rust Debug Artifact',
        appliesTo: ['rust'],
        severity: 'low',
        pattern: /\bprintln!\s*\(|\beprintln!\s*\(|\bdbg!\s*\(|\bprint!\s*\(|\bpanic!\s*\(/i,
        maxMatches: 3,
        message: 'Rust debug artifact (println!, dbg!, panic!) detected. Remove before production builds.'
    },
    rustFramework: {
        id: 'rustFramework',
        name: 'Rust Framework Anti-pattern',
        appliesTo: ['rust'],
        severity: 'medium',
        pattern: /\.unwrap\s*\(\s*\)(?:\s*\?\s*\.unwrap\s*\(\s*\))+|\.expect\s*\(\s*["']\s*["']\s*\)/i,
        maxMatches: 3,
        message: 'Rust anti-pattern: unwrap chain or empty expect message detected. Use proper error handling.'
    },
    phpDebug: {
        id: 'phpDebug',
        name: 'PHP Debug Artifact',
        appliesTo: ['php'],
        severity: 'low',
        pattern: /\becho\s+['"]|\bvar_dump\s*\(|\bprint_r\s*\(|\bdie\s*\(|\bexit\s*\(|\bdebug_backtrace\s*\(|\btrigger_error\s*\(/i,
        maxMatches: 3,
        message: 'PHP debug artifact (echo, var_dump, die, exit) detected. Remove before production builds.'
    },
    phpFramework: {
        id: 'phpFramework',
        name: 'PHP Framework Config Issue',
        appliesTo: ['php'],
        severity: 'medium',
        pattern: /APP_DEBUG\s*=>\s*true|APP_ENV\s*=>\s*['"]local['"]|DB::raw\s*\(|mysql_query\s*\(|mysqli_query\s*\(|PDO\s*::\s*query\s*\(/i,
        maxMatches: 3,
        message: 'PHP framework issue: debug mode or raw SQL detected. Review before production.'
    },
    dotnetDebug: {
        id: 'dotnetDebug',
        name: '.NET Debug Artifact',
        appliesTo: ['dotnet'],
        severity: 'low',
        pattern: /\bConsole\.Write(Line)?\s*\(|\bDebug\.Write(Line)?\s*\(|\bTrace\.Write(Line)?\s*\(|\bDebugger\.Break\s*\(/i,
        maxMatches: 3,
        message: '.NET debug artifact (Console.WriteLine, Debug.WriteLine, Debugger.Break) detected. Remove before production builds.'
    },
    dotnetFramework: {
        id: 'dotnetFramework',
        name: '.NET Framework Config Issue',
        appliesTo: ['dotnet'],
        severity: 'medium',
        pattern: /connectionString\s*=\s*["'][^"']{10,}|Integrated\s+Security\s*=\s*false|Server=localhost;|\.UseInMemoryDatabase\s*\(/i,
        maxMatches: 3,
        redact: true,
        message: '.NET framework issue: hardcoded connection string or in-memory database detected. Use secrets management.'
    },
    rubyDebug: {
        id: 'rubyDebug',
        name: 'Ruby Debug Artifact',
        appliesTo: ['ruby'],
        severity: 'low',
        pattern: /\bputs\s+['"]|\bp\s+['"]|\bdebugger\b|\bdebug\s+['"]|\bbinding\.irb\b|\bbinding\.pry\b|\bRails\.logger\.debug\s*\(/i,
        maxMatches: 3,
        message: 'Ruby debug artifact (puts, p, debugger, binding.irb) detected. Remove before production builds.'
    },
    rubyFramework: {
        id: 'rubyFramework',
        name: 'Ruby Framework Anti-pattern',
        appliesTo: ['ruby'],
        severity: 'medium',
        pattern: /\.permit!\s*\)|\bskip_before_action\b|\beval\s*\(|\bsend\s*\(\s*params\[/i,
        maxMatches: 3,
        message: 'Ruby framework anti-pattern: unsafe mass assignment, eval, or dynamic send detected. Review for security risks.'
    },
    aiResidueStub: {
        id: 'aiResidueStub',
        name: 'Stub Implementation',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /function\s+\w+\s*\([^)]*\)\s*\{\s*\/\/\s*TODO|def\s+\w+\s*\([^)]*\):\s*pass\b|public\s+\w+\s+\w+\s*\([^)]*\)\s*\{\s*\/\/\s*implement|TODO\s*:\s*implement|TODO\s*:\s*AI|TODO\s*:\s*generated|\/\/\s*AI\s+generated|\/\/\s*Generated\s+by\s+(ChatGPT|GPT|Claude|Copilot|Gemini|LLM)/i,
        maxMatches: 3,
        message: 'Stub or AI-generated placeholder detected. Replace with actual implementation before production.'
    },
    aiResidueSwallow: {
        id: 'aiResidueSwallow',
        name: 'Error Swallowing',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'medium',
        pattern: /catch\s*\([^)]*\)\s*\{\s*\}|catch\s*\([^)]*\)\s*\{\s*\/\/\s*ignore|catch\s*\([^)]*\)\s*\{\s*console\.(log|warn|error)\s*\(|except\s*[^:]+:\s*pass|catch\s*\([^)]*\)\s*\{\s*return\s*null|catch\s*\([^)]*\)\s*\{\s*return\s*;|rescue\s+=>\s*e\s*#\s*ignore/i,
        maxMatches: 3,
        message: 'Error swallowing anti-pattern detected. Empty catch blocks hide runtime failures.'
    },
    aiResidueDeprecated: {
        id: 'aiResidueDeprecated',
        name: 'Deprecated Pattern',
        appliesTo: ['javascript', 'python', 'java', 'php', 'ruby'],
        severity: 'low',
        pattern: /jQuery\s*\(|\.ajax\s*\(|componentWillMount\s*\(|componentWillReceiveProps\s*\(|shouldComponentUpdate\s*\(|React\.createClass\s*\(|\.getInitialState\s*\(|asyncio\.coroutine|@asyncio\.coroutine|urllib\.urlopen\s*\(|urllib2\.urlopen\s*\(|xrange\s*\(|raw_input\s*\(|apply\s*\(|execfile\s*\(/i,
        maxMatches: 3,
        message: 'Deprecated API or legacy idiom detected. Modernize to current framework standards.'
    },
    aiResidueDeadCode: {
        id: 'aiResidueDeadCode',
        name: 'Dead Code Block',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /\/\*[\s\S]{80,}\*\/(?!\s*\n\s*(?:export|import|const|let|var|function|class|def|public|private|protected|static|if|for|while|switch|try|return))/,
        maxMatches: 2,
        selfReferenceFilter: /^\s*\/\*\*\s*(?:Platform|Production|Shared|Self-hosted|Token engine|Path resolution|Scan|Dashboard|Local|Dev|Test|Config|Setup|Initialize|Build|Deploy|Release|Version|Module|Component|Service|Utility|Helper|API|REST|GraphQL|Webhook|Event|Listener|Handler|Controller|Model|View|Route|Middleware|Plugin|Extension|Library|Package|Dependency|Import|Export|Default|Named|Async|Await|Promise|Callback|Event|Stream|Buffer|File|Path|Dir|FS|OS|Process|Env|Config|Settings|Options|Params|Args|Input|Output|Result|Data|State|Props|Context|Ref|Memo|Effect|Reducer|Store|Action|Dispatch|Subscribe|Observer|Observable|Subject|Behavior|Replay|Async|Await|Promise|Resolve|Reject|Then|Catch|Finally|Try|Throw|Error|Exception|Stack|Trace|Log|Debug|Info|Warn|Assert|Test|Spec|Suite|Case|Step|Hook|Fixture|Mock|Stub|Spy|Fake|Dummy|Sandbox|Context|Scope|Block|Module|Namespace|Global|Local|Window|Document|Element|Node|Component|Fragment|Portal|Suspense|Lazy|Memo|Callback|Ref|Imperative|Forward|Context|Provider|Consumer|Use|Hook|State|Effect|Reducer|Context|Ref|Memo|Callback|Layout|Insertion|Debug|Custom|Build|Deploy|Release|Version|Tag|Branch|Commit|Push|Pull|Fetch|Clone|Checkout|Reset|Revert|Stash|Apply|Drop|Clean|Status|Log|Diff|Blame|Show|Grep|Branch|Merge|Rebase|Cherry|Revert|Tag|Remote|Submodule|Worktree|Sparse|Index|Pack|Unpack|GC|FSCK|Reflog|Hook|Config|Attribute|Ignore|Mailmap|Repl|Bisect|Bugreport|Verify|Maintenance)/i,
        message: 'Large commented-out code block detected. AI assistants often leave dead code behind. Remove or restore.'
    },
    perfNestedLoop: {
        id: 'perfNestedLoop',
        name: 'Performance Anti-Pattern',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /for\s*\([^)]*\)\s*\{[\s\S]{0,80}for\s*\(|for\s+\w+\s+in\s+\w+\s*:[\s\S]{0,80}for\s+\w+\s+in|while\s*\([^)]*\)\s*\{[\s\S]{0,80}while\s*\(/i,
        maxMatches: 3,
        message: 'Nested loops detected. Consider optimization to reduce O(n²) complexity.'
    },
    typeSafetyAny: {
        id: 'typeSafetyAny',
        name: 'Type Safety Gap',
        appliesTo: ['javascript', 'typescript'],
        severity: 'low',
        pattern: /:\s*any\b(?!\s*\[\])|@ts-ignore|@ts-nocheck|: \(\)\s*=>\s*any/i,
        maxMatches: 3,
        message: 'Type safety gap: any type, missing PropTypes, or excessive parameters detected.'
    },
    missingTest: {
        id: 'missingTest',
        name: 'Missing Test Coverage',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /test\.(todo|skip|xit|xtest)\s*\(|describe\.(skip|todo)\s*\(|it\.(skip|todo)\s*\(|pytest\.mark\.skip|^\s*@Disabled\b|func Test.*\{\s*\}/i,
        maxMatches: 3,
        message: 'Empty or skipped test detected. Ensure production code has active coverage.'
    },
    a11yGap: {
        id: 'a11yGap',
        name: 'Accessibility Gap',
        appliesTo: ['javascript', 'typescript', 'html'],
        severity: 'medium',
        pattern: /<img\b(?![^>]*\balt=)[^>]*>|<(input|textarea|select)\b(?![^>]*\b(?:aria-label|aria-labelledby|title|placeholder)=)[^>]*>|<button\b(?![^>]*\b(?:aria-label|aria-labelledby|title)=)[^>]*>\s*<\/button>|<div\b[^>]*\brole=["']button["'](?![^>]*\b(?:aria-label|aria-labelledby|tabindex))[^>]*>/i,
        maxMatches: 3,
        selfReferenceFilter: /<label[^>]*>\s*.*<(input|textarea|select)/i,
        message: 'Missing alt text, unlabeled input, or inaccessible button detected.'
    },
    i18nHardcoded: {
        id: 'i18nHardcoded',
        name: 'i18n Issue',
        appliesTo: ['javascript', 'typescript', 'html', 'vue', 'svelte'],
        severity: 'low',
        pattern: /['"][A-Z][a-zA-Z\s]{2,30}['"]\s*\+|innerHTML\s*=\s*['"][A-Za-z\s]{5,}|textContent\s*=\s*['"][A-Za-z\s]{5,}|document\.title\s*=\s*['"][A-Za-z\s]{3,}/i,
        maxMatches: 3,
        selfReferenceFilter: /toLocaleDateString|toLocaleString|LocaleString|log\(|console\.|send.*email|email.*subject|invoice|Estimated revenue/i,
        message: 'Hardcoded UI string or locale-naive formatting detected. Wrap with i18n function.'
    },
    sensitiveData: {
        id: 'sensitiveData',
        name: 'Sensitive Data Exposure',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'high',
        pattern: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z]{2,}\b|\b\d{3}-\d{2}-\d{4}\b|\b\d{3}-\d{3}-\d{4}\b|console\.(log|warn|error|info)\s*\(\s*(?:user|customer|email|password|token|ssn|phone)|localStorage\.setItem\s*\(\s*['"](?:token|auth|session|password)/i,
        maxMatches: 3,
        redact: true,
        selfReferenceFilter: /\b(?:dev@simplebeacon\.ai|demo@simplebeacon\.ai|test@example\.com|alice@example\.com|trevor_punt@live\.com|audit@simplebeacon\.ai|@live\.com|noreply@|no-reply@|example\.com|localhost|127\.0\.0\.1|0\.0\.0\.0|::1|generate.*token|send.*email|email.*template|outreach|prospect|marketing|invoice|billing|payment|tier|sandbox|demo|test|fixture|mock|sample|dummy|fake|stub)\b/i,
        message: 'Potential PII or sensitive data exposure in logs or storage detected.'
    },
    configDrift: {
        id: 'configDrift',
        name: 'Configuration Drift',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'medium',
        pattern: /localhost:\d+|127\.0\.0\.1:\d+|hardcoded.*url|password\s*=\s*['"]|secret\s*=\s*['"]|api_key\s*=\s*['"]/i,
        maxMatches: 3,
        redact: true,
        message: 'Hardcoded URL, secret, or .env reference detected. Use environment-based configuration.'
    },
    securityHeaders: {
        id: 'securityHeaders',
        name: 'Missing Security Header',
        appliesTo: ['javascript', 'python', 'java', 'go', 'php', 'ruby'],
        severity: 'medium',
        pattern: /Content-Security-Policy|X-Frame-Options|Strict-Transport-Security|Referrer-Policy| helmet\(\)|helmet\s*\.\w+/i,
        maxMatches: 2,
        message: 'Review security header configuration. Ensure CSP, X-Frame-Options, HSTS, and Referrer-Policy are set.'
    },
    dbAntiPattern: {
        id: 'dbAntiPattern',
        name: 'Database Anti-Pattern',
        appliesTo: ['javascript', 'python', 'java', 'go', 'php', 'ruby'],
        severity: 'high',
        pattern: /SELECT\s+.*['"]\s*\+\s*['"]|query\s*\(\s*['"].*\+\s*['"]|raw\s*\(\s*['"].*\$\{|\.findAll\s*\(\s*\)(?!.*limit)|execute\s*\(\s*['"].*\+\s*['"]/i,
        maxMatches: 3,
        message: 'Raw SQL concatenation or unbounded query detected. Use parameterized queries and pagination.'
    },
    frameworkPractice: {
        id: 'frameworkPractice',
        name: 'Framework Practice Issue',
        appliesTo: ['javascript', 'typescript'],
        severity: 'low',
        pattern: /useEffect\s*\(\s*\(\)\s*=>\s*\{[\s\S]{0,60}\}\s*\)(?!.*,\s*\[)|useState\s*\(\s*\)\s*;(?=.*useState\s*\(\s*\))|this\.\$refs\.|ngOnInit\s*\(\s*\)[\s\S]{0,200}(?!.*ngOnDestroy)/i,
        maxMatches: 3,
        message: 'React hook misuse or missing Angular cleanup detected.'
    },
    unusedDep: {
        id: 'unusedDep',
        name: 'Unused Dependency',
        appliesTo: ['javascript', 'typescript'],
        severity: 'low',
        pattern: /package\.json/i,
        maxMatches: 1,
        selfReferenceFilter: /package\.json files found|package\.json inventory|npmAudit\.packageJsonCount|dependencyCount|supplyChainStatus|Remove unused dependencies|node_modules|eslint|jest|ignorePatterns|testPathIgnorePatterns/i,
        message: 'Cross-reference package.json entries against source imports to detect unused dependencies.'
    },
    apiContractDrift: {
        id: 'apiContractDrift',
        name: 'API Contract Drift',
        appliesTo: ['javascript', 'python', 'java', 'go', 'php', 'ruby'],
        severity: 'low',
        pattern: /app\.(get|post|put|delete|patch)\s*\(\s*['"]\/|router\.(get|post|put|delete|patch)\s*\(\s*['"]\/|@app\.|@router\.|openapi|swagger/i,
        maxMatches: 3,
        message: 'REST endpoint or OpenAPI reference detected. Verify frontend consumes all defined routes.'
    },
    complexityMetric: {
        id: 'complexityMetric',
        name: 'High Complexity',
        appliesTo: ['javascript', 'python', 'java', 'go', 'rust', 'php', 'ruby', 'dotnet'],
        severity: 'low',
        pattern: /function\s+\w+\s*\([^)]*\)\s*\{[\s\S]{300,2000}?\}|def\s+\w+\s*\([^)]*\):[\s\S]{300,2000}?(?=\ndef |\nclass |\Z)|if\s*\([^)]*\)\s*\{[\s\S]{0,120}?if\s*\([^)]*\)\s*\{[\s\S]{0,120}?if\s*\(|try\s*\{[\s\S]{0,60}?try\s*\{|for\s*\([^)]*\)\s*\{[\s\S]{0,60}?for\s*\(/i,
        maxMatches: 3,
        message: 'Overly long function or deeply nested control flow detected. Consider refactoring.'
    }
};

/**
 * Schema overlay for each analyzer: category (for routing) and exclusion profile.
 * Adding a new analyzer only requires one line here instead of 15+ scattered edits.
 */
const ANALYZER_SCHEMA = {
    aiIndicators:     { category: 'aiIndicators',  exclusionProfile: 'aiIndicators' },
    credentials:      { category: 'credentials',   exclusionProfile: 'noArtifacts' },
    debugArtifacts:   { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    pythonDebug:      { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    javaDebug:        { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    pythonFramework:  { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    javaFramework:    { category: 'credentials',   exclusionProfile: 'noArtifacts' },
    goDebug:          { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    goFramework:      { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    rustDebug:        { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    rustFramework:    { category: 'credentials',   exclusionProfile: 'noArtifacts' },
    phpDebug:         { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    phpFramework:     { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    dotnetDebug:      { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    dotnetFramework:  { category: 'credentials',   exclusionProfile: 'noArtifacts' },
    rubyDebug:        { category: 'debug',         exclusionProfile: 'sourceCodeOnly' },
    rubyFramework:    { category: 'credentials',   exclusionProfile: 'noArtifacts' },
    aiResidueStub:    { category: 'aiResidue',     exclusionProfile: 'sourceCodeOnly' },
    aiResidueSwallow: { category: 'aiResidue',     exclusionProfile: 'sourceCodeOnly' },
    aiResidueDeprecated:{ category: 'aiResidue',    exclusionProfile: 'sourceCodeOnly' },
    aiResidueDeadCode:{ category: 'aiResidue',     exclusionProfile: 'sourceCodeOnly' },
    perfNestedLoop:   { category: 'performance',   exclusionProfile: 'noBuildArtifacts' },
    typeSafetyAny:    { category: 'typeSafety',    exclusionProfile: 'sourceCodeOnly' },
    missingTest:      { category: 'testCoverage',  exclusionProfile: 'sourceCodeOnly' },
    a11yGap:          { category: 'accessibility', exclusionProfile: 'sourceCodeOnly' },
    i18nHardcoded:    { category: 'i18n',          exclusionProfile: 'sourceCodeOnly' },
    sensitiveData:    { category: 'sensitiveData', exclusionProfile: 'sourceCodeOnly' },
    configDrift:      { category: 'configDrift',   exclusionProfile: 'sourceCodeOnly' },
    securityHeaders:  { category: 'securityHeaders', exclusionProfile: 'sourceCodeOnly' },
    dbAntiPattern:    { category: 'databasePatterns', exclusionProfile: 'sourceCodeOnly' },
    frameworkPractice:{ category: 'frameworkPractices', exclusionProfile: 'sourceCodeOnly' },
    unusedDep:        { category: 'unusedDeps',    exclusionProfile: 'sourceCodeOnly' },
    apiContractDrift: { category: 'apiContract',   exclusionProfile: 'sourceCodeOnly' },
    complexityMetric: { category: 'complexity',      exclusionProfile: 'noBuildArtifacts' }
};

/**
 * Exclusion rules keyed by profile name. Each receives a context object
 * and returns true when the file should be skipped for that analyzer.
 */
const EXCLUSION_RULES = {
    aiIndicators: (ctx) => ctx.isNodeModule || ctx.isTestOutput || ctx.isTestFile || ctx.isSimplebeaconCache || ctx.isScannerArtifact,
    noArtifacts:    (ctx) => ctx.isNodeModule || ctx.isSampleOrTest || ctx.isTypeScriptDef || ctx.isScannerArtifact,
    noNodeModules:  (ctx) => ctx.isNodeModule || ctx.isSimplebeaconCache || ctx.isScannerArtifact,
    noBuildArtifacts: (ctx) => ctx.isNodeModule || ctx.isBuildArtifact || ctx.isSimplebeaconCache || ctx.isScannerArtifact || ctx.isTestFile || ctx.isSampleOrTest,
    sourceCodeOnly: (ctx) => !ctx.isSourceCode || ctx.isNodeModule || ctx.isCiWorkflow || ctx.isTestFile || ctx.isServerEntry || ctx.isSimplebeaconCache || ctx.isScannerArtifact
};

// ============================================================================
// Analyzer Report Schema — drives uniform section generation
// ============================================================================
const REPORT_SECTION_SCHEMA = [
    { section: 'aiResidue', hitsVar: 'aiResidueHits', findingsVar: 'aiResidueFindings', label: 'AI residue pattern', detail: 'stubs, deprecated APIs, error swallowing, dead code' },
    { section: 'performance', hitsVar: 'perfHits', findingsVar: 'perfFindings', label: 'performance anti-pattern', detail: 'nested loops, leaked listeners, inefficient regex' },
    { section: 'typeSafety', hitsVar: 'typeSafetyHits', findingsVar: 'typeSafetyFindings', label: 'type safety gap', detail: 'any types, missing PropTypes, excessive params' },
    { section: 'testCoverage', hitsVar: 'testHits', findingsVar: 'testFindings', label: 'test coverage gap', detail: 'skipped/empty tests' },
    { section: 'accessibility', hitsVar: 'a11yHits', findingsVar: 'a11yFindings', label: 'accessibility gap', detail: 'missing alt, unlabeled inputs' },
    { section: 'i18n', hitsVar: 'i18nHits', findingsVar: 'i18nFindings', label: 'i18n issue', detail: 'hardcoded strings, locale-naive formatting' },
    { section: 'sensitiveData', hitsVar: 'sensitiveDataHits', findingsVar: 'sensitiveDataFindings', label: 'sensitive data exposure', detail: 'PII in logs/storage' },
    { section: 'configDrift', hitsVar: 'configDriftHits', findingsVar: 'configDriftFindings', label: 'configuration drift', detail: 'hardcoded URLs, .env in repo' },
    { section: 'securityHeaders', hitsVar: 'securityHeaderHits', findingsVar: 'securityHeaderFindings', label: 'security header reference', detail: 'Review CSP, X-Frame-Options, HSTS coverage' },
    { section: 'databasePatterns', hitsVar: 'dbPatternHits', findingsVar: 'dbPatternFindings', label: 'database anti-pattern', detail: 'raw SQL concat, unbounded queries' },
    { section: 'frameworkPractices', hitsVar: 'frameworkHits', findingsVar: 'frameworkFindings', label: 'framework practice issue', detail: 'hook misuse, missing cleanup' },
    { section: 'workspaceHealth', hitsVar: 'workspaceHits', findingsVar: 'workspaceFindings', label: 'workspace health issue', detail: 'circular imports, mismatched deps' },
    { section: 'unusedDeps', hitsVar: 'unusedDepHits', findingsVar: 'unusedDepFindings', label: 'unused dependency reference', detail: 'unused deps in package.json' },
    { section: 'apiContract', hitsVar: 'apiContractHits', findingsVar: 'apiContractFindings', label: 'API contract drift', detail: 'unconsumed endpoints, stale OpenAPI' },
    { section: 'complexity', hitsVar: 'complexityHits', findingsVar: 'complexityFindings', label: 'high complexity pattern', detail: 'over-long functions, deep nesting' }
];

/**
 * Build uniform analyzer report sections from schema.
 * `ctx` is an object mapping variable names to their values.
 */
function buildAnalyzerSections(ctx, allowedSections) {
    const result = {};
    for (const s of REPORT_SECTION_SCHEMA) {
        if (!allowedSections.includes(s.section)) continue;
        const findings = ctx[s.findingsVar] || [];
        const hits = ctx[s.hitsVar] || findings.length || 0;
        result[s.section] = {
            [`${s.section}Hits`]: hits,
            [`${s.section}Findings`]: findings.slice(0, 5).map(f => ({
                file: f.file,
                type: f.type,
                matches: f.matches.slice(0, 3).map(m => ({ line: m.line, snippet: m.snippet }))
            })),
            summary: hits > 0
                ? `${hits} ${s.label}(s) detected (${s.detail}).`
                : `No ${s.label}s detected.`
        };
    }
    return result;
}

/**
 * Category collectors route findings to the correct hit counters and arrays.
 * Each collector receives (path, reg, filteredMatches, context).
 */
const CATEGORY_COLLECTORS = {
    aiIndicators: (path, reg, matches, ctx) => {
        ctx.aiHits.push(path);
        ctx.aiFindings.push({ file: path, matches });
        appendTerminalLine(`AI indicator detected: <span style="color:#94A3B8;">${path}</span> (${matches.length} match${matches.length !== 1 ? 'es' : ''})`, 'warn');
    },
    credentials: (path, reg, matches, ctx) => {
        ctx.credentialHits++;
        ctx.credFiles.push(path);
        ctx.credentialFindings.push({ file: path, matches });
    },
    debug: (path, reg, matches, ctx) => {
        ctx.debugHits.push(path);
        ctx.debugFindings.push({ file: path, matches });
    },
    governance: (path, reg, matches, ctx) => {
        ctx.govHits.push(path);
        ctx.govFindings.push({ file: path, matches });
    },
    aiResidue: (path, reg, matches, ctx) => {
        ctx.aiResidueHits++;
        ctx.aiResidueFindings.push({ file: path, type: reg.name, matches });
        appendTerminalLine(`AI residue detected (${reg.name}): <span style="color:#94A3B8;">${path}</span> (${matches.length} match${matches.length !== 1 ? 'es' : ''})`, 'warn');
    },
    performance: (path, reg, matches, ctx) => {
        ctx.perfHits++;
        ctx.perfFindings.push({ file: path, type: reg.name, matches });
    },
    typeSafety: (path, reg, matches, ctx) => {
        ctx.typeSafetyHits++;
        ctx.typeSafetyFindings.push({ file: path, type: reg.name, matches });
    },
    testCoverage: (path, reg, matches, ctx) => {
        ctx.testHits++;
        ctx.testFindings.push({ file: path, type: reg.name, matches });
    },
    accessibility: (path, reg, matches, ctx) => {
        ctx.a11yHits++;
        ctx.a11yFindings.push({ file: path, type: reg.name, matches });
    },
    i18n: (path, reg, matches, ctx) => {
        ctx.i18nHits++;
        ctx.i18nFindings.push({ file: path, type: reg.name, matches });
    },
    sensitiveData: (path, reg, matches, ctx) => {
        ctx.sensitiveDataHits++;
        ctx.sensitiveDataFindings.push({ file: path, type: reg.name, matches });
    },
    configDrift: (path, reg, matches, ctx) => {
        ctx.configDriftHits++;
        ctx.configDriftFindings.push({ file: path, type: reg.name, matches });
    },
    securityHeaders: (path, reg, matches, ctx) => {
        ctx.securityHeaderHits++;
        ctx.securityHeaderFindings.push({ file: path, type: reg.name, matches });
    },
    databasePatterns: (path, reg, matches, ctx) => {
        ctx.dbPatternHits++;
        ctx.dbPatternFindings.push({ file: path, type: reg.name, matches });
    },
    frameworkPractices: (path, reg, matches, ctx) => {
        ctx.frameworkHits++;
        ctx.frameworkFindings.push({ file: path, type: reg.name, matches });
    },
    workspaceHealth: (path, reg, matches, ctx) => {
        ctx.workspaceHits++;
        ctx.workspaceFindings.push({ file: path, type: reg.name, matches });
    },
    unusedDeps: (path, reg, matches, ctx) => {
        ctx.unusedDepHits++;
        ctx.unusedDepFindings.push({ file: path, type: reg.name, matches });
    },
    apiContract: (path, reg, matches, ctx) => {
        ctx.apiContractHits++;
        ctx.apiContractFindings.push({ file: path, type: reg.name, matches });
    },
    complexity: (path, reg, matches, ctx) => {
        ctx.complexityHits++;
        ctx.complexityFindings.push({ file: path, type: reg.name, matches });
    }
};

/**
 * Detect the dominant language of a repository from its file list.
 * Returns the language key with the most matching source files.
 */
function detectDominantLanguage(paths) {
    const counts = {};
    for (const path of paths) {
        const ext = (path.match(/\.([^.]+)$/) || [null, ''])[1].toLowerCase();
        for (const [langKey, config] of Object.entries(LANGUAGE_REGISTRY)) {
            if (config.extensions.includes(ext)) {
                counts[langKey] = (counts[langKey] || 0) + 1;
                break;
            }
        }
    }
    const entries = Object.entries(counts);
    if (entries.length === 0) return 'javascript';
    entries.sort((a, b) => b[1] - a[1]);
    return entries[0][0];
}

/**
 * Return the set of active analyzer IDs for a given language and profile.
 */
function getAnalyzersForLanguage(langKey, profile) {
    const active = [];
    if (profile.checkAi) active.push('aiIndicators');
    if (profile.checkCredentials) active.push('credentials');
    if (profile.checkDebug) {
        active.push('debugArtifacts');
        active.push('pythonDebug');
        active.push('javaDebug');
        active.push('pythonFramework');
        active.push('goDebug');
        active.push('goFramework');
        active.push('rustDebug');
        active.push('phpDebug');
        active.push('dotnetDebug');
        active.push('rubyDebug');
    }
    if (profile.checkGov) active.push('governance');
    if (profile.checkCredentials) active.push('javaFramework');
    if (profile.checkCredentials) active.push('rustFramework');
    if (profile.checkCredentials) active.push('phpFramework');
    if (profile.checkCredentials) active.push('dotnetFramework');
    if (profile.checkCredentials) active.push('rubyFramework');
    if (profile.checkAiResidue) {
        active.push('aiResidueStub');
        active.push('aiResidueSwallow');
        active.push('aiResidueDeprecated');
        active.push('aiResidueDeadCode');
        active.push('perfNestedLoop');
        active.push('typeSafetyAny');
        active.push('missingTest');
        active.push('a11yGap');
        active.push('i18nHardcoded');
        active.push('sensitiveData');
        active.push('configDrift');
        active.push('securityHeaders');
        active.push('dbAntiPattern');
        active.push('frameworkPractice');
        active.push('unusedDep');
        active.push('apiContractDrift');
        active.push('complexityMetric');
    }
    return active.filter(id => {
        const entry = PATTERN_REGISTRY[id];
        return entry && entry.appliesTo.includes(langKey);
    });
}

/**
 * Get all root-file markers for a given language key.
 */
function getRootFilesForLanguage(langKey) {
    const cfg = LANGUAGE_REGISTRY[langKey];
    return cfg ? cfg.rootFiles : [];
}

/**
 * Build readiness checks for the dominant language.
 */
function getBuildChecksForLanguage(langKey) {
    const cfg = LANGUAGE_REGISTRY[langKey];
    return cfg ? cfg.buildChecks : LANGUAGE_REGISTRY.javascript.buildChecks;
}

/**
 * Build EU AI Act control recommendations based on detected AI indicators and governance docs.
 */
function buildEuAiActControls(aiHits, licenseFiles, securityFiles, aiFindings = []) {
    const controls = [];
    const docCount = (licenseFiles?.length || 0) + (securityFiles?.length || 0);
    const hasDocs = docCount > 0;
    const aiCount = aiHits?.length || 0;

    // Scan AI findings for specific prohibited-practice indicators (Art. 5)
    const prohibitedPatterns = [
        /\bface-?api\b|\bfaceapi\b|\bfacial\s+recognition\b|\bfingerprint\b|\biris\s+scan\b|\bbiometric(s)?\b/i,
        /\bsocial\s+scor(e|ing)\b|\bcredit\s+scor(e|ing)\b|\brank\s+(individuals|people|users)\b/i,
        /\bsubliminal\b|\bmicro-target(ing)?\b/i,
        /\bemotion\s+(detection|recognition)\b|\bage\s+(detection|estimation)\b|\bmanipulate\s+user(s)?\b/i
    ];
    const prohibitedHits = [];
    for (const finding of aiFindings) {
        for (const match of finding.matches || []) {
            const snippet = match.snippet || '';
            if (prohibitedPatterns.some(p => p.test(snippet))) {
                prohibitedHits.push({ file: finding.file, snippet: snippet.slice(0, 100) });
                break;
            }
        }
    }
    const prohibitedCount = prohibitedHits.length;

    // Art. 5 — Prohibited AI Practices (only WARN if specific prohibited indicators found)
    controls.push({
        controlId: 'EU-AIA-ART-5',
        title: 'Prohibited AI Practices Audit',
        article: 'Regulation (EU) 2024/1689, Article 5',
        status: prohibitedCount > 0 ? 'WARN' : 'PASS',
        severity: prohibitedCount > 0 ? 'critical' : 'low',
        description: prohibitedCount > 0
            ? `Article 5 prohibits: (a) subliminal techniques, (b) exploitation of vulnerabilities, (c) social scoring by governments, (d) real-time biometric ID in public spaces. ${prohibitedCount} prohibited-practice indicator(s) detected — immediate legal review required.`
            : aiCount > 0
                ? `Article 5 prohibits specific practices (subliminal techniques, exploitation of vulnerabilities, social scoring, biometric ID). ${aiCount} generic AI SDK import(s) detected — none indicate prohibited practices.`
                : 'No AI SDK imports or model inference patterns detected. Article 5 prohibited practices not applicable.',
        evidence: prohibitedCount > 0
            ? `${prohibitedCount} match(es): ${prohibitedHits.map(h => h.file + ' — ' + h.snippet).join('; ')}`
            : aiCount > 0 ? `${aiCount} generic AI SDK import(s) — no prohibited-practice indicators found.` : 'None detected',
        action: prohibitedCount > 0
            ? 'Conduct legal review immediately: the detected patterns suggest the system may perform practices prohibited under Art. 5(1). If confirmed, stop development and redesign.'
            : aiCount > 0
                ? 'No prohibited practices detected. Document the lawful use case for compliance records, but no immediate action required.'
                : 'No action needed — maintain zero-AI posture or document lawful use case.'
    });

    // Art. 6 — Classification as high-risk (Annex III)
    const annexIIIPatterns = [
        { domain: 'law enforcement', pattern: /\b(police|law enforcement|criminal justice|arrest|warrant|patrol|surveillance cam|detention|prison|probation|parole|investigat(e|ion))\b/i },
        { domain: 'migration / border control', pattern: /\b(border|immigration|asylum|visa|refugee|migrant|deportation|customs|passport|entry|exit)\b/i },
        { domain: 'democratic processes', pattern: /\b(election|vote|ballot|campaign|polling|voter|referendum|democratic|candidate)\b/i },
        { domain: 'employment / recruitment', pattern: /\b(recruit|hire|employment|worker|employee|resume|interview|job|candidate|performance review|workplace|HR|human resources|talent)\b/i },
        { domain: 'education', pattern: /\b(student|school|education|university|college|grade|exam|assessment|academic|course|enrollment|admission|curriculum)\b/i },
        { domain: 'healthcare / medical', pattern: /\b(hospital|patient|diagnosis|medical|healthcare|treatment|clinical|prescription|symptom|disease|therapy|surgery)\b/i },
        { domain: 'credit / insurance / finance', pattern: /\b(credit score|credit rating|loan|insurance|underwriting|premium|claim|mortgage|banking|finance|investment)\b/i },
        { domain: 'critical infrastructure / transport', pattern: /\b(transport|traffic|vehicle|aircraft|railway|subway|energy|power grid|utility|water supply|telecommunication|nuclear|dam)\b/i },
        { domain: 'administration of justice', pattern: /\b(judge|court|judicial|trial|legal|litigation|verdict|sentence|evidence|witness)\b/i }
    ];
    const annexIIIMatches = [];
    for (const finding of aiFindings) {
        for (const match of finding.matches || []) {
            const snippet = match.snippet || '';
            for (const { domain, pattern } of annexIIIPatterns) {
                if (pattern.test(snippet)) {
                    annexIIIMatches.push({ domain, file: finding.file, snippet: snippet.slice(0, 80) });
                    break;
                }
            }
        }
    }
    const annexIIIDomains = [...new Set(annexIIIMatches.map(m => m.domain))];
    const isHighRiskDomain = annexIIIMatches.length > 0;

    controls.push({
        controlId: 'EU-AIA-ART-6',
        title: 'AI System Classification (Annex III)',
        article: 'Regulation (EU) 2024/1689, Article 6 & Annex III',
        status: aiCount > 0 ? 'REVIEW' : 'PASS',
        severity: isHighRiskDomain ? 'high' : (aiCount > 0 ? 'medium' : 'low'),
        description: isHighRiskDomain
            ? `Annex III high-risk domain indicator(s) detected: ${annexIIIDomains.join(', ')}. These use cases require a full conformity assessment under Article 6 before deployment.`
            : aiCount > 0
                ? 'Annex III lists high-risk AI systems (critical infrastructure, education, employment, law enforcement, migration, democratic processes). Classification determines conformity obligations.'
                : 'No AI system indicators — Annex III classification not applicable.',
        evidence: isHighRiskDomain
            ? `${annexIIIMatches.length} match(es) across domains: ${annexIIIDomains.join(', ')}. Example: ${annexIIIMatches[0].file} — "${annexIIIMatches[0].snippet}"`
            : aiCount > 0 ? `${aiCount} generic AI indicator(s); ${hasDocs ? docCount + ' governance doc(s) present — verify Annex III classification is explicitly documented' : '0 governance docs — add risk-assessment.md'}` : 'None detected',
        action: isHighRiskDomain
            ? 'URGENT: The detected domain(s) suggest this is a high-risk AI system under Annex III. Conduct a full conformity assessment (Articles 8–15), implement risk management (Article 9), and register the system before deployment.'
            : aiCount > 0
                ? (hasDocs ? 'Review existing governance docs to confirm Annex III classification is explicitly documented. Do not assume presence of docs equals correct classification.' : 'Add risk-assessment.md documenting whether the system is high-risk under Annex III.')
                : 'No action needed.'
    });

    // Art. 10 — Data and Data Governance (training data quality, bias mitigation)
    controls.push({
        controlId: 'EU-AIA-ART-10',
        title: 'Data and Data Governance',
        article: 'Regulation (EU) 2024/1689, Article 10',
        status: aiCount > 0 ? (hasDocs ? 'REVIEW' : 'WARN') : 'PASS',
        severity: aiCount > 0 ? (hasDocs ? 'medium' : 'high') : 'low',
        description: aiCount > 0
            ? 'Article 10 requires that training, validation and testing datasets meet quality criteria: relevance, representativeness, freedom from errors, and completeness. Bias detection and mitigation must be documented.'
            : 'No AI system indicators — data governance obligations not applicable.',
        evidence: aiCount > 0 ? `${aiCount} AI indicator(s); ${hasDocs ? docCount + ' governance doc(s) present — verify data governance coverage' : 'No data governance documentation detected'}` : 'None detected',
        action: aiCount > 0
            ? 'Document dataset provenance, bias assessment methodology, and data quality verification procedures. If using pre-trained models, record provider data governance certifications.'
            : 'No action needed.'
    });

    // Art. 14 — Human Oversight (natural persons must be able to oversee high-risk AI)
    controls.push({
        controlId: 'EU-AIA-ART-14',
        title: 'Human Oversight Measures',
        article: 'Regulation (EU) 2024/1689, Article 14',
        status: aiCount > 0 ? (hasDocs ? 'REVIEW' : 'WARN') : 'PASS',
        severity: aiCount > 0 ? (hasDocs ? 'medium' : 'high') : 'low',
        description: aiCount > 0
            ? 'Article 14 requires high-risk AI systems to be designed so natural persons can effectively oversee them, including the ability to correctly interpret outputs, decide not to use the system, and intervene on operation.'
            : 'No AI indicators — human oversight obligations not applicable.',
        evidence: aiCount > 0 ? `${aiCount} AI indicator(s); ${hasDocs ? docCount + ' governance doc(s) present — verify oversight coverage' : 'No oversight documentation detected'}` : 'None detected',
        action: aiCount > 0
            ? 'Implement and document: (1) human review checkpoints before high-stakes decisions, (2) override/escalation mechanisms, (3) operator training materials, (4) audit trails for human interventions.'
            : 'No action needed.'
    });

    // Art. 50 — Transparency obligations (chatbots, deepfakes)
    controls.push({
        controlId: 'EU-AIA-ART-50',
        title: 'Transparency Obligations',
        article: 'Regulation (EU) 2024/1689, Article 50',
        status: aiCount > 0 ? 'WARN' : 'PASS',
        severity: aiCount > 0 ? 'medium' : 'low',
        description: aiCount > 0
            ? 'Article 50 requires that persons interacting with AI systems are informed they are engaging with an AI (chatbots), and that deep-synthetic content is labelled as artificially generated.'
            : 'No AI indicators — transparency obligations not applicable.',
        evidence: aiCount > 0 ? `${aiCount} AI indicator(s) detected` : 'None detected',
        action: aiCount > 0
            ? 'Verify UI/UX includes AI disclosure notices. If generating images/video/audio, implement synthetic media watermarking or metadata tags.'
            : 'No action needed.'
    });

    // Art. 9 — Risk management system (high-risk only)
    controls.push({
        controlId: 'EU-AIA-ART-9',
        title: 'Risk Management System',
        article: 'Regulation (EU) 2024/1689, Article 9',
        status: aiCount > 0 ? (hasDocs ? 'REVIEW' : 'WARN') : 'PASS',
        severity: aiCount > 0 ? (hasDocs ? 'medium' : 'high') : 'low',
        description: aiCount > 0
            ? 'High-risk AI systems must implement a continuous risk management system throughout the entire lifecycle.'
            : 'No AI indicators — risk management system not applicable.',
        evidence: aiCount > 0 ? `${hasDocs ? docCount + ' doc(s) present — verify risk management coverage' : 'No risk management documentation detected'}` : 'None detected',
        action: aiCount > 0
            ? 'Create or update risk-assessment.md covering: identified risks, estimated likelihood/severity, mitigation measures, residual risk acceptance criteria.'
            : 'No action needed.'
    });

    return controls;
}

async function processLocalCLIScan(files) {
    const localScanFileName = document.getElementById('localScanFileName');
    // Normalize Windows backslashes to forward slashes in all file paths
    for (const f of files) {
        const raw = f.webkitRelativePath || f.name;
        if (raw.includes('\\')) {
            Object.defineProperty(f, 'webkitRelativePath', {
                value: raw.replace(/\\/g, '/'),
                writable: false,
                configurable: true
            });
        }
    }
    // Auto-detect project root: find the directory with the most files
    // that contains package.json, .simplebeacon/, || server.cjs.
    const paths = files.map(f => f.webkitRelativePath || f.name).map(p => p.replace(/\\/g, '/'));
    let rootPrefix = '';
    let detectedRoot = '';

    // Helper: check if a prefix is a valid project root
    function isProjectRoot(prefix) {
        const last = prefix.split('/').pop();
        if (last === '.git' || last === 'node_modules') return false;
        // Check legacy JS markers first
        const hasJsRoot = paths.some(p => p === prefix + '/package.json') ||
                          paths.some(p => p.startsWith(prefix + '/.simplebeacon/')) ||
                          paths.some(p => p === prefix + '/server.cjs');
        if (hasJsRoot) return true;
        // Check all registered language ecosystem markers
        for (const cfg of Object.values(LANGUAGE_REGISTRY)) {
            for (const rootFile of cfg.rootFiles) {
                if (paths.some(p => p === prefix + '/' + rootFile)) return true;
                // Handle wildcard patterns like *.csproj
                if (rootFile.startsWith('*.')) {
                    const ext = rootFile.slice(1);
                    if (paths.some(p => p.startsWith(prefix + '/') && p.endsWith(ext))) return true;
                }
            }
        }
        return false;
    }

    // Try top-level directories first, then one level deeper
    const topSegments = [...new Set(paths.map(p => p.split('/')[0]))];
    let candidate = '';
    for (const top of topSegments) {
        if (isProjectRoot(top)) { candidate = top; break; }
    }
    // If no top-level root found, check immediate subdirectories
    if (!candidate) {
        const subDirs = new Set();
        for (const p of paths) {
            const parts = p.split('/');
            if (parts.length >= 2) subDirs.add(parts[0] + '/' + parts[1]);
        }
        // Pick the subdirectory with the most files that is a project root
        let bestCount = 0;
        for (const sub of subDirs) {
            if (isProjectRoot(sub)) {
                const count = paths.filter(p => p.startsWith(sub + '/')).length;
                if (count > bestCount) { bestCount = count; candidate = sub; }
            }
        }
    }

    if (candidate) {
        rootPrefix = candidate + '/';
        detectedRoot = candidate;
        // Strip prefix from all paths for cleaner reporting, but keep ALL files
        for (const f of files) {
            const raw = f.webkitRelativePath || f.name;
            const normalized = raw.replace(/\\/g, '/');
            if (normalized.startsWith(rootPrefix)) {
                Object.defineProperty(f, 'webkitRelativePath', {
                    value: normalized.slice(rootPrefix.length),
                    writable: false,
                    configurable: true
                });
            }
        }
        if (localScanFileName) {
            appendTerminalLine(`<span style="color:#60A5FA;">&#9432;</span> Auto-detected project root: <strong>${detectedRoot}</strong> — scanning all ${files.length.toLocaleString()} files.`);
        }
    }
    if (localScanFileName) localScanFileName.textContent = `Filtering ${files.length.toLocaleString()} files...`;
    // Defense-in-depth: token must be present
    if (!hasValidToken()) {
        showToast('Paste a license token to unlock scanning.', 'warning');
        licenseInput.focus();
        licenseInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }
    // Abort any previous scan
    if (scanAbortController) {
        scanAbortController.abort();
    }
    scanAbortController = new AbortController();
    const signal = scanAbortController.signal;

    if (dropzonePrompt) dropzonePrompt.style.display = 'none';
    terminalConsole.style.display = 'block';
    panelProgressContainer.style.display = 'block';
    panelMetrics.style.display = 'inline';
    panelStatus.textContent = 'RUNNING_ANALYSIS';
    panelStatus.style.color = '#60A5FA';
    terminalConsole.innerHTML = '';

    const cancelBtn = document.getElementById('cancelScanBtn');
    if (cancelBtn) {
        cancelBtn.style.display = 'inline-block';
        cancelBtn.onclick = () => {
            if (scanAbortController) {
                scanAbortController.abort();
                appendTerminalLine('Scan cancellation requested.', 'warn');
            }
        };
    }
    const downloadLogBtn = document.getElementById('downloadLogBtn');
    if (downloadLogBtn) {
        downloadLogBtn.style.display = 'inline-block';
        downloadLogBtn.onclick = () => {
            const lines = Array.from(terminalConsole.children).map(div => ({
                timestamp: div.querySelector('span')?.textContent || '',
                text: div.textContent || '',
                html: div.innerHTML || ''
            }));
            const payload = {
                exportedAt: new Date().toISOString(),
                command: 'simplebeacon scan .',
                lines
            };
            const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'scan-log-' + new Date().toISOString().slice(0,10) + '.json';
            a.click();
            URL.revokeObjectURL(url);
        };
    }

    try {
    // Scan always runs 'complete' so all modules have data; ZIP filters to selected modules
    const profileKey = 'complete';
    const profile = BROWSER_SCAN_PROFILES[profileKey];
    const allowedSections = PROFILE_SECTIONS[profileKey] || PROFILE_SECTIONS.complete;
    const tier = window._tokenPayload?.tier || window._tokenPayload?.product || 'locked';
    const shouldRedact = tier !== 'executive' && tier !== 'euai' && tier !== 'universal';
    if (browserFolderDropzone) browserFolderDropzone.classList.add('scanning');
    const localScanFileName = document.getElementById('localScanFileName');
    if (localScanFileName) localScanFileName.textContent = `Preparing to scan ${files.length.toLocaleString()} files...`;
    appendTerminalLine('simplebeacon scan .', 'input');
    appendTerminalLine(`Initializing Local Web Worker Core... Profile: ${profile.label}. Allocating isolated browser memory structures.`);
    // Security baseline: only exclude dependency trees by default (user can override via checkbox)
    const includeDeps = document.getElementById('includeDepsToggle')?.checked || false;
    const deepScan = document.getElementById('deepScanToggle')?.checked || false;
    const excludeEnv = false;             // scan all files including .env — credential detection handles false positives
    const skipDeps = false;               // analyze ALL directory files (node_modules/.git included)
    const skipDocs = false;               // scan docs by default — they contain governance markers

    // Pre-scan estimator: warn if node_modules appears included
    const nodeModuleCount = files.filter(f => /node_modules\//.test((f.webkitRelativePath || f.name).toLowerCase())).length;
    const gitCount = files.filter(f => /\.git\//.test((f.webkitRelativePath || f.name).toLowerCase())).length;
    const estTimeSec = Math.round(files.length * 0.003); // ~3ms per file heuristic
    appendTerminalLine(`Discovered targets: evaluation tree containing ${files.length} raw elements.`);
    appendTerminalLine(`Estimator: ~${estTimeSec}s scan time · ${nodeModuleCount} node_modules files · ${gitCount} .git files detected.`);
    if (nodeModuleCount > 100 && !includeDeps) {
        appendTerminalLine(`Note: ${nodeModuleCount} node_modules files will be excluded by default. If you intended to scan source only, this is expected.`, 'success');
    } else if (nodeModuleCount > 100 && includeDeps) {
        appendTerminalLine(`Warning: ${nodeModuleCount} node_modules files will be scanned. Expect slower performance && potential false positives.`, 'warn');
    }
    if (includeDeps) appendTerminalLine('Note: node_modules/.git inclusion enabled — scan will be slower && noisier.', 'warn');
    if (deepScan) appendTerminalLine('DEEP SCAN MODE: All cache, docs, && scanner-page filters bypassed. Only secrets && 500MB+ files are excluded.', 'warn');

    let scanned = 0;
    let totalLines = 0;
    let aiHits = [];
    let credentialHits = 0;
    let credFiles = [];
    let debugHits = [];
    let govHits = [];
    let aiResidueHits = 0;
    let aiResidueFindings = [];
    let perfHits = 0;
    let perfFindings = [];
    let typeSafetyHits = 0;
    let typeSafetyFindings = [];
    let testHits = 0;
    let testFindings = [];
    let a11yHits = 0;
    let a11yFindings = [];
    let i18nHits = 0;
    let i18nFindings = [];
    let sensitiveDataHits = 0;
    let sensitiveDataFindings = [];
    let configDriftHits = 0;
    let configDriftFindings = [];
    let securityHeaderHits = 0;
    let securityHeaderFindings = [];
    let dbPatternHits = 0;
    let dbPatternFindings = [];
    let frameworkHits = 0;
    let frameworkFindings = [];
    let workspaceHits = 0;
    let workspaceFindings = [];
    let unusedDepHits = 0;
    let unusedDepFindings = [];
    let apiContractHits = 0;
    let apiContractFindings = [];
    let complexityHits = 0;
    let complexityFindings = [];
    let mockFiles = [];
    let packageJsonFiles = [];
    let licenseFiles = [];
    let securityFiles = [];
    let emptyJsonFiles = [];
    let totalJsonFiles = 0;
    let duplicateHashes = new Map();
    let duplicateGroups = 0;
    let todoFiles = [];
    const todoMarkerCounts = { TODO: 0, FIXME: 0, HACK: 0, BUG: 0, XXX: 0 };
    let imageFiles = [];
    let unusedAssetCandidates = [];
    let junkFiles = [];
    let monorepoMarkers = 0;
    let totalDependencyCount = 0;
    const fileTypes = {};
    const startTime = Date.now();

    // Rich finding collectors: per-file, per-line findings with context
    const aiFindings = [];
    const credentialFindings = [];
    const debugFindings = [];
    const govFindings = [];
    const bloatFindings = [];

    // 1. Check for user-provided .simplebeaconignore (collect ALL nested ones)
    let ignorePatterns = [];
    const ignoreFiles = files.filter(f => (f.webkitRelativePath || f.name).endsWith('.simplebeaconignore'));
    for (const ignoreFile of ignoreFiles) {
        try { ignorePatterns.push(...parseIgnoreFile(await ignoreFile.text())); } catch (e) { /* ignore parse errors */ }
    }

    appendTerminalLine(`<span style="color:#60A5FA;font-weight:700;">&#9654; Stage 2/3:</span> Filtering ${files.length.toLocaleString()} files (excluding dependencies, secrets, generated artifacts)...`);

    // 2. Filter loop with skip logging
    let skipped = 0;
    const sourceFiles = [];
    const skipReasons = {};
    let filterIdx = 0;
    for (const f of files) {
        filterIdx++;
        const path = (f.webkitRelativePath || f.name).replace(/\\/g, '/');
        const lowerPath = path.toLowerCase();
        let reason = null;

        // All files pass — no exclusions
        sourceFiles.push(f);
        if (filterIdx % 1000 === 0 || filterIdx === files.length) {
            const pct = Math.round((filterIdx / files.length) * 100);
            if (localScanFileName) localScanFileName.textContent = `Filtering ${filterIdx.toLocaleString()} of ${files.length.toLocaleString()} files (${pct}%)...`;
            await new Promise(r => setTimeout(r, 0));
        }
    }

    // Diagnostic: log exclusion breakdown
    appendTerminalLine(`<span style="color:#F59E0B;font-weight:700;">&#128310; Filter Summary:</span> ${sourceFiles.length.toLocaleString()} source files kept · ${skipped.toLocaleString()} excluded`);
    const sortedReasons = Object.entries(skipReasons).sort((a, b) => b[1] - a[1]);
    for (const [reason, count] of sortedReasons.slice(0, 8)) {
        appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> ${reason}: <strong>${count.toLocaleString()}</strong>`);
    }
    if (sortedReasons.length > 8) {
        const rest = sortedReasons.slice(8).reduce((a, [,c]) => a + c, 0);
        appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Other reasons: <strong>${rest.toLocaleString()}</strong>`);
    }

    if (sourceFiles.length < files.length * 0.1) {
        appendTerminalLine(`<span style="color:#60A5FA;">&#9432;</span> Only ${(sourceFiles.length / files.length * 100).toFixed(1)}% of files were analyzed. Check filter summary above for exclusion reasons.`, 'warn');
    }

    // No file cap — analyze all dropped files

    if (deepScan) {
        appendTerminalLine(`Found ${sourceFiles.length.toLocaleString()} source files. (${skipped.toLocaleString()} excluded — only secrets && 500MB+ files skipped.)`, 'success');
    } else {
        appendTerminalLine(`Found ${sourceFiles.length.toLocaleString()} source files. (${skipped.toLocaleString()} dependency/secret/generated files excluded.)`, 'success');
    }

    // File inventory breakdown — show real composition of discovered files
    const inventory = {
        sourceCode: 0, markup: 0, config: 0, docs: 0,
        buildArtifacts: 0, testFixtures: 0, tempDev: 0, other: 0
    };
    for (const f of sourceFiles) {
        const p = (f.webkitRelativePath || f.name).toLowerCase();
        if (/\.(js|cjs|mjs|ts|tsx|jsx|py|java|go|rs|php|rb|cs|swift|kt|scala|dart|vue|svelte)$/i.test(p)) {
            inventory.sourceCode++;
        } else if (/\.(html|css|scss|sass|less)$/i.test(p)) {
            inventory.markup++;
        } else if (/\.(json|yml|yaml|toml|xml|ini|properties|tfvars)$/i.test(p)) {
            inventory.config++;
        } else if (/\.(md|txt|rst)$/i.test(p)) {
            inventory.docs++;
        } else if (/\/(frontend-build|dist|build|\.next|out|coverage)[\/]|\.(map|chunk\.js)$/i.test(p)) {
            inventory.buildArtifacts++;
        } else if (/\/(test-cert|java-ai-vulnerable|simplebeacon-rule-tests|__tests__|mocks|fixtures)[\/]|\.(test|spec)\./i.test(p)) {
            inventory.testFixtures++;
        } else if (/(^|[\/])(tmp-|temp_|fix_|patch_|repair_|deploy-)[^\/]*\.js$/i.test(p)) {
            inventory.tempDev++;
        } else {
            inventory.other++;
        }
    }
    appendTerminalLine(`<span style="color:#60A5FA;font-weight:700;">&#128200; File Inventory:</span> ${sourceFiles.length.toLocaleString()} total files`);
    appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Source code: <strong>${inventory.sourceCode.toLocaleString()}</strong>`);
    appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Markup/style: <strong>${inventory.markup.toLocaleString()}</strong>`);
    appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Config/data: <strong>${inventory.config.toLocaleString()}</strong>`);
    appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Documentation: <strong>${inventory.docs.toLocaleString()}</strong>`);
    if (inventory.buildArtifacts > 0) appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Build artifacts: <strong>${inventory.buildArtifacts.toLocaleString()}</strong>`);
    if (inventory.testFixtures > 0) appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Test fixtures: <strong>${inventory.testFixtures.toLocaleString()}</strong>`);
    if (inventory.tempDev > 0) appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Temp/dev files: <strong>${inventory.tempDev.toLocaleString()}</strong>`);
    if (inventory.other > 0) appendTerminalLine(`  <span style="color:#64748B;">&#10148;</span> Other: <strong>${inventory.other.toLocaleString()}</strong>`);

    if (localScanFileName) localScanFileName.textContent = `Scanning ${sourceFiles.length.toLocaleString()} files...`;
    appendTerminalLine(`<span style="color:#60A5FA;font-weight:700;">&#9654; Stage 3/3:</span> Scanning ${sourceFiles.length.toLocaleString()} source files across 15 analysis engines...`);

    // 3. Heuristic scan loop
    // Web Worker for large repositories — offloads scanning from main thread
    let scanWorker = null;
    if (sourceFiles.length >= 1000 && typeof Worker !== 'undefined') {
        try {
            scanWorker = new Worker('js/scan-worker.js');
            appendTerminalLine('Web Worker initialized for background scanning.', 'success');
        } catch (err) {
            appendTerminalLine('Web Worker unavailable — falling back to main-thread scan.', 'warn');
        }
    }
    if (scanWorker) {
        scanWorker.onmessage = (e) => {
            const msg = e.data;
            if (msg.type === 'progress') {
                const pct = Math.round((msg.processed / msg.total) * 100);
                panelProgressBar.style.width = pct + '%';
                if (localScanFileName) localScanFileName.textContent = `Worker scanning ${msg.processed.toLocaleString()} of ${msg.total.toLocaleString()} files (${pct}%)...`;
            } else if (msg.type === 'complete') {
                appendTerminalLine(`Worker scan complete: ${msg.issueCount} findings across ${msg.processed} files.`, 'success');
                scanWorker.terminate();
                scanWorker = null;
            } else if (msg.type === 'error') {
                appendTerminalLine(`Worker error: ${msg.error}`, 'error');
                scanWorker.terminate();
                scanWorker = null;
            }
        };
        // Post files to worker (we send only paths since File objects can't be cloned)
        const workerFiles = sourceFiles.slice(0, 5000).map((f, idx) => ({
            id: idx,
            path: f.webkitRelativePath || f.name,
            size: f.size
        }));
        scanWorker.postMessage({ type: 'scan', files: workerFiles, scanId: Date.now() });
    }
    // Robust file reader: File.text() with FileReader fallback for older browsers
    async function readFileText(file) {
        if (typeof file.text === 'function') {
            return await file.text();
        }
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(reader.error || new Error('FileReader error'));
            reader.readAsText(file);
        });
    }
    // Skip known binary extensions — no text analysis needed, avoids UTF-8 decode errors
    const BINARY_EXTS = /\.(png|jpe?g|gif|webp|ico|bmp|tiff?|psd|ai|eps|sketch|mp3|mp4|avi|mov|wav|flac|ogg|webm|mkv|zip|tar|gz|bz2|xz|lz|7z|rar|exe|dll|so|dylib|bin|o|obj|class|woff2?|ttf|otf|eot|pdf|doc|docx|xls|xlsx|ppt|pptx|odt|ods|odp|db|sqlite3?|wasm|dat|pkl|npy|h5|pb|pt|onnx|tflite|parquet|pcap|cap|jar|war|ear|apk|aab|ipa|dmg|pkg|msi|iso|img|vmdk|ova|tgz|rpm|deb)$/i;
    let binarySkipped = 0;
    let readErrors = 0;
    for (let i = 0; i < sourceFiles.length; i++) {
        const file = sourceFiles[i];
        const path = (file.webkitRelativePath || file.name).replace(/\\/g, '/');
        let text = '';
        let lineCount = 0;
        try {
            text = await readFileText(file);
            lineCount = text.split('\n').length;
            totalLines += lineCount;
        } catch (e) {
            readErrors++;
            scanned++;
            continue;
        }
        const lower = text.toLowerCase();
        const lowerPath = path.toLowerCase();
        const isNodeModule = /node_modules\//.test(lowerPath);
        const isNodeModuleDoc = isNodeModule && /\/(readme|changelog|history|license|copying)([-_][a-z]+)?(\.md|\.txt|\.markdown)?$|\/examples?\//i.test(lowerPath);
        const isSimplebeaconCache = /\.simplebeacon\//i.test(lowerPath) || /\.github-sync\//i.test(lowerPath) || /github-cache\//i.test(lowerPath);
        const isScannerArtifact = /\/upload\.html$|\/report\.json$|\/report-deliveries\/|\/explainability\.md$|\/certificate\.html$|\/certificate\.png$|\/executive-summary\.md$|\/remediation-checklist\.md$|\/dev-report\.html$|\/manifest\.json$|\/findings\.md$|\/scanner-engine\.js$|\/main\.js$|\/ui-renderer\.js$|\/token-manager\.js$|\/scan-worker\.js$|\/certificate-module\.js$|\/generate-token\.js$|\/server\.cjs$|\/run-all-tier-scans\.cjs$|\/free-token\.cjs$|\/lib\/db\.cjs$|\/trello-roadmap-export\.js$|\/site-config\.js$|\/contact\.js$|\/roadmap\.html$|\/routes\/(certificates|checkout|subscriptions)\.cjs$|\/services\/email\.cjs$|\/modules\/(gate|consolidation|mock-data|roadmap|codebase|file-reduction|data-quality|cleanup|npm-audit|compliance|ai-indicators|governance|dependency-vulns|build-readiness|eu-ai-act|ai-residue|index)\.json$/i.test(path);
        // Determine language and active analyzers for this file
        const fileLang = detectDominantLanguage([path]);
        const activeAnalyzers = getAnalyzersForLanguage(fileLang, profile);
        const isTestFile = /test-.*\.js$|\.test\.|\.spec\./i.test(path);
        const isTestOutput = /test-(output|debug|failures|log|complete|auto)\.(txt|log)$/i.test(path) || /\.(txt|log)$/i.test(path) && /test|debug|output|log/i.test(path.split('/').pop());
        const isSampleOrTest = /[/-]test[-_]|\.(test|spec)\.|sample[-_]|demo-|fixture-|mock-|audit-|vulnerable|exposed|leaky_|positive-test|\.simplebeacon\/|test-cert\/|__tests__\/|mocks\/|fixtures\/|report\.json|\.simplebeaconignore/i.test(lowerPath);
        const isTypeScriptDef = lowerPath.endsWith('.d.ts');
        const isCiWorkflow = /\.github\/workflows\//.test(lowerPath);
        const isSourceCode = /\.(js|cjs|mjs|ts|tsx|jsx|py|java|go|rs|c|cpp|h|hpp|cs|php|rb|swift|kt|scala|dart|vue|svelte)$/i.test(path);
        const isServerEntry = /\/server\.cjs$|\/(server|api|scripts|reporters|bin|lib)\/|mcp-[^/]+\.cjs$|-helper\.cjs$|-gateway\.cjs$|AssessmentController\.cjs$|path-health\.cjs$|fetch-grammars\.js$/.test(path);
        const isBuildArtifact = /\/(frontend-build|dist|build|\.next|out|coverage)\//i.test(lowerPath);

        // Run all applicable analyzers via dispatch
        for (const analyzerId of activeAnalyzers) {
            const reg = PATTERN_REGISTRY[analyzerId];
            if (!reg) continue;
            // Schema-driven exclusion: one rule per profile instead of 20+ if/else blocks
            const schema = ANALYZER_SCHEMA[analyzerId];
            if (schema) {
                const rule = EXCLUSION_RULES[schema.exclusionProfile];
                if (rule && rule({
                    isNodeModule, isTestOutput, isTestFile, isSimplebeaconCache, isScannerArtifact,
                    isSourceCode, isCiWorkflow, isServerEntry, isSampleOrTest, isTypeScriptDef, isBuildArtifact
                })) continue;
            }
            // Exclude config-drift matches in analyzer/parser files and outreach data from sensitive-data
            if (reg.id === 'configDrift' && /\/analyzers\/|env-parser\.js$|env-profile-utils\.js$|commands\.js$|compliance-checklist\.js$|fix-dry-run\.js$|certificate-module\.js$|ui-renderer\.js$|app-links\.js$|site-config\.js$|playwright\.config\.js$|db\.cjs$|generate-token\.js$|free-token\.cjs$|main\.js$|trello-roadmap-export\.js$|server\.cjs$/.test(path)) continue;
            if (reg.id === 'sensitiveData' && /outreach-prospects\.js$|agency-handoff-patterns\.js$|site-config\.js$|app-links\.js$|email\.cjs$|free-token\.cjs$|generate-token\.js$|main\.js$/.test(path)) continue;
            if (reg.id === 'securityHeaders' && /certificate-module\.js$|main\.js$|ui-renderer\.js$|run-all-tier-scans\.cjs$|server\.cjs$/.test(path)) continue;
            if (reg.id === 'unusedDeps' && /outreach-prospects\.js$|dependency-health-analyzer\.js$|supply-chain-security-scanner\.js$|unused-file-detector\.js$|config-management-analyzer\.js$|certificate-utils\.cjs$|certificate-generator\.cjs$|trello-roadmap-export\.js$|certificates\.cjs$|server\.cjs$|scan-utils\.js$/.test(path)) continue;
            if (reg.id === 'debugArtifacts' && /generate-token\.js$|db\.cjs$|trello-roadmap-export\.js$/.test(path)) continue;
            if (reg.id === 'dbPattern' && /java-ai-vulnerable/.test(path)) continue;
            if (reg.id === 'i18nHardcoded' && /certificate-utils\.cjs$|certificates\.cjs$|checkout\.cjs$|server\.cjs$|services\/email\.cjs$|contact\.js$/.test(path)) continue;
            if (reg.id === 'apiContractDrift' && /routes\/(certificates|checkout|subscriptions)\.cjs$|server\.cjs$/.test(path)) continue;
            if (reg.id === 'missingTest' && /trello-roadmap-export\.js$/.test(path)) continue;
            if (reg.id === 'complexityMetric' && /contact\.js$|roadmap\.html$/.test(path)) continue;
            const matches = extractMatches(text, reg.pattern, reg.maxMatches || 5, reg.redact || false);
            if (matches.length === 0) continue;
            // Apply self-reference filter if defined
            const filteredMatches = reg.selfReferenceFilter
                ? matches.filter(m => !reg.selfReferenceFilter.test(m.snippet || ''))
                : matches;
            if (filteredMatches.length === 0) continue;
            // configDrift: lines using process.env are correct, not drift
            if (reg.id === 'configDrift') {
                const envSafe = filteredMatches.filter(m => !/process\.env/.test(m.snippet || ''));
                if (envSafe.length === 0) continue;
                // Continue with envSafe instead of filteredMatches for this rule
                const finalMatches = envSafe;
                const cat = schema ? schema.category : null;
                const collector = cat ? CATEGORY_COLLECTORS[cat] : null;
                if (collector) {
                    collector(path, reg, finalMatches, {
                        aiHits, aiFindings,
                        credentialHits, credFiles, credentialFindings,
                        debugHits, debugFindings,
                        govHits, govFindings,
                        aiResidueHits, aiResidueFindings,
                        perfHits, perfFindings,
                        typeSafetyHits, typeSafetyFindings,
                        testHits, testFindings,
                        a11yHits, a11yFindings,
                        i18nHits, i18nFindings,
                        sensitiveDataHits, sensitiveDataFindings,
                        configDriftHits, configDriftFindings,
                        securityHeaderHits, securityHeaderFindings,
                        dbPatternHits, dbPatternFindings,
                        frameworkHits, frameworkFindings,
                        workspaceHits, workspaceFindings,
                        unusedDepHits, unusedDepFindings,
                        apiContractHits, apiContractFindings,
                        complexityHits, complexityFindings
                    });
                }
                continue;
            }
            // securityHeaders: lines with setHeader or helmet indicate headers are present
            if (reg.id === 'securityHeaders') {
                const missingOnly = filteredMatches.filter(m => !/setHeader|helmet/.test(m.snippet || ''));
                if (missingOnly.length === 0) continue;
                const finalMatches = missingOnly;
                const cat = schema ? schema.category : null;
                const collector = cat ? CATEGORY_COLLECTORS[cat] : null;
                if (collector) {
                    collector(path, reg, finalMatches, {
                        aiHits, aiFindings,
                        credentialHits, credFiles, credentialFindings,
                        debugHits, debugFindings,
                        govHits, govFindings,
                        aiResidueHits, aiResidueFindings,
                        perfHits, perfFindings,
                        typeSafetyHits, typeSafetyFindings,
                        testHits, testFindings,
                        a11yHits, a11yFindings,
                        i18nHits, i18nFindings,
                        sensitiveDataHits, sensitiveDataFindings,
                        configDriftHits, configDriftFindings,
                        securityHeaderHits, securityHeaderFindings,
                        dbPatternHits, dbPatternFindings,
                        frameworkHits, frameworkFindings,
                        workspaceHits, workspaceFindings,
                        unusedDepHits, unusedDepFindings,
                        apiContractHits, apiContractFindings,
                        complexityHits, complexityFindings
                    });
                }
                continue;
            }
            // Schema-driven routing: one collector per category instead of 20+ if/else branches
            const cat = schema ? schema.category : null;
            const collector = cat ? CATEGORY_COLLECTORS[cat] : null;
            if (collector) {
                collector(path, reg, filteredMatches, {
                    aiHits, aiFindings,
                    credentialHits, credFiles, credentialFindings,
                    debugHits, debugFindings,
                    govHits, govFindings,
                    aiResidueHits, aiResidueFindings,
                    perfHits, perfFindings,
                    typeSafetyHits, typeSafetyFindings,
                    testHits, testFindings,
                    a11yHits, a11yFindings,
                    i18nHits, i18nFindings,
                    sensitiveDataHits, sensitiveDataFindings,
                    configDriftHits, configDriftFindings,
                    securityHeaderHits, securityHeaderFindings,
                    dbPatternHits, dbPatternFindings,
                    frameworkHits, frameworkFindings,
                    workspaceHits, workspaceFindings,
                    unusedDepHits, unusedDepFindings,
                    apiContractHits, apiContractFindings,
                    complexityHits, complexityFindings
                });
            }
        }
        // --- 15 Analysis Category Heuristics (profile-gated) ---
        // 3. Mock data: fixture/sample/test-data files
        if (allowedSections.includes('mockDataCategories')) {
            const isDemoSample = /sample-(certificate|clearance-pdf|report)\./.test(lowerPath);
            const isGitInternal = /\.git\//.test(lowerPath);
            const isTestOutputFile = /test-output/i.test(lowerPath);
            if (!isNodeModule && !isGitInternal && !isDemoSample && !isTestOutputFile && !isSimplebeaconCache && /mock|fixture|sample|test-data|testdata|fake-data|dummy|stub/i.test(lowerPath)) {
                mockFiles.push(path);
            }
        }
            // 9. npm audit: package.json files
            if (allowedSections.includes('npmAudit')) {
                const isCacheDir = /\.github-sync\/|github-cache\//i.test(lowerPath);
                if (!isNodeModule && !isCacheDir && lowerPath.endsWith('package.json')) {
                    packageJsonFiles.push(path);
                    try {
                        const pkg = JSON.parse(text);
                        const depCount = Object.keys(pkg.dependencies || {}).length + Object.keys(pkg.devDependencies || {}).length;
                        totalDependencyCount += depCount;
                        if (depCount > 50) monorepoMarkers++;
                    } catch (e) { /* ignore invalid package.json */ }
                }
            }
            // 5. Codebase: track file types (skip backup timestamps && path-like extensions)
            const extMatch = path.match(/\.([^.]+)$/);
            if (extMatch) {
                const ext = extMatch[1].toLowerCase();
                if (!/^\d/.test(ext) && !ext.includes('/') && ext.length <= 20) {
                    fileTypes[ext] = (fileTypes[ext] || 0) + 1;
                }
            }
            // 10. Compliance: governance files
            const isBuildOutput = /\/(build|dist|frontend-build|out|\.next|\.output|target|coverage)\//i.test(lowerPath);
            if (allowedSections.includes('compliance') || allowedSections.includes('euAiActSummary')) {
                if (!isNodeModule && !isBuildOutput && /license|licence/i.test(lowerPath) && !licenseFiles.includes(path)) {
                    licenseFiles.push(path);
                }
                if (!isNodeModule && !isBuildOutput && /security\.md|code_of_conduct|contributing|changelog|risk-assessment/i.test(lowerPath)) {
                    securityFiles.push(path);
                }
            }
            // 7. Data quality: empty || trivial JSON
            if (allowedSections.includes('dataQuality')) {
                const isTestFixture = /\/test[-/]|\/test\.json$|\.simplebeacon\/|test-cert\/|__tests__\/|fixtures\/|mocks\//.test(lowerPath);
                if (!isTestFixture && lowerPath.endsWith('.json') && !/subscriptions\.json$/.test(lowerPath)) {
                    totalJsonFiles++;
                    if (text.trim().length < 10 || text.trim() === '{}' || text.trim() === '[]') {
                        emptyJsonFiles.push(path);
                    }
                }
            }
            // 2. Consolidation + 6. File reduction: simple content hash for duplicates
            if ((allowedSections.includes('consolidation') || allowedSections.includes('fileReduction')) && text.length < 200000 && !/node_modules|\.git|dist|build|coverage/i.test(lowerPath)) {
                const hash = await simpleHash(text);
                if (duplicateHashes.has(hash)) {
                    duplicateHashes.get(hash).push(path);
                    if (duplicateHashes.get(hash).length === 2) duplicateGroups++;
                } else {
                    duplicateHashes.set(hash, [path]);
                }
            }
            // 4. Roadmap: task/fix markers in actual code comments only
            if (allowedSections.includes('roadmap')) {
                const isCacheOrBinary = /\.git\/|\.simplebeacon\/|github-cache\/|\.github-sync\/|node_modules\/|\.pack$|\.idx$|\.objects\//i.test(lowerPath);
                const isScanReport = /report\.json$|eu-ai-act-report\.json$|delivery_\d+_\w+\.json$/i.test(path);
                const isTestFile = /test[-_]|\.test\.|\.spec\./i.test(path);
                const hasSourceExt = /\.(js|cjs|mjs|ts|tsx|jsx|py|java|go|rs|c|cpp|h|hpp|cs|php|rb|swift|kt|scala|dart|vue|svelte|html|css|scss|sass|less|sql|sh|bash|ps1|yml|yaml|json|md|txt|xml|cfg|ini|toml|gradle|dockerfile)$/i.test(path);
                const todoCommentPattern = /(?:\/\/\s*|\/\*\s*|#\s*)\b(TODO|FIXME|HACK|XXX|BUG)\b/i;
                const fileMarkers = { TODO: 0, FIXME: 0, HACK: 0, BUG: 0, XXX: 0 };
                text.split('\n').forEach(line => {
                    const m = line.match(todoCommentPattern);
                    if (m) {
                        // Skip matches inside string literals (e.g., const x = "// TODO: fix")
                        const idx = line.indexOf(m[0]);
                        if (idx >= 0) {
                            const before = line.slice(0, idx);
                            const quoteCount = (before.match(/['"]/g) || []).length;
                            if (quoteCount % 2 !== 0) return; // inside a string literal
                        }
                        const type = m[1].toUpperCase();
                        if (fileMarkers.hasOwnProperty(type)) fileMarkers[type]++;
                    }
                });
                const hasRealTodo = Object.values(fileMarkers).some(c => c > 0);
                if (!isNodeModule && !isCacheOrBinary && !isScanReport && !isTestFile && hasSourceExt && hasRealTodo) {
                    todoFiles.push({ path, markers: fileMarkers });
                    Object.keys(fileMarkers).forEach(k => { todoMarkerCounts[k] += fileMarkers[k]; });
                }
            }
            // 6. File reduction: collect image paths for post-scan cross-reference
            if (allowedSections.includes('fileReduction')) {
                const baseName = path.split('/').pop();
                const isBuildOutput = /\/(build|dist|frontend-build|out|\.next|\.output|target|coverage)\//i.test(lowerPath);
                const isStandardWebAsset = /^(favicon|apple-touch-icon|mstile|browserconfig|site\.webmanifest|logo192\.png|logo512\.png|maskable-icon|splash-screen|og-image)/i.test(baseName);
                if (!isNodeModule && !isBuildOutput && !isStandardWebAsset && /\.(png|jpg|jpeg|gif|svg|webp|ico)$/i.test(lowerPath)) {
                    imageFiles.push({ path, name: baseName });
                }
            }
            // 16. Junk & Temporary Files: detect OS/editor/build artifacts
            if (allowedSections.includes('junkFiles')) {
                const baseName = path.split('/').pop();
                const isJunk = (
                    /\.(tmp|temp|bak|backup|swp|swo|swn|old|orig|rej|pid|seed|crdownload)$/i.test(baseName) ||
                    baseName.endsWith('~') ||
                    /^(\.DS_Store|Thumbs\.db|desktop\.ini|npm-debug\.log|yarn-error\.log|\.eslintcache|\.node_repl_history)$/i.test(baseName) ||
                    /\.(sass-cache|cache)\//i.test(path)
                );
                if (isJunk && !/node_modules\/|\.git\/|\.simplebeacon\/|github-cache\//i.test(lowerPath)) {
                    junkFiles.push(path);
                }
            }
            // Log every 50th file (|| last) to reduce DOM thrashing
            if ((i + 1) % 50 === 0 || i === sourceFiles.length - 1) {
                appendTerminalLine(`Scanning chunk: <span style="color:#94A3B8;">${path}</span> (${lineCount} lines)`);
            }
            scanned++;
        const pct = Math.round(((i + 1) / sourceFiles.length) * 100);
        // Batch DOM updates: progress bar every 25 files, text every 25
        if ((i + 1) % 25 === 0 || i === sourceFiles.length - 1) {
            panelProgressBar.style.width = pct + '%';
        }
        if (localScanFileName && ((i + 1) % 25 === 0 || i === sourceFiles.length - 1)) {
            localScanFileName.textContent = `Scanning ${scanned.toLocaleString()} of ${sourceFiles.length.toLocaleString()} files (${pct}%) — ${path.split('/').pop()}`;
        }
        // Batch metrics update every 25 files
        if ((i + 1) % 25 === 0 || i === sourceFiles.length - 1) {
            const findingParts = [`Files: ${scanned}/${sourceFiles.length}`];
            if (profile.checkCredentials && credentialHits > 0) findingParts.push(`Creds: ${credentialHits}`);
            if (profile.checkAi && aiHits.length > 0) findingParts.push(`AI: ${aiHits.length}`);
            if (profile.checkDebug && debugHits.length > 0) findingParts.push(`Debug: ${debugHits.length}`);
            if (profile.checkAiResidue && aiResidueHits > 0) findingParts.push(`AI Residue: ${aiResidueHits}`);
            panelMetrics.textContent = findingParts.join(' · ');
        }
        // Yield to browser every 25 files, && check for abort
        if ((i + 1) % 25 === 0) {
            await new Promise(r => setTimeout(r, 0));
            if (signal.aborted) {
                appendTerminalLine('Scan aborted by user.', 'warn');
                panelStatus.textContent = 'ABORTED';
                panelStatus.style.color = '#F59E0B';
                throw new Error('Scan aborted');
            }
        }
    }

    // 3.4 Self-bloat detection: old scan backups, verification dumps, browser reports
    const bloatPatterns = [
        /report\(\d+\)\.json$/i,                          // browser scan dumps like report(31).json
        /\.simplebeacon-backup\.\d{4}-\d{2}-\d{2}T/i,    // timestamped backups
        /verify-scan\d*\.json$/i,                          // verification scan outputs
        /report-fresh\.json$/i,                           // fresh report dumps
        /report\.json\.simplebeacon-backup\./i             // full backup copies
    ];
    for (const file of sourceFiles) {
        const path = (file.webkitRelativePath || file.name).replace(/\\/g, '/');
        for (const pat of bloatPatterns) {
            if (pat.test(path)) {
                bloatFindings.push({ file: path, reason: 'Self-generated scan artifact — safe to delete after review' });
                break;
            }
        }
    }
    if (bloatFindings.length > 0) {
        appendTerminalLine(`Detected ${bloatFindings.length} self-generated bloat file(s) — consider cleanup`, 'warn');
    }

    // 3.5 Cross-reference images against source files to find truly unused assets
    if (imageFiles.length > 0) {
        appendTerminalLine(`Cross-referencing ${imageFiles.length} image assets against source files...`);
        const sourceTextFiles = sourceFiles.filter(f => {
            const p = (f.webkitRelativePath || f.name).toLowerCase();
            return /\.(js|cjs|mjs|ts|tsx|jsx|vue|svelte|html|htm|css|scss|sass|less|json|md|txt|xml)$/i.test(p) && !/node_modules\/|\.git\/|\.simplebeacon\/|github-cache\//i.test(p);
        });
        // Collect all referenced image names in a single pass
        const referencedNames = new Set();
        for (const sf of sourceTextFiles) {
            try {
                const txt = await sf.text();
                for (const img of imageFiles) {
                    if (txt.includes(img.name)) referencedNames.add(img.name);
                }
            } catch (e) { /* ignore unreadable */ }
        }
        unusedAssetCandidates = imageFiles.filter(img => !referencedNames.has(img.name)).map(img => img.path);
        if (unusedAssetCandidates.length > 0) {
            appendTerminalLine(`${unusedAssetCandidates.length} of ${imageFiles.length} images appear unused in source code.`, 'warn');
        } else {
            appendTerminalLine(`All ${imageFiles.length} image assets are referenced in source code.`, 'success');
        }
    }

    // 4. Score & report
    const aiPenalty = profile.checkAi ? Math.min(aiHits.length * 1, 10) : 0;
    const credPenalty = profile.checkCredentials ? Math.min(credentialHits * 5, 15) : 0;
    const debugPenalty = profile.checkDebug ? Math.min(debugHits.length * 0.3, 4) : 0;
    const aiResiduePenalty = profile.checkAiResidue ? Math.min(aiResidueHits * 0.5, 5) : 0;
    const perfPenalty = profile.checkAiResidue ? Math.min(perfHits * 0.3, 3) : 0;
    const typeSafetyPenalty = profile.checkAiResidue ? Math.min(typeSafetyHits * 0.3, 3) : 0;
    const testPenalty = profile.checkAiResidue ? Math.min(testHits * 0.3, 3) : 0;
    const a11yPenalty = profile.checkAiResidue ? Math.min(a11yHits * 0.5, 3) : 0;
    const i18nPenalty = profile.checkAiResidue ? Math.min(i18nHits * 0.2, 2) : 0;
    const sensitiveDataPenalty = profile.checkAiResidue ? Math.min(sensitiveDataHits * 1, 5) : 0;
    const configDriftPenalty = profile.checkAiResidue ? Math.min(configDriftHits * 0.5, 3) : 0;
    const dbPenalty = profile.checkAiResidue ? Math.min(dbPatternHits * 0.5, 3) : 0;
    const frameworkPenalty = profile.checkAiResidue ? Math.min(frameworkHits * 0.3, 2) : 0;
    const workspacePenalty = profile.checkAiResidue ? Math.min(workspaceHits * 0.2, 2) : 0;
    const unusedDepPenalty = profile.checkAiResidue ? Math.min(unusedDepHits * 0.2, 2) : 0;
    const apiContractPenalty = profile.checkAiResidue ? Math.min(apiContractHits * 0.2, 2) : 0;
    const complexityPenalty = profile.checkAiResidue ? Math.min(complexityHits * 0.3, 3) : 0;
    const qualityScore = Math.max(0, 100 - aiPenalty - credPenalty - debugPenalty - aiResiduePenalty - perfPenalty - typeSafetyPenalty - testPenalty - a11yPenalty - i18nPenalty - sensitiveDataPenalty - configDriftPenalty - dbPenalty - frameworkPenalty - workspacePenalty - unusedDepPenalty - apiContractPenalty - complexityPenalty);
    const schemaCompliance = totalJsonFiles === 0 ? 100 : Math.max(0, Math.round(100 - (emptyJsonFiles.length / totalJsonFiles) * 100));
    const consistencyScore = duplicateGroups === 0 ? 100 : Math.max(0, Math.round(100 - Math.min(duplicateGroups * 5, 50)));
    const gatePass = credentialHits === 0;

    // EU AI Act: filter out node_modules documentation (! project governance)
    const nonModuleLicenseFiles = licenseFiles.filter(p => !/node_modules\//.test(p));
    const nonModuleSecurityFiles = securityFiles.filter(p => !/node_modules\//.test(p));

    const now = new Date().toISOString();
    // Find the actual project root folder from webkitRelativePath (first directory segment)
    let projectName = 'browser-local';
    for (const f of files) {
        const rp = f.webkitRelativePath || '';
        if (rp && rp.includes('/')) {
            const firstDir = rp.split('/')[0];
            if (firstDir && !firstDir.startsWith('.')) {
                projectName = firstDir;
                break;
            }
        }
    }
    if (projectName === 'browser-local' && files[0]?.name) {
        projectName = files[0].name;
    }
    const testFixturePattern = /test-all-patterns|\.test\.|\.spec\.|mock|fixture|sample|demo|test.*\.js$|test-technical|e2e\/|positive-test|negative-test|simplebeacon-rule-tests/i;
    const gateFindings = (profile.checkCredentials && credentialFindings.length ? credentialFindings.filter(f => !testFixturePattern.test(f.file)).slice(0,5).map(f => ({ severity: 'medium', type: 'Credential Pattern', count: f.matches.length, filePath: f.file, rule: 'CREDENTIAL_PATTERN_HEURISTIC', impact: 'MEDIUM RISK: Hardcoded credential patterns in source increase breach surface.', fix: 'Move secrets to environment variables || a secret manager; never commit keys to version control.', findings: f.matches })) : []);
    const gateBlockingCount = gateFindings.length;
    const gatePassFinal = gateBlockingCount === 0;
    reportData = {
        type: profile.reportType || 'simplebeacon-report',
        reportVersion: 2,
        version: '1.3.0',
        generatedAt: now,
        generatedBy: 'SimpleBeacon Browser Sandbox',
        scanProfileLabel: profile.label || 'Browser Scan',
        checkEuAi: profile.checkEuAi || false,
        projectRoot: projectName,
        projectPath: projectName,
        scanTargetRoot: projectName,
        platformRoot: 'browser-sandbox',
        gate: { pass: gatePassFinal, blockingCount: gateBlockingCount, failOn: ['high', 'critical'] },
        qualityScore: qualityScore,
        schemaCompliance: schemaCompliance,
        consistencyScore: consistencyScore,
        duplicateGroups: duplicateGroups,
        invalidJson: 0,
        emptyFiles: emptyJsonFiles.length,
        schemaChecked: totalJsonFiles,
        schemaPassed: totalJsonFiles - emptyJsonFiles.length,
        totalFiles: sourceFiles.length,
        filesAnalyzed: sourceFiles.length,
        repositoryFilesTotal: sourceFiles.length,
        repositoryFoldersTotal: [...new Set(sourceFiles.map(f => (f.webkitRelativePath || f.name).replace(/\\/g, '/').split('/').slice(0, -1).join('/')))].filter(Boolean).length,
        excludedCount: skipped,
        excludedSummary: Object.entries(skipReasons).sort((a,b) => b[1] - a[1]).slice(0,5).map(([r,c]) => `${c} ${r}`).join(', ') || 'none',
        issueCount: (profile.checkAi ? aiHits.length : 0) + (profile.checkCredentials ? credentialHits : 0) + (profile.checkDebug ? debugHits.length : 0) + (profile.checkGov ? govHits.length : 0) + (profile.checkAiResidue ? aiResidueHits + perfHits + typeSafetyHits + testHits + a11yHits + i18nHits + sensitiveDataHits + configDriftHits + dbPatternHits + frameworkHits + workspaceHits + unusedDepHits + apiContractHits + complexityHits : 0),
        simplebeaconIssues: (profile.checkAi ? aiHits.length : 0) + (profile.checkCredentials ? credentialHits : 0) + (profile.checkDebug ? debugHits.length : 0) + (profile.checkGov ? govHits.length : 0) + (profile.checkAiResidue ? aiResidueHits + perfHits + typeSafetyHits + testHits + a11yHits + i18nHits + sensitiveDataHits + configDriftHits + dbPatternHits + frameworkHits + workspaceHits + unusedDepHits + apiContractHits + complexityHits : 0),
        detectedIssues: [
            ...(profile.checkAi && aiFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'AI System Indicator', count: aiFindings.reduce((a, f) => a + f.matches.length, 0), filePath: aiFindings.slice(0,10).map(f => f.file), rule: 'AI_IMPLEMENTATION_PATTERN', impact: 'REVIEW REQUIRED: Left unchanged, this pattern may reappear in the next release cycle without a local gate on pull requests.', fix: 'Review && remediate before enabling --gate on main.', findings: aiFindings.slice(0,5), reasoning: 'The scanner detected imports || function calls matching known AI SDK signatures (OpenAI, Anthropic, LangChain, HuggingFace). These patterns indicate AI system integration that may require compliance review under EU AI Act Article 6.', confidence: 0.92, humanReadable: `AI SDK usage detected in ${aiFindings.length} file(s). This suggests the project implements || integrates with third-party AI services.` }] : []),
            ...(profile.checkCredentials && credentialFindings.length ? [{ severity: 'medium', severityBand: 'medium', type: 'Credential Pattern', count: credentialFindings.reduce((a, f) => a + f.matches.length, 0), filePath: credentialFindings.slice(0,10).map(f => f.file), rule: 'CREDENTIAL_PATTERN_HEURISTIC', impact: 'MEDIUM RISK: Hardcoded credential patterns in source increase breach surface && may trigger automated scanner alerts in CI.', fix: 'Move secrets to environment variables || a secret manager; never commit keys to version control.', findings: credentialFindings.slice(0,5), reasoning: 'Regex heuristics matched hardcoded credential patterns: password=, api_key=, secret_key=, || AWS access keys. These strings resemble common secret formats && are flagged for review even if they are dummy values.', confidence: 0.78, humanReadable: `Potential hardcoded secrets found in ${credentialFindings.length} file(s). The scanner matched patterns resembling API keys, passwords, || tokens assigned as string literals.` }] : []),
            ...(profile.checkDebug && debugFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Debug Artifact', count: debugFindings.reduce((a, f) => a + f.matches.length, 0), filePath: debugFindings.slice(0,10).map(f => f.file), rule: 'DEBUG_ARTIFACT', impact: 'HYGIENE RISK: Debug artifacts should ! reach production builds.', fix: 'Remove console.log, debugger, TODO, && FIXME markers before release.', findings: debugFindings.slice(0,5), reasoning: 'Source code analysis detected console.log(), debugger statements, || alert()/prompt() calls. These are development-only artifacts that can leak internal state || interrupt user experience in production.', confidence: 0.98, humanReadable: `Debug artifacts (console.log, debugger, alert) found in ${debugFindings.length} file(s). These should be removed before production builds.` }] : []),
            ...(profile.checkGov && govFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'License/Governance Marker', count: govFindings.reduce((a, f) => a + f.matches.length, 0), filePath: govFindings.slice(0,10).map(f => f.file), rule: 'GOVERNANCE_PATTERN', impact: 'INFO: License headers && copyright notices detected. Verify compliance with open-source policy.', fix: 'Review license compatibility with your product distribution model.', findings: govFindings.slice(0,5), reasoning: 'SPDX-License-Identifier tags, copyright headers, || license references were found  in source files. This indicates the project contains licensed third-party code that must be tracked for compliance.', confidence: 0.95, humanReadable: `License && copyright markers detected in ${govFindings.length} file(s). Verify open-source license compatibility with your distribution model.` }] : []),
            ...(profile.checkAiResidue && aiResidueFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'AI Residue', count: aiResidueFindings.reduce((a, f) => a + f.matches.length, 0), filePath: aiResidueFindings.slice(0,10).map(f => f.file), rule: 'AI_RESIDUE_PATTERN', impact: 'HYGIENE RISK: AI-generated stubs, deprecated idioms, and error-swallowing patterns reduce code quality.', fix: 'Replace stubs with real implementations, modernize deprecated APIs, and add proper error handling.', findings: aiResidueFindings.slice(0,5), reasoning: 'The scanner detected patterns commonly left behind by AI coding assistants: empty function bodies, TODO placeholders, deprecated framework APIs, error-swallowing catch blocks, and large commented-out dead code.', confidence: 0.85, humanReadable: `AI residue (stubs, deprecated patterns, error swallowing, dead code) found in ${aiResidueFindings.length} file(s).` }] : []),
            ...(profile.checkAiResidue && perfFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Performance Anti-Pattern', count: perfFindings.reduce((a, f) => a + f.matches.length, 0), filePath: perfFindings.slice(0,10).map(f => f.file), rule: 'PERFORMANCE_PATTERN', impact: 'PERFORMANCE RISK: Nested loops and leaked listeners degrade runtime performance.', fix: 'Optimize hot paths, debounce event handlers, and remove listeners on unmount.', findings: perfFindings.slice(0,5), reasoning: 'Nested loops create O(n²) complexity. Leaked event listeners accumulate DOM references causing memory bloat.', confidence: 0.80, humanReadable: `${perfFindings.length} file(s) contain performance anti-patterns.` }] : []),
            ...(profile.checkAiResidue && typeSafetyFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Type Safety Gap', count: typeSafetyFindings.reduce((a, f) => a + f.matches.length, 0), filePath: typeSafetyFindings.slice(0,10).map(f => f.file), rule: 'TYPE_SAFETY_PATTERN', impact: 'MAINTAINABILITY RISK: any types and missing PropTypes erode compile-time guarantees.', fix: 'Replace any with specific types, add PropTypes or migrate to TypeScript.', findings: typeSafetyFindings.slice(0,5), reasoning: 'any defeats TypeScript compiler checks. Missing PropTypes causes runtime prop mismatch errors in React.', confidence: 0.82, humanReadable: `${typeSafetyFindings.length} file(s) contain type safety gaps.` }] : []),
            ...(profile.checkAiResidue && testFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Missing Test Coverage', count: testFindings.reduce((a, f) => a + f.matches.length, 0), filePath: testFindings.slice(0,10).map(f => f.file), rule: 'TEST_COVERAGE_PATTERN', impact: 'QUALITY RISK: Skipped or empty tests give false confidence in coverage metrics.', fix: 'Implement skipped tests or remove empty test placeholders.', findings: testFindings.slice(0,5), reasoning: 'Empty test bodies pass silently while production code remains unverified.', confidence: 0.88, humanReadable: `${testFindings.length} file(s) have test coverage gaps.` }] : []),
            ...(profile.checkAiResidue && a11yFindings.length ? [{ severity: 'medium', severityBand: 'medium', type: 'Accessibility Gap', count: a11yFindings.reduce((a, f) => a + f.matches.length, 0), filePath: a11yFindings.slice(0,10).map(f => f.file), rule: 'A11Y_PATTERN', impact: 'INCLUSION RISK: Missing alt text and unlabeled inputs block assistive technology users.', fix: 'Add alt attributes to images, aria-label to buttons, and associate labels with inputs.', findings: a11yFindings.slice(0,5), reasoning: 'Screen readers rely on alt text and ARIA labels. Color-only indicators fail for colorblind users.', confidence: 0.92, humanReadable: `${a11yFindings.length} file(s) have accessibility gaps.` }] : []),
            ...(profile.checkAiResidue && i18nFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'i18n Issue', count: i18nFindings.reduce((a, f) => a + f.matches.length, 0), filePath: i18nFindings.slice(0,10).map(f => f.file), rule: 'I18N_PATTERN', impact: 'GLOBAL RISK: Hardcoded English strings prevent localization.', fix: 'Wrap UI strings in t()/i18n() functions and use locale-aware formatting.', findings: i18nFindings.slice(0,5), reasoning: 'Concatenated strings with variables are impossible to translate because word order varies by language.', confidence: 0.78, humanReadable: `${i18nFindings.length} file(s) have i18n issues.` }] : []),
            ...(profile.checkAiResidue && sensitiveDataFindings.length ? [{ severity: 'high', severityBand: 'high', type: 'Sensitive Data Exposure', count: sensitiveDataFindings.reduce((a, f) => a + f.matches.length, 0), filePath: sensitiveDataFindings.slice(0,10).map(f => f.file), rule: 'SENSITIVE_DATA_PATTERN', impact: 'PRIVACY RISK: PII in logs or source code violates GDPR and increases breach liability.', fix: 'Sanitize logs, remove PII from source, and use tokenization for identifiers.', findings: sensitiveDataFindings.slice(0,5), reasoning: 'Email addresses, phone numbers, and SSN-like patterns in non-test files indicate potential data leakage.', confidence: 0.85, humanReadable: `${sensitiveDataFindings.length} file(s) may expose sensitive data.` }] : []),
            ...(profile.checkAiResidue && configDriftFindings.length ? [{ severity: 'medium', severityBand: 'medium', type: 'Configuration Drift', count: configDriftFindings.reduce((a, f) => a + f.matches.length, 0), filePath: configDriftFindings.slice(0,10).map(f => f.file), rule: 'CONFIG_DRIFT_PATTERN', impact: 'SECURITY RISK: Hardcoded URLs and secrets in config files bypass environment controls.', fix: 'Move secrets to .env, inject URLs via environment variables, and audit config files.', findings: configDriftFindings.slice(0,5), reasoning: 'Config drift occurs when local settings are committed instead of environment-specific overrides.', confidence: 0.80, humanReadable: `${configDriftFindings.length} file(s) show configuration drift.` }] : []),
            ...(profile.checkAiResidue && securityHeaderFindings.length ? [{ severity: 'medium', severityBand: 'medium', type: 'Missing Security Header', count: securityHeaderFindings.reduce((a, f) => a + f.matches.length, 0), filePath: securityHeaderFindings.slice(0,10).map(f => f.file), rule: 'SECURITY_HEADER_PATTERN', impact: 'SECURITY RISK: Missing CSP or X-Frame-Options enables XSS and clickjacking.', fix: 'Add helmet middleware or configure reverse proxy with CSP, HSTS, X-Frame-Options.', findings: securityHeaderFindings.slice(0,5), reasoning: 'Modern browsers enforce security headers to mitigate XSS, clickjacking, and MIME sniffing attacks.', confidence: 0.83, humanReadable: `${securityHeaderFindings.length} file(s) reference security headers — verify full coverage.` }] : []),
            ...(profile.checkAiResidue && dbPatternFindings.length ? [{ severity: 'high', severityBand: 'high', type: 'Database Anti-Pattern', count: dbPatternFindings.reduce((a, f) => a + f.matches.length, 0), filePath: dbPatternFindings.slice(0,10).map(f => f.file), rule: 'DB_PATTERN', impact: 'SECURITY RISK: Raw SQL concatenation enables injection. Unbounded queries cause DoS.', fix: 'Use parameterized queries, ORM methods, and always apply LIMIT/OFFSET.', findings: dbPatternFindings.slice(0,5), reasoning: 'String concatenation in SQL queries is the leading cause of injection vulnerabilities in web apps.', confidence: 0.90, humanReadable: `${dbPatternFindings.length} file(s) contain database anti-patterns.` }] : []),
            ...(profile.checkAiResidue && frameworkFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Framework Practice Issue', count: frameworkFindings.reduce((a, f) => a + f.matches.length, 0), filePath: frameworkFindings.slice(0,10).map(f => f.file), rule: 'FRAMEWORK_PATTERN', impact: 'MAINTAINABILITY RISK: Hook misuse and missing cleanup cause memory leaks and stale state.', fix: 'Add dependency arrays to useEffect, unsubscribe in ngOnDestroy, avoid direct DOM access.', findings: frameworkFindings.slice(0,5), reasoning: 'React hooks without dependency arrays re-run on every render. Missing Angular unsubscribes leak memory.', confidence: 0.85, humanReadable: `${frameworkFindings.length} file(s) have framework practice issues.` }] : []),
            ...(profile.checkAiResidue && workspaceFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Workspace Health Issue', count: workspaceFindings.reduce((a, f) => a + f.matches.length, 0), filePath: workspaceFindings.slice(0,10).map(f => f.file), rule: 'WORKSPACE_PATTERN', impact: 'MAINTAINABILITY RISK: Circular imports and mismatched versions cause build failures.', fix: 'Refactor shared code into a common package, align dependency versions across workspace.', findings: workspaceFindings.slice(0,5), reasoning: 'Relative imports between workspace packages suggest tight coupling that can become circular.', confidence: 0.70, humanReadable: `${workspaceFindings.length} file(s) show workspace health concerns.` }] : []),
            ...(profile.checkAiResidue && unusedDepFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'Unused Dependency', count: unusedDepFindings.reduce((a, f) => a + f.matches.length, 0), filePath: unusedDepFindings.slice(0,10).map(f => f.file), rule: 'UNUSED_DEP_PATTERN', impact: 'BLOAT RISK: Unused packages increase install time, bundle size, and attack surface.', fix: 'Remove unused packages from package.json and lockfile.', findings: unusedDepFindings.slice(0,5), reasoning: 'Dependencies not imported anywhere add zero value but increase supply chain risk.', confidence: 0.75, humanReadable: `${unusedDepFindings.length} file(s) suggest unused dependencies.` }] : []),
            ...(profile.checkAiResidue && apiContractFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'API Contract Drift', count: apiContractFindings.reduce((a, f) => a + f.matches.length, 0), filePath: apiContractFindings.slice(0,10).map(f => f.file), rule: 'API_CONTRACT_PATTERN', impact: 'INTEGRATION RISK: Unconsumed endpoints and stale OpenAPI specs mislead consumers.', fix: 'Sync OpenAPI spec with implementation, remove dead endpoints, verify frontend coverage.', findings: apiContractFindings.slice(0,5), reasoning: 'Backend routes not called by frontend may be dead code or indicate missing frontend integration.', confidence: 0.72, humanReadable: `${apiContractFindings.length} file(s) show API contract drift.` }] : []),
            ...(profile.checkAiResidue && complexityFindings.length ? [{ severity: 'low', severityBand: 'low', type: 'High Complexity', count: complexityFindings.reduce((a, f) => a + f.matches.length, 0), filePath: complexityFindings.slice(0,10).map(f => f.file), rule: 'COMPLEXITY_PATTERN', impact: 'MAINTAINABILITY RISK: Over-long functions and deep nesting increase bug density.', fix: 'Extract helper functions, reduce nesting with early returns, apply cyclomatic complexity limits.', findings: complexityFindings.slice(0,5), reasoning: 'Functions over 50 lines or with deeply nested control flow are harder to test and reason about.', confidence: 0.80, humanReadable: `${complexityFindings.length} file(s) contain high complexity patterns.` }] : [])
        ],
        issues: [
            ...(profile.checkAi && aiHits.length ? [{ severity: 'low', type: 'AI System Indicator', count: aiHits.length }] : []),
            ...(profile.checkCredentials && credentialHits ? [{ severity: 'medium', type: 'Credential Pattern', count: credentialHits }] : []),
            ...(profile.checkDebug && debugHits.length ? [{ severity: 'low', type: 'Debug Artifact', count: debugHits.length }] : []),
            ...(profile.checkGov && govHits.length ? [{ severity: 'low', type: 'License/Governance Marker', count: govHits.length }] : []),
            ...(profile.checkAiResidue && aiResidueHits ? [{ severity: 'low', type: 'AI Residue', count: aiResidueHits }] : []),
            ...(profile.checkAiResidue && perfHits ? [{ severity: 'low', type: 'Performance Anti-Pattern', count: perfHits }] : []),
            ...(profile.checkAiResidue && typeSafetyHits ? [{ severity: 'low', type: 'Type Safety Gap', count: typeSafetyHits }] : []),
            ...(profile.checkAiResidue && testHits ? [{ severity: 'low', type: 'Missing Test Coverage', count: testHits }] : []),
            ...(profile.checkAiResidue && a11yHits ? [{ severity: 'medium', type: 'Accessibility Gap', count: a11yHits }] : []),
            ...(profile.checkAiResidue && i18nHits ? [{ severity: 'low', type: 'i18n Issue', count: i18nHits }] : []),
            ...(profile.checkAiResidue && sensitiveDataHits ? [{ severity: 'high', type: 'Sensitive Data Exposure', count: sensitiveDataHits }] : []),
            ...(profile.checkAiResidue && configDriftHits ? [{ severity: 'medium', type: 'Configuration Drift', count: configDriftHits }] : []),
            ...(profile.checkAiResidue && securityHeaderHits ? [{ severity: 'medium', type: 'Missing Security Header', count: securityHeaderHits }] : []),
            ...(profile.checkAiResidue && dbPatternHits ? [{ severity: 'high', type: 'Database Anti-Pattern', count: dbPatternHits }] : []),
            ...(profile.checkAiResidue && frameworkHits ? [{ severity: 'low', type: 'Framework Practice Issue', count: frameworkHits }] : []),
            ...(profile.checkAiResidue && workspaceHits ? [{ severity: 'low', type: 'Workspace Health Issue', count: workspaceHits }] : []),
            ...(profile.checkAiResidue && unusedDepHits ? [{ severity: 'low', type: 'Unused Dependency', count: unusedDepHits }] : []),
            ...(profile.checkAiResidue && apiContractHits ? [{ severity: 'low', type: 'API Contract Drift', count: apiContractHits }] : []),
            ...(profile.checkAiResidue && complexityHits ? [{ severity: 'low', type: 'High Complexity', count: complexityHits }] : [])
        ],
        rawIssues: [
            ...(profile.checkAi && aiHits.length ? [{ severity: 'low', type: 'AI System Indicator', count: aiHits.length }] : []),
            ...(profile.checkCredentials && credentialHits ? [{ severity: 'medium', type: 'Credential Pattern', count: credentialHits }] : []),
            ...(profile.checkDebug && debugHits.length ? [{ severity: 'low', type: 'Debug Artifact', count: debugHits.length }] : []),
            ...(profile.checkGov && govHits.length ? [{ severity: 'low', type: 'License/Governance Marker', count: govHits.length }] : []),
            ...(profile.checkAiResidue && aiResidueHits ? [{ severity: 'low', type: 'AI Residue', count: aiResidueHits }] : []),
            ...(profile.checkAiResidue && perfHits ? [{ severity: 'low', type: 'Performance Anti-Pattern', count: perfHits }] : []),
            ...(profile.checkAiResidue && typeSafetyHits ? [{ severity: 'low', type: 'Type Safety Gap', count: typeSafetyHits }] : []),
            ...(profile.checkAiResidue && testHits ? [{ severity: 'low', type: 'Missing Test Coverage', count: testHits }] : []),
            ...(profile.checkAiResidue && a11yHits ? [{ severity: 'medium', type: 'Accessibility Gap', count: a11yHits }] : []),
            ...(profile.checkAiResidue && i18nHits ? [{ severity: 'low', type: 'i18n Issue', count: i18nHits }] : []),
            ...(profile.checkAiResidue && sensitiveDataHits ? [{ severity: 'high', type: 'Sensitive Data Exposure', count: sensitiveDataHits }] : []),
            ...(profile.checkAiResidue && configDriftHits ? [{ severity: 'medium', type: 'Configuration Drift', count: configDriftHits }] : []),
            ...(profile.checkAiResidue && securityHeaderHits ? [{ severity: 'medium', type: 'Missing Security Header', count: securityHeaderHits }] : []),
            ...(profile.checkAiResidue && dbPatternHits ? [{ severity: 'high', type: 'Database Anti-Pattern', count: dbPatternHits }] : []),
            ...(profile.checkAiResidue && frameworkHits ? [{ severity: 'low', type: 'Framework Practice Issue', count: frameworkHits }] : []),
            ...(profile.checkAiResidue && workspaceHits ? [{ severity: 'low', type: 'Workspace Health Issue', count: workspaceHits }] : []),
            ...(profile.checkAiResidue && unusedDepHits ? [{ severity: 'low', type: 'Unused Dependency', count: unusedDepHits }] : []),
            ...(profile.checkAiResidue && apiContractHits ? [{ severity: 'low', type: 'API Contract Drift', count: apiContractHits }] : []),
            ...(profile.checkAiResidue && complexityHits ? [{ severity: 'low', type: 'High Complexity', count: complexityHits }] : [])
        ],
        severityCounts: {
            critical: 0,
            high: (profile.checkAiResidue ? sensitiveDataHits + dbPatternHits : 0),
            medium: (profile.checkCredentials ? credentialHits : 0) + (profile.checkAiResidue ? a11yHits + configDriftHits + securityHeaderHits : 0),
            low: (profile.checkAi ? aiHits.length : 0) + (profile.checkDebug ? debugHits.length : 0) + (profile.checkGov ? govHits.length : 0) + (profile.checkAiResidue ? aiResidueHits + perfHits + typeSafetyHits + testHits + i18nHits + frameworkHits + workspaceHits + unusedDepHits + apiContractHits + complexityHits : 0)
        },
        // AI-agent context: structured metadata to help AI coding agents understand && act on this report
        aiContext: {
            schemaVersion: '2.1',
            readerGuide: {
                purpose: 'This report contains a static analysis of a JavaScript/TypeScript codebase. Each module section (gate, cleanup, performance, etc.) contains findings with file paths, line numbers, snippets, and suggested fixes.',
                howToUse: 'Start with aiContext.suggestedFixes[] for prioritized actionable tasks. Each fix has file, line, currentCode, replacement, suggestedPatch (unified diff), and verificationCommand. For high-level planning, use moduleDependencies and completionCriteria.',
                keyFields: {
                    'aiContext.suggestedFixes[].file': 'Affected file path — use for git checkout or direct edit',
                    'aiContext.suggestedFixes[].line': 'Line number where the fix should be applied',
                    'aiContext.suggestedFixes[].currentCode': 'Exact code snippet to be replaced (before state)',
                    'aiContext.suggestedFixes[].replacement': 'Suggested replacement code (after state)',
                    'aiContext.suggestedFixes[].suggestedPatch': 'Unified diff string — can be applied with git apply',
                    'aiContext.suggestedFixes[].context': 'Array of surrounding code lines for broader context',
                    'aiContext.suggestedFixes[].autoFixable': 'Boolean — if true, AI can apply without human review',
                    'aiContext.suggestedFixes[].verificationCommand': 'Shell command to verify the fix is correct',
                    'detectedIssues[].severity': 'critical || high || medium || low — start with high severity',
                    'detectedIssues[].fix': 'Actionable remediation string — can be turned into a code change directly',
                    'detectedIssues[].filePath': 'Array of affected file paths',
                    'detectedIssues[].confidence': '0.0-1.0 — higher means more certain',
                    'detectedIssues[].findings[].line': 'Line number in the file',
                    'detectedIssues[].findings[].snippet': 'Code context around the finding'
                }
            },
            projectContext: {
                dominantLanguage: detectDominantLanguage(sourceFiles.map(f => f.webkitRelativePath || f.name)),
                totalFiles: sourceFiles.length,
                totalLines: totalLines,
                fileTypes: fileTypes,
                buildTool: packageJsonFiles.length > 0 ? 'npm/node' : 'unknown',
                testFramework: 'jest',
                lintCommand: 'npm run lint',
                buildCommand: 'npm run build',
                scanEnvironment: 'browser-sandbox'
            },
            suggestedFixes: buildSuggestedFixes(
                { aiFindings, credentialFindings, debugFindings, govFindings, aiResidueFindings, perfFindings, typeSafetyFindings, testFindings, a11yFindings, i18nFindings, sensitiveDataFindings, configDriftFindings, securityHeaderFindings, dbPatternFindings, frameworkFindings, workspaceFindings, unusedDepFindings, apiContractFindings, complexityFindings }
            ),
            filesRequiringChanges: dedupeFileChanges(
                { aiFindings, credentialFindings, debugFindings, govFindings, aiResidueFindings, perfFindings, typeSafetyFindings, testFindings, a11yFindings, i18nFindings, sensitiveDataFindings, configDriftFindings, securityHeaderFindings, dbPatternFindings, frameworkFindings, workspaceFindings, unusedDepFindings, apiContractFindings, complexityFindings }
            ),
            moduleDependencies: [
                { id: 'security', dependsOn: null, reason: 'Fix credentials && secrets first — they are the highest-risk items' },
                { id: 'sensitive-data', dependsOn: null, reason: 'Remove PII from source before refactoring' },
                { id: 'database-patterns', dependsOn: null, reason: 'Fix SQL injection vectors before feature work' },
                { id: 'config-drift', dependsOn: null, reason: 'Move hardcoded secrets to env before other changes' },
                { id: 'data-quality', dependsOn: 'security', reason: 'Validate JSON integrity after security fixes' },
                { id: 'cleanup', dependsOn: 'security', reason: 'Remove debug artifacts only after verifying no secrets are in them' },
                { id: 'performance', dependsOn: 'cleanup', reason: 'Optimize after removing dead code && debug artifacts' },
                { id: 'type-safety', dependsOn: 'cleanup', reason: 'Add types after refactoring for clarity' },
                { id: 'test-coverage', dependsOn: 'type-safety', reason: 'Write tests after types are stable' },
                { id: 'documentation', dependsOn: 'test-coverage', reason: 'Document after APIs are tested && finalized' }
            ],
            completionCriteria: [
                { phase: 'security', criteria: ['No hardcoded credentials in source', 'All secrets moved to environment variables', 'secretlint or grep scan returns clean'] },
                { phase: 'cleanup', criteria: ['No console.log, debugger, or alert in production code', 'No self-generated bloat files', 'eslint-plugin-no-console passes in CI'] },
                { phase: 'performance', criteria: ['No nested O(n²) loops in hot paths', 'All event listeners properly removed on unmount', 'Benchmark tests pass within baseline'] },
                { phase: 'type-safety', criteria: ['TypeScript compiler errors = 0', 'No any types in src/', 'All public functions have JSDoc @param tags'] },
                { phase: 'test-coverage', criteria: ['No skipped or empty tests', 'Coverage >= 80% for critical paths', 'All tests pass in CI'] },
                { phase: 'documentation', criteria: ['All exported functions have JSDoc or docstrings', 'README updated for new APIs', 'CHANGELOG entry for breaking changes'] },
                { phase: 'eu-ai-act', criteria: ['AI disclosure notices present in UI', 'No prohibited practices per Article 5', 'Risk assessment document current'] }
            ],
            confidenceThreshold: 0.75,
            autoFixable: ['debugArtifacts','aiResidue','unusedDeps','junkFiles'],
            manualReviewRequired: ['credentials','sensitiveData','databasePatterns','securityHeaders','configDrift']
        },
        // 1. Simplebeacon Gate (always included)
        gate: {
            pass: gatePassFinal,
            blockingCount: gateBlockingCount,
            warningCount: 0,
            blockingFindings: gateFindings
        },
        gateReport: {
            pass: gatePassFinal,
            blockingCount: gateBlockingCount,
            summary: gatePassFinal
                ? 'Gate passed — no blocking credentials found.'
                : `${gateBlockingCount} medium-severity credential pattern(s) detected. Review before release.`
        },
        summary: {
            gatePass: gatePass,
            qualityScore: qualityScore
        },
        // Profile-aware sections — only include what the selected profile needs
        ...(allowedSections.includes('consolidation') ? {
            consolidation: {
                monorepoMarkers: monorepoMarkers,
                duplicateGroups: duplicateGroups,
                duplicateFiles: Array.from(duplicateHashes.values()).filter(g => g.length > 1).slice(0, 100),
                summary: duplicateGroups > 0 ? `${duplicateGroups} duplicate file groups detected.` : 'No duplicate files detected.'
            }
        } : {}),
        ...(allowedSections.includes('mockDataCategories') ? {
            mockDataCategories: [
                ...(mockFiles.length ? [{
                    category: 'Mock / Fixture / Sample Files',
                    fileCount: mockFiles.length,
                    confidence: 'medium',
                    description: 'Files with mock, fixture, sample, || test-data naming patterns.',
                    affectedFiles: mockFiles.slice(0, 5)
                }] : [])
            ],
            mockSampleFiles: mockFiles.length
        } : {}),
        ...(allowedSections.includes('roadmap') ? {
            roadmap: {
                todoCount: todoFiles.length,
                todoFiles: todoFiles.map(f => f.path || f).slice(0, 20),
                markerBreakdown: { TODO: todoMarkerCounts.TODO, FIXME: todoMarkerCounts.FIXME, HACK: todoMarkerCounts.HACK, BUG: todoMarkerCounts.BUG, XXX: todoMarkerCounts.XXX },
                summary: todoFiles.length > 0 ? `${todoFiles.length} files contain task/fix markers.` : 'No roadmap markers found.'
            }
        } : {}),
        ...(allowedSections.includes('codebase') ? {
            codebase: {
                totalFiles: sourceFiles.length,
                totalLines: totalLines,
                fileTypes: fileTypes,
                summary: `${sourceFiles.length} files analyzed, ${totalLines.toLocaleString()} lines of code.`
            }
        } : {}),
        ...(allowedSections.includes('fileReduction') ? {
            fileReduction: {
                unusedAssetCandidates: unusedAssetCandidates.slice(0, 10),
                duplicateGroups: duplicateGroups,
                summary: `${unusedAssetCandidates.length} image assets detected for review. ${duplicateGroups} duplicate content groups found.`
            }
        } : {}),
        ...(allowedSections.includes('dataQuality') ? {
            dataQuality: {
                emptyJsonFiles: emptyJsonFiles.slice(0, 5),
                emptyJsonCount: emptyJsonFiles.length,
                summary: emptyJsonFiles.length > 0 ? `${emptyJsonFiles.length} empty || trivial JSON files detected.` : 'No empty JSON files detected.'
            }
        } : {}),
        ...(allowedSections.includes('cleanup') ? {
            cleanup: {
                debugArtifacts: debugHits.slice(0, 5),
                debugArtifactCount: debugHits.length,
                debugFindings: debugFindings.slice(0, 5).map(f => ({
                    file: f.file,
                    matches: f.matches.slice(0, 3).map(m => ({ line: m.line, snippet: m.snippet }))
                })),
                bloatArtifacts: bloatFindings.slice(0, 5),
                bloatArtifactCount: bloatFindings.length,
                summary: (debugHits.length > 0 ? `${debugHits.length} debug artifacts detected.` : 'No debug artifacts found.') +
                         (bloatFindings.length > 0 ? ` ${bloatFindings.length} self-generated bloat file(s).` : '')
            }
        } : {}),
        ...(allowedSections.includes('junkFiles') ? {
            junkFiles: {
                files: junkFiles.slice(0, 10),
                fileCount: junkFiles.length,
                summary: junkFiles.length > 0 ? `${junkFiles.length} junk || temporary file${junkFiles.length === 1 ? '' : 's'} detected.` : 'No junk or temporary files found.'
            }
        } : {}),
        ...(allowedSections.includes('npmAudit') ? {
            npmAudit: {
                packageJsonFiles: packageJsonFiles.slice(0, 5),
                packageJsonCount: packageJsonFiles.length,
                dependencyCount: totalDependencyCount,
                summary: packageJsonFiles.length > 0 ? `${packageJsonFiles.length} package.json file${packageJsonFiles.length === 1 ? '' : 's'} found with ${totalDependencyCount.toLocaleString()} total dependenc${totalDependencyCount === 1 ? 'y' : 'ies'}.` : 'No package.json files detected.'
            }
        } : {}),
        ...(allowedSections.includes('compliance') ? {
            compliance: {
                licenseFiles: licenseFiles.slice(0, 5),
                securityFiles: securityFiles.slice(0, 5),
                licenseCount: licenseFiles.length,
                securityCount: securityFiles.length,
                govFindings: govFindings.slice(0, 5).map(f => ({
                    file: f.file,
                    matches: f.matches.slice(0, 3).map(m => ({ line: m.line, snippet: m.snippet }))
                })),
                summary: `${licenseFiles.length} license files, ${securityFiles.length} security/governance files detected.`
            }
        } : {}),
        ...(allowedSections.includes('euAiActSummary') ? (() => {
            const euControls = buildEuAiActControls(aiHits, licenseFiles, securityFiles, aiFindings);
            const warnOrWorse = euControls.filter(c => c.status === 'WARN' || c.status === 'FAIL');
            const reviewItems = euControls.filter(c => c.status === 'REVIEW');
            const highRiskIndicators = warnOrWorse.filter(c => c.severity === 'high' || c.severity === 'critical').length;
            const transparencyGaps = warnOrWorse.filter(c => c.controlId === 'EU-AIA-ART-50').length;
            return {
                euAiActSummary: {
                    highRiskIndicators,
                    aiSystemIndicators: aiHits.length,
                    transparencyGaps,
                    documentationArtifacts: (licenseFiles.length + securityFiles.length) || 0,
                    documentationFound: [...licenseFiles, ...securityFiles].slice(0, 10),
                    controls: euControls,
                    deadlineNote: aiHits.length > 0 ? `${aiHits.length} AI system indicator${aiHits.length === 1 ? '' : 's'} detected; ${warnOrWorse.length} control(s) require action, ${reviewItems.length} need review.` : 'Review EU AI Act requirements.'
                },
                euAiActFindings: aiHits.length,
                euAiActScanned: sourceFiles.length
            };
        })() : {}),
        ...(allowedSections.includes('dependencyAudit') ? {
            dependencyAudit: {
                vulnerabilityCount: 0,
                critical: 0,
                high: 0,
                moderate: 0,
                low: 0,
                affectedPackages: [],
                outdatedPackages: [],
                summary: 'Browser scan does ! execute npm audit. Run CLI scan with --audit flag for full CVE report.'
            }
        } : {}),
        ...buildAnalyzerSections({
            aiResidueHits, aiResidueFindings,
            perfHits, perfFindings,
            typeSafetyHits, typeSafetyFindings,
            testHits, testFindings,
            a11yHits, a11yFindings,
            i18nHits, i18nFindings,
            sensitiveDataHits, sensitiveDataFindings,
            configDriftHits, configDriftFindings,
            securityHeaderHits, securityHeaderFindings,
            dbPatternHits, dbPatternFindings,
            frameworkHits, frameworkFindings,
            workspaceHits, workspaceFindings,
            unusedDepHits, unusedDepFindings,
            apiContractHits, apiContractFindings,
            complexityHits, complexityFindings
        }, allowedSections),
        fileList: sourceFiles.map(f => f.webkitRelativePath || f.name).filter(p => !/node_modules\/|\.git\//.test(p.toLowerCase())),
        ...(allowedSections.includes('buildReadiness') ? (() => {
            const lowerPaths = (sourceFiles.map(f => (f.webkitRelativePath || f.name).toLowerCase()));
            const allPaths = sourceFiles.map(f => (f.webkitRelativePath || f.name).replace(/\\/g, '/'));
            const dominantLang = detectDominantLanguage(allPaths);
            const langChecks = getBuildChecksForLanguage(dominantLang);
            // Map LANGUAGE_REGISTRY buildChecks to the format expected by the readiness scorer
            const brChecks = langChecks.map(check => ({
                name: check.name,
                found: check.customCheck
                    ? check.customCheck(allPaths)
                    : lowerPaths.some(p => check.regex.test(p)),
                critical: check.critical
            }));
            // If JS-dominant and no language detected, fall back to legacy npm checks for compatibility
            if (dominantLang === 'javascript' && !lowerPaths.some(p => p.endsWith('package.json'))) {
                brChecks.push(
                    { name: 'package.json', found: false, critical: true },
                    { name: 'Lockfile', found: false, critical: true }
                );
            }
            const brMissingCritical = brChecks.filter(c => c.critical && !c.found);
            const brMissingNice = brChecks.filter(c => !c.critical && !c.found);
            const brScore = Math.round(((brChecks.filter(c => c.found).length / brChecks.length) * 100));
            return { buildReadiness: {
                readinessScore: brScore,
                readinessStatus: brScore >= 80 ? 'READY' : (brScore >= 50 ? 'NEEDS WORK' : 'BLOCKED'),
                totalChecks: brChecks.length,
                passedChecks: brChecks.filter(c => c.found).length,
                missingCritical: brMissingCritical.map(c => c.name),
                missingRecommended: brMissingNice.map(c => c.name),
                checklist: brChecks,
                summary: `${brScore >= 80 ? 'READY' : (brScore >= 50 ? 'NEEDS WORK' : 'BLOCKED')} — ${brChecks.filter(c => c.found).length} of ${brChecks.length} checklist items present.${brMissingCritical.length ? ` ${brMissingCritical.length} critical blocker${brMissingCritical.length === 1 ? '' : 's'}.` : ''}`,
                remediation: brMissingCritical.length > 0 ? `Missing critical: ${brMissingCritical.map(c => c.name).join(', ')}.` : (brMissingNice.length > 0 ? `Missing recommended: ${brMissingNice.map(c => c.name).join(', ')}.` : 'No remediation needed.'),
                recommendations: brMissingCritical.length > 0 ? ['Add all critical files before production deployment.', 'Start with package.json, README, .gitignore, && .env.example.'] : (brMissingNice.length > 0 ? ['Add recommended files to improve maintainability.', 'Consider Docker, linting config, && CHANGELOG.'] : ['Project is fully ready for production. All checklist items present.'])
            }};
        })() : {}),
        credentialScanned: sourceFiles.length,
        credentialFindings: credentialHits,
        scanDurationMs: Date.now() - startTime,
        repositoryInventory: { totalFiles: sourceFiles.length, projectRoot: projectName },
        title: profile.title || 'SimpleBeacon Browser Scan',
        summary: {
            gatePass: gatePass,
            qualityScore: qualityScore,
            repositoryFiles: sourceFiles.length,
            simplebeaconIssues: (profile.checkAi ? aiHits.length : 0) + (profile.checkCredentials ? credentialHits : 0) + (profile.checkDebug ? debugHits.length : 0) + (profile.checkGov ? govHits.length : 0) + (profile.checkAiResidue ? aiResidueHits + perfHits + typeSafetyHits + testHits + a11yHits + i18nHits + sensitiveDataHits + configDriftHits + dbPatternHits + frameworkHits + workspaceHits + unusedDepHits + apiContractHits + complexityHits : 0),
            totalFindings: (profile.checkAi ? aiHits.length : 0) + (profile.checkCredentials ? credentialHits : 0) + (profile.checkDebug ? debugHits.length : 0) + (profile.checkGov ? govHits.length : 0) + (profile.checkAiResidue ? aiResidueHits + perfHits + typeSafetyHits + testHits + a11yHits + i18nHits + sensitiveDataHits + configDriftHits + dbPatternHits + frameworkHits + workspaceHits + unusedDepHits + apiContractHits + complexityHits : 0)
        },
        scanProfile: browserScanProfile?.value || 'gate',
        scanProfileLabel: profile.label
    };

    // Derive severityCounts from detectedIssues so it always matches the actual findings
    reportData.severityCounts = (reportData.detectedIssues || []).reduce((acc, issue) => {
        const sev = issue.severity || 'low';
        acc[sev] = (acc[sev] || 0) + (issue.count || 0);
        return acc;
    }, { critical: 0, high: 0, medium: 0, low: 0 });

    // Strip reportData to only sections the user's tier has activated
    if (typeof filterReportByModules === 'function' && selectedModules) {
        reportData = filterReportByModules(reportData, Array.from(selectedModules));
    }

    appendTerminalLine('Local directory crawl operation complete. Verification tree generated.', 'success');
    appendTerminalLine('Zero-Retention Safeguard Verified. Report compiled locally inside browser sandbox.', 'success');

    // 6-Dimension Data Quality validation before preview render
    const dq = renderQualityScorecard(reportData);
    if (dq.overall === 'FAIL') {
        appendTerminalLine('Certificate generation blocked: Data quality validation failed. Review the scorecard above.', 'error');
        panelStatus.textContent = 'QUALITY_FAIL';
        panelStatus.style.color = '#EF4444';
        if (browserFolderDropzone) browserFolderDropzone.classList.remove('scanning');
        return; // halt certificate pipeline
    }

    panelStatus.textContent = 'SUCCESS_COMPLETED';
    panelStatus.style.color = '#10B981';

    // Compute hash of generated report
    const reportJsonStr = JSON.stringify(reportData);
    computeSha256(reportJsonStr).then(hash => {
        showHashRibbon('browserHashRibbon', 'browserHashValue', hash);
    });

    if (browserFolderDropzone) browserFolderDropzone.classList.remove('scanning');
    renderPreview(reportData);
    scanPreview.style.display = 'block';
    updateSubmit();
    // Auto-scroll to certificate section after scan
    setTimeout(() => {
        document.getElementById('tokenActionRow').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 300);
    const statusParts = [`Complete scan: ${sourceFiles.length} files`, `${selectedModules.size} modules selected for ZIP`];
    if (credentialHits) statusParts.push(`${credentialHits} credentials`);
    if (aiHits.length) statusParts.push(`${aiHits.length} AI indicators`);
    if (debugHits.length) statusParts.push(`${debugHits.length} debug artifacts`);
    showStatus(statusParts.join(' · ') + '. Token required for certificate.', 'success');

    // Build Secure Report preview + download
    const existingReport = document.getElementById('secureReportBlock');
    if (existingReport) existingReport.remove();

    const reportBlock = document.createElement('div');
    reportBlock.id = 'secureReportBlock';
    reportBlock.style.marginTop = '16px';
    reportBlock.style.padding = '16px';
    reportBlock.style.background = 'rgba(16,185,129,0.06)';
    reportBlock.style.border = '1px solid rgba(16,185,129,0.2)';
    reportBlock.style.borderRadius = '10px';

    const reportJson = JSON.stringify(reportData, null, 2);
    reportBlock.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
            <span style="font-size:1.2rem;">&#128275;</span>
            <div>
                <div style="font-size:0.85rem;font-weight:700;color:#34D399;">Secure Report Ready</div>
                <div style="font-size:0.75rem;color:var(--text-muted);">Review what's included before downloading. No source code in this file.</div>
            </div>
        </div>
        <details style="margin-bottom:12px;">
            <summary style="font-size:0.8rem;color:#60A5FA;cursor:pointer;font-weight:600;">Preview report.json contents</summary>
            <pre style="margin-top:8px;padding:12px;background:#0B0F19;border:1px solid var(--border);border-radius:8px;font-size:0.75rem;color:#94A3B8;overflow-x:auto;max-height:200px;">${reportJson.replace(/</g, '&lt;')}</pre>
        </details>
        <button id="downloadReportBtn" class="btn btn-primary" style="background:linear-gradient(135deg,#059669,#047857);width:100%;">
            <span>&#128229;</span> Download report.json
        </button>
    `;
    status.parentNode.insertBefore(reportBlock, status.nextSibling);

    document.getElementById('downloadReportBtn').addEventListener('click', () => {
        const blob = new Blob([reportJson], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'report.json';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 100);
    });
    } catch (err) {
        if (err.message !== 'Scan aborted') {
            appendTerminalLine(`Scan failed: ${err.message}`, 'error');
            panelStatus.textContent = 'FAILED';
            panelStatus.style.color = '#EF4444';
        }
    } finally {
        if (browserFolderDropzone) browserFolderDropzone.classList.remove('scanning');
        const cancelBtn = document.getElementById('cancelScanBtn');
        if (cancelBtn) cancelBtn.style.display = 'none';
        const downloadLogBtn = document.getElementById('downloadLogBtn');
        if (downloadLogBtn) downloadLogBtn.style.display = 'none';
        scanAbortController = null;
    }
}

