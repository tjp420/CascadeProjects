const fs = require('fs');
const file = 'C:/Users/Trevor/CascadeProjects/coming-soon/js/dashboard/main.js';
let content = fs.readFileSync(file, 'utf8');

// Helper: find line index from character index
function lineIndex(text, charIdx) {
    return text.slice(0, charIdx).split('\n').length;
}

// We'll replace each corrupted block using exact string boundaries

// 1. Replace execSummary block
const execStart = content.indexOf('    const execSummary = `# Executive Risk Summary');
const execEnd = content.indexOf("\n    zip.file('executive-summary.md', execSummary);");
if (execStart !== -1 && execEnd !== -1) {
    const before = content.slice(0, execStart);
    const after = content.slice(execEnd);
    const newExec = `    const execSummary = \`# Executive Risk Summary \u2014 ${escapeHtml(projectName)}

**Certificate ID:** ${certId} \u00b7 **Issued:** ${dateStr} \u00b7 **Grade:** ${grade}

## At a Glance
| Metric | Value |
|--------|-------|
| Gate Status | ${gateLabel} |
| Quality Score | ${qs}/100 |
| Files Analyzed | ${fileCount.toLocaleString()} |
| Lines of Code | ${lineCount.toLocaleString()} |
| Findings | ${issueCount} |
| EU AI Act | ${(report.euAiActSummary?.aiSystemIndicators || 0)} AI indicator(s) |

## Top Risks
${report.gate?.blockingFindings?.length ? report.gate.blockingFindings.map((f, idx) => \`${idx + 1}. **${(f.severity || 'medium').toUpperCase()}** \u2014 ${f.type || 'Finding'} (${f.count || 0}): ${(f.impact || 'Review required.').replace(/REVIEW REQUIRED[:\\s]*/i, '')}${f.fix ? \` *Fix:* ${f.fix}\` : ''}\`).join('\\n') : (topIssues.length ? topIssues.map((i, idx) => \`${idx + 1}. **${(i.severity || 'low').toUpperCase()}** \u2014 ${i.type || 'Issue'} (${i.count || 0}): ${(i.impact || 'Review required.').replace(/REVIEW REQUIRED[:\\s]*/i, '')}${i.fix ? \` *Fix:* ${i.fix}\` : ''}\`).join('\\n') : 'No actionable findings detected.')}

## Recommended Actions
${gatePassed ? '- [x] Gate passed \u2014 no immediate blocking issues.\\n' : (report.gate?.remediation?.length ? report.gate.remediation.map(r => '- [ ] **URGENT:** ' + r).join('\\n') + '\\n' : '- [ ] **URGENT:** Address ' + (report.gate?.blockingCount || 0) + ' blocking credential finding(s) before release.\\n')}${(report.euAiActSummary?.highRiskIndicators || 0) > 0 ? '- [ ] Schedule EU AI Act legal review (high-risk indicators detected).\\n' : ''}${qs < 70 ? '- [ ] Quality score below 70 \u2014 prioritize refactoring low-quality modules.\\n' : ''}${(report.consolidation?.duplicateGroups || 0) > 0 ? '- [ ] Consolidate ' + report.consolidation.duplicateGroups + ' duplicate file group(s).\\n' : ''}${(report.roadmap?.todoCount || 0) > 0 ? '- [ ] Address ' + report.roadmap.todoCount + ' TODO/FIXME marker(s) before release.\\n' : ''}- [ ] Schedule next scan in 30 days.

## Compliance Posture
${(report.euAiActSummary?.highRiskIndicators || 0) === 0 ? '\u2705 No high-risk AI indicators (Art. 5)' : '\u26a0\ufe0f High-risk AI indicators present (Art. 5)'}  
${(report.euAiActSummary?.aiSystemIndicators || 0) === 0 ? '\u2705 No AI system indicators (Art. 6)' : '\u26a0\ufe0f AI system indicators present \u2014 review classification (Art. 6)'}  
${(report.euAiActSummary?.transparencyGaps || 0) === 0 ? '\u2705 No transparency gaps (Art. 10)' : '\u26a0\ufe0f Transparency gaps present (Art. 10)'}


*This summary was generated entirely in-browser by SimpleBeacon. No source code was transmitted to external servers.*\`;`;
    content = before + newExec + after;
    console.log('Fixed execSummary');
}

fs.writeFileSync(file, content, 'utf8');
console.log('Wrote file');
