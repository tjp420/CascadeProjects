import { formatPathLabel, redactPathForDisplay, showToast, escapeHtml } from '../utils.js';
import { refreshLiveReport, normalizeProjectPath, shouldPreferLiveReport } from '../services/analyzeService.js';
import { isDemoMode, demoReadOnlyMessage } from '../demoMode.js';
import { isBenchmarkCachePath } from '../utils/complete-scan-artifact-profile.browser.js';
import { isRemoteRepoUrl } from './analyzePathSources.js';

function isPlausibleProjectPath(value) {
  const raw = String(value || '').trim();
  if (!raw || raw.length > 280) return false;
  if (isRemoteRepoUrl(raw)) return true;
  if (/outside allowed analysis roots|projectPath is required|projectPath is outside/i.test(raw)) {
    return false;
  }
  if (/^[a-zA-Z]:[\\/]/.test(raw)) return true;
  if (raw.startsWith('\\\\') || raw.startsWith('/')) return true;
  if (/^[\w.-]+([\\/]|$)/.test(raw)) return true;
  return false;
}

/** Read typed path from the active page path bar (Analyze bar or Dashboard scan input). */
export function readProjectPathInput(root) {
  const scope = root && typeof root.querySelector === 'function' ? root : document;
  const el = scope.querySelector('#project-path-input') || scope.querySelector('#scan-root-input');
  return el?.value ?? '';
}

/**
 * Resolve the repo path for dashboard page scans — uses the typed path as-is
 * (no silent upgrade to the server default / nested ai-platform folder).
 */
export function resolvePageProjectPath(inputValue, app) {
  const trimmed = String(inputValue || '').trim();
  const defaultPath = String(app.state.defaultProjectPath || '').trim();
  if (trimmed && !trimmed.startsWith('…') && isPlausibleProjectPath(trimmed)) {
    return trimmed;
  }
  if (app.state.lastProjectPath && isPlausibleProjectPath(app.state.lastProjectPath)) {
    return app.state.lastProjectPath;
  }
  if (trimmed.startsWith('…')) {
    return defaultPath;
  }
  return trimmed || defaultPath || '';
}

/** Value to show in path inputs before the user scans (last scan or server default). */
export function getPathInputDisplayValue(app) {
  if (app.state.lastProjectPath) return app.state.lastProjectPath;
  return String(app.state.defaultProjectPath || '').trim();
}

/** Active path for the current page — prefers typed input, then last scan, then default. */
export function getPageProjectPath(app, root) {
  const inputValue = root ? readProjectPathInput(root) : readProjectPathInput(document);
  return resolvePageProjectPath(inputValue, app);
}

/** Product platform root when path sits under github-cache/ (e.g. …/ai-platform/github-cache/foo). */
export function productPlatformRootFromBenchmarkPath(projectPath) {
  const normalized = String(projectPath || '').replace(/\\/g, '/');
  const idx = normalized.toLowerCase().indexOf('/github-cache/');
  return idx > 0 ? normalized.slice(0, idx) : null;
}

/**
 * EU compliance / handoff scans must target product code — not OSS benchmark clones.
 * Falls back to server default when the typed or remembered path is under github-cache/.
 */
export function resolveProductCompliancePath(inputValue, app) {
  const resolved = resolvePageProjectPath(inputValue, app);
  const defaultPath = String(app.state.defaultProjectPath || '').trim();
  if (resolved && isBenchmarkCachePath(resolved)) {
    if (defaultPath && !isBenchmarkCachePath(defaultPath)) {
      return defaultPath;
    }
    const productRoot = productPlatformRootFromBenchmarkPath(resolved);
    if (productRoot && !isBenchmarkCachePath(productRoot)) {
      return productRoot;
    }
  }
  return resolved || defaultPath;
}

export function ensureProductCompliancePath(app, root) {
  const current = getPageProjectPath(app, root);
  const defaultPath = String(app.state.defaultProjectPath || '').trim();
  if (current && isBenchmarkCachePath(current)) {
    const productRoot = resolveProductCompliancePath(current, app);
    if (productRoot && productRoot !== current) {
      app.state.lastProjectPath = productRoot;
      return productRoot;
    }
  }
  return current;
}

export function reportMatchesPagePath(report, projectPath) {
  if (!report?.projectRoot || !projectPath) return false;
  const a = normalizeProjectPath(report.projectRoot);
  const b = normalizeProjectPath(projectPath);
  return a === b || a.startsWith(`${b}/`) || b.startsWith(`${a}/`);
}

/** Report artifact that matches the requested repo path (ignores stale global report). */
export function reportForProjectPath(app, projectPath) {
  const path = String(projectPath || '').trim();
  if (!path) return null;
  if (app.state.report && reportMatchesPagePath(app.state.report, path)) {
    return app.state.report;
  }
  const analyzeReport = app.state.analyzeResult?.report;
  if (analyzeReport && reportMatchesPagePath(analyzeReport, path)) {
    return analyzeReport;
  }
  return null;
}

/** Report for the path currently selected on a dashboard page. */
export function getPageReport(app, root) {
  return reportForProjectPath(app, getPageProjectPath(app, root));
}

export function syncPathChipStates(root, projectPath) {
  if (!root) return;
  const activeNorm = projectPath ? normalizeProjectPath(projectPath) : '';
  root.querySelectorAll('.analyze-path-chip-wrap').forEach((wrap) => {
    const chip = wrap.querySelector('.analyze-path-chip');
    const chipPath = chip?.dataset.path || '';
    const active = Boolean(activeNorm && chipPath && normalizeProjectPath(chipPath) === activeNorm);
    wrap.classList.toggle('active', active);
    chip?.classList.toggle('active', active);
  });
}

export function renderPageScanContext(app, options = {}) {
  const requested = options.requestedPath
    || (options.container ? getPageProjectPath(app, options.container) : getPageProjectPath(app));
  const report = options.report ?? reportForProjectPath(app, requested);
  const reportRoot = report?.projectRoot || '';
  const bundleRoot = options.bundleProjectPath || '';
  const scannedRoot = bundleRoot || reportRoot;

  if (!requested && !scannedRoot && !options.force) return '';

  const requestedLabel = requested ? formatPathLabel(requested) || redactPathForDisplay(requested) : '';
  const scannedLabel = scannedRoot ? formatPathLabel(scannedRoot) || redactPathForDisplay(scannedRoot) : '';
  const mismatch = requested && scannedRoot && !reportMatchesPagePath({ projectRoot: scannedRoot }, requested);

  const gate = report?.gate?.pass;
  const gateChip = gate === true
    ? '<span class="gate-badge pass">GATE PASS</span>'
    : gate === false
      ? '<span class="gate-badge warn">GATE REVIEW</span>'
      : '';
  const scannedAt = report?.generatedAt
    ? new Date(report.generatedAt).toLocaleString()
    : '';

  return `
    <div class="card mb-4 analyze-page-scan-context" data-page-scan-context>
      <p class="text-muted" style="margin:0;font-size:var(--font-size-sm);">
        ${requestedLabel
    ? `Scan target: <code>${escapeHtml(requestedLabel)}</code>`
    : 'Enter a folder path above, then run scan.'}
        ${scannedLabel && requestedLabel && mismatch
    ? ` · Artifacts loaded from <code>${escapeHtml(scannedLabel)}</code>`
    : scannedLabel && !requestedLabel
      ? ` · Showing results for <code>${escapeHtml(scannedLabel)}</code>`
      : ''}
        ${gateChip ? ` ${gateChip}` : ''}
        ${scannedAt ? ` · ${escapeHtml(scannedAt)}` : ''}
      </p>
      ${mismatch ? `
        <p class="text-warning" style="margin:0.35rem 0 0;font-size:var(--font-size-xs);">
          Requested path differs from loaded artifact root — run scan again on this page or pick the exact repo folder.
        </p>
      ` : ''}
    </div>
  `;
}

export function updatePageScanContextDom(container, app, options = {}) {
  if (!container) return;
  const pathInput = container.querySelector('#project-path-input');
  const projectPath = getPageProjectPath(app, container);
  const report = reportForProjectPath(app, projectPath);
  const slot = container.querySelector('[data-page-scan-context]');
  const html = renderPageScanContext(app, {
    ...options,
    container,
    requestedPath: projectPath,
    report
  });
  if (slot) {
    slot.outerHTML = html || '';
  } else if (html) {
    const bar = container.querySelector('[data-analyze-path-bar]');
    bar?.insertAdjacentHTML('afterend', html);
  }
}

/** Load report.json for the given path into app.state (when available). */
export async function refreshAppReportForPath(app, projectPath, root) {
  const path = String(
    projectPath
    || (root ? getPageProjectPath(app, root) : getPageProjectPath(app))
    || ''
  ).trim();
  if (!path) {
    return refreshLiveReport(app.scanService, app.state);
  }
  try {
    const live = await app.scanService.fetchReport(path);
    if (live && reportMatchesPagePath(live, path)) {
      const staleRoot = app.state.report && !reportMatchesPagePath(app.state.report, path);
      if (!app.state.report || staleRoot || shouldPreferLiveReport(app.state.report, live)) {
        app.state.report = live;
      }
    }
  } catch {
    /* No report on disk for this path yet — page panels use config defaults. */
  }
  return app.state.report;
}

/** Gate scan via SimpleBeacon API for the path entered on the current page. */
export async function runPageRepoScan(app, projectPath, options = {}) {
  if (isDemoMode()) {
    showToast(demoReadOnlyMessage(), 'info');
    return null;
  }
  if (app.state.scanning) return null;
  const root = options.container;
  const resolved = String(
    projectPath
    || (root ? getPageProjectPath(app, root) : resolvePageProjectPath('', app))
    || ''
  ).trim();
  if (!resolved) {
    showToast('Enter a project path on the dashboard server', 'error');
    return null;
  }

  app.state.scanning = true;
  if (typeof app.refreshCurrentView === 'function') {
    app.refreshCurrentView();
  }

  try {
    await app.scanService.runScan(resolved);
    app.state.lastProjectPath = resolved;
    Object.assign(app.state, {
      report: app.scanService.report,
      baseline: app.scanService.baseline,
      config: app.scanService.config,
      history: app.scanService.history,
      audit: null
    });
    await refreshAppReportForPath(app, resolved, root);
    app.views.audit?.invalidateCache?.();
    return { projectPath: resolved, report: app.state.report };
  } finally {
    app.state.scanning = false;
  }
}
