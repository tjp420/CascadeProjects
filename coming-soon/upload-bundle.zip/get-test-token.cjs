const fs = require('fs');
const storePath = require('path').join(__dirname, '..', '.simplebeacon', 'subscriptions.json');
const store = JSON.parse(fs.readFileSync(storePath, 'utf8'));
const targetEmail = process.env.SIMPLEBEACON_OWNER_EMAIL || 'trevor_punt@live.com';
const rec = store.subscriptions[targetEmail];
if (rec && rec.licenseToken) {
  fs.writeFileSync(require('path').join(__dirname, '..', '.simplebeacon', 'test-token.txt'), rec.licenseToken + '\n');
  console.log('Token saved to .simplebeacon/test-token.txt');
} else {
  console.log('No token found');
}
