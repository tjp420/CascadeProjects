const fs = require('fs');
const p = 'c:/Users/Trevor/CascadeProjects/coming-soon/js/dashboard/main.js';
let c = fs.readFileSync(p, 'utf8');

const startNeedle = '// Download selected module\'s full data as JSON\nfunction downloadSelectedModule(btn) {';
const startIdx = c.indexOf(startNeedle);
if (startIdx === -1) { console.log('START NOT FOUND'); process.exit(1); }

const endNeedle = "        const mod = (window._scanPreviewModules || []).find(m => m.id === select.value);";
const endIdx = c.indexOf(endNeedle, startIdx);
if (endIdx === -1) { console.log('END NOT FOUND'); process.exit(1); }

const replacement = `// Redact all leaf data values while preserving structure
function redactReport(obj) {
    if (obj === null || obj === undefined) return obj;
    if (typeof obj === 'number' || typeof obj === 'boolean') return obj;
    if (typeof obj === 'string') return '***REDACTED***';
    if (Array.isArray(obj)) return obj.length ? ['***REDACTED***'] : [];
    const out = {};
    for (const key in obj) {
        if (!Object.prototype.hasOwnProperty.call(obj, key)) continue;
        const val = obj[key];
        if (typeof val === 'string') out[key] = '***REDACTED***';
        else if (typeof val === 'number' || typeof val === 'boolean') out[key] = val;
        else if (Array.isArray(val)) out[key] = val.length ? ['***REDACTED***'] : [];
        else if (val && typeof val === 'object') out[key] = redactReport(val);
        else out[key] = val;
    }
    return out;
}

// Download selected module's full data as JSON
function downloadSelectedModule(btn) {
    try {
        const container = btn.closest('[style*="display:flex;gap:8px"]') || btn.parentElement;
        if (!container) { console.error('Export: no container found'); showToast('Export button layout error', 'error'); return; }
        const select = container.querySelector('.module-dropdown');
        if (!select || !select.value) {
            showToast('Select a module first', 'warning');
            return;
        }
        const data = window._scanPreviewData || {};
        if (select.value === '__full_report__') {
            const tier = window._tokenPayload?.tier || window._tokenPayload?.product || 'locked';
            const isFree = tier === 'instant';
            const projectName = data.projectRoot || data.projectPath || data.projectName || 'local-scan';
            const rawReport = {
                metadata: {
                    projectName,
                    generatedAt: new Date().toISOString(),
                    scanVersion: '1.3.0',
                    totalModules: (window._scanPreviewModules || []).length,
                    exportType: isFree ? 'redacted-report' : 'complete-report',
                    tier
                },
                ...data
            };
            const fullReport = isFree ? redactReport(rawReport) : rawReport;
            const blob = new Blob([JSON.stringify(fullReport, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = \`simplebeacon-full-report-\${projectName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-\${new Date().toISOString().slice(0,10)}.json\`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
            showToast(isFree ? 'Downloaded redacted report (upgrade for full data)' : 'Downloaded complete report data', 'success');
            return;
        }
        `;

const before = c.slice(0, startIdx);
const after = c.slice(endIdx);
const result = before + replacement + after;
fs.writeFileSync(p, result);
console.log('OK');
