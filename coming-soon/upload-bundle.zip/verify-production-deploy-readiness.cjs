#!/usr/bin/env node

/**
 * Production Deploy Readiness Verification
 * 
 * This script verifies that the Simplebeacon platform is ready for production deployment
 * by checking all critical components, configurations, and security measures.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CHECKS = {
  // Environment Configuration
  ENVIRONMENT_VARS: {
    name: 'Environment Variables',
    required: [
      'NODE_ENV',
      'REQUIRE_AUTH',
      'JWT_SECRET',
      'JWT_REFRESH_SECRET',
      'SIMPLEBEACON_INTERNAL_DASHBOARD'
    ],
    production: [
      'NODE_ENV=production',
      'REQUIRE_AUTH=true',
      'SEED_DEMO_USERS=false',
      'ALLOW_LEGACY_LOGIN=false'
    ]
  },

  // Security Configuration
  SECURITY: {
    name: 'Security Configuration',
    checks: [
      'JWT secrets must be 32+ characters',
      'No placeholder values in production',
      'HTTPS configuration',
      'Security headers enabled',
      'Rate limiting configured'
    ]
  },

  // Database Configuration
  DATABASE: {
    name: 'Database Configuration',
    required: [
      'POSTGRES_HOST',
      'POSTGRES_PORT',
      'POSTGRES_DB',
      'POSTGRES_USER',
      'POSTGRES_PASSWORD'
    ],
    checks: [
      'Database connectivity',
      'SSL/TLS configuration',
      'Connection pooling',
      'Migration scripts'
    ]
  },

  // Infrastructure
  INFRASTRUCTURE: {
    name: 'Infrastructure',
    checks: [
      'Docker configuration',
      'Health checks',
      'Monitoring setup',
      'Logging configuration',
      'Backup procedures'
    ]
  },

  // Testing and Quality
  TESTING: {
    name: 'Testing and Quality',
    checks: [
      'Unit tests passing',
      'Integration tests passing',
      'Coverage thresholds met',
      'Security audit passed',
      'Performance tests passed'
    ]
  },

  // Documentation
  DOCUMENTATION: {
    name: 'Documentation',
    required: [
      'docs/v1-internal-runbook.md',
      'README.md',
      'CHANGELOG.md'
    ],
    checks: [
      'API documentation',
      'Deployment guide',
      'Troubleshooting guide',
      'Security policies'
    ]
  }
};

class ProductionDeployVerifier {
  constructor() {
    this.results = {
      passed: [],
      failed: [],
      warnings: []
    };
    this.isProduction = process.env.NODE_ENV === 'production';
  }

  log(message, type = 'info') {
    const prefix = type === 'error' ? '❌' : type === 'warning' ? '⚠️' : type === 'success' ? '✅' : 'ℹ️';
    console.log(`${prefix} ${message}`);
  }

  checkEnvironmentVariables() {
    this.log(`Checking ${CHECKS.ENVIRONMENT_VARS.name}...`);

    // Check required environment variables
    for (const varName of CHECKS.ENVIRONMENT_VARS.required) {
      const value = process.env[varName];
      
      if (!value) {
        this.log(`Missing required environment variable: ${varName}`, 'error');
        this.results.failed.push(`Missing ${varName}`);
        continue;
      }

      // Check for placeholder values in production
      if (this.isProduction && this.isPlaceholderValue(value)) {
        this.log(`Production environment has placeholder value: ${varName}`, 'error');
        this.results.failed.push(`Placeholder value for ${varName}`);
        continue;
      }

      // Check JWT secret length
      if (varName.includes('JWT_SECRET') && value.length < 32) {
        this.log(`JWT secret too short: ${varName} (${value.length} chars)`, 'error');
        this.results.failed.push(`Short JWT secret: ${varName}`);
        continue;
      }

      this.log(`Environment variable configured: ${varName}`, 'success');
      this.results.passed.push(`${varName} configured`);
    }

    // Check production-specific requirements
    if (this.isProduction) {
      for (const requirement of CHECKS.ENVIRONMENT_VARS.production) {
        const [key, expectedValue] = requirement.split('=');
        const actualValue = process.env[key];
        
        if (actualValue !== expectedValue) {
          this.log(`Production requirement not met: ${key}=${actualValue} (expected ${expectedValue})`, 'error');
          this.results.failed.push(`Production setting: ${key}`);
        } else {
          this.log(`Production requirement met: ${requirement}`, 'success');
          this.results.passed.push(`Production setting: ${key}`);
        }
      }
    }
  }

  isPlaceholderValue(value) {
    const placeholders = [
      'your-', 'change-in-production', 'replace-with', 'dev-', 'test-',
      'example-', 'placeholder', 'secret-key', 'password'
    ];
    
    return placeholders.some(placeholder => 
      value.toLowerCase().includes(placeholder.toLowerCase())
    );
  }

  checkSecurityConfiguration() {
    this.log(`Checking ${CHECKS.SECURITY.name}...`);

    // Check JWT configuration
    const jwtSecret = process.env.JWT_SECRET;
    const jwtRefreshSecret = process.env.JWT_REFRESH_SECRET;
    
    if (jwtSecret && jwtSecret.length >= 32) {
      this.log('JWT secret properly configured', 'success');
      this.results.passed.push('JWT secret length');
    } else {
      this.log('JWT secret not properly configured', 'error');
      this.results.failed.push('JWT secret configuration');
    }

    // Check for HTTPS in production
    if (this.isProduction) {
      const httpsEnabled = process.env.HTTPS_ENABLED === 'true' || 
                         process.env.FORCE_HTTPS === 'true' ||
                         process.env.NODE_ENV === 'production';
      
      if (httpsEnabled) {
        this.log('HTTPS configuration detected', 'success');
        this.results.passed.push('HTTPS enabled');
      } else {
        this.log('HTTPS not configured for production', 'error');
        this.results.failed.push('HTTPS required for production');
      }
    }

    // Check security headers
    const helmetEnabled = process.env.HELMET_ENABLED === 'true';
    if (helmetEnabled) {
      this.log('Security headers enabled', 'success');
      this.results.passed.push('Security headers');
    } else {
      this.log('Security headers not enabled', 'warning');
      this.results.warnings.push('Security headers recommended');
    }

    // Check rate limiting
    const rateLimitEnabled = process.env.RATE_LIMIT_ENABLED === 'true';
    if (rateLimitEnabled) {
      this.log('Rate limiting enabled', 'success');
      this.results.passed.push('Rate limiting');
    } else {
      this.log('Rate limiting not enabled', 'warning');
      this.results.warnings.push('Rate limiting recommended');
    }
  }

  checkDatabaseConfiguration() {
    this.log(`Checking ${CHECKS.DATABASE.name}...`);

    const dbVars = CHECKS.DATABASE.required;
    let dbConfigured = true;

    for (const varName of dbVars) {
      if (!process.env[varName]) {
        this.log(`Database variable missing: ${varName}`, 'error');
        this.results.failed.push(`Database config: ${varName}`);
        dbConfigured = false;
      }
    }

    if (dbConfigured) {
      this.log('Database configuration complete', 'success');
      this.results.passed.push('Database configuration');
    }

    // Check database connectivity (if we can)
    if (dbConfigured && process.env.POSTGRES_HOST) {
      try {
        // This would require pg module, so we'll just check if we can import it
        require('pg');
        this.log('Database driver available', 'success');
        this.results.passed.push('Database driver');
      } catch (error) {
        this.log('Database driver not available', 'warning');
        this.results.warnings.push('Database driver missing');
      }
    }
  }

  checkInfrastructure() {
    this.log(`Checking ${CHECKS.INFRASTRUCTURE.name}...`);

    // Check Docker configuration
    const dockerComposeFiles = [
      'docker-compose.yml',
      'docker-compose.phase2.yml',
      'docker-compose.production.yml'
    ];

    let dockerConfigured = false;
    for (const file of dockerComposeFiles) {
      if (fs.existsSync(file)) {
        this.log(`Docker configuration found: ${file}`, 'success');
        this.results.passed.push(`Docker config: ${file}`);
        dockerConfigured = true;
      }
    }

    if (!dockerConfigured) {
      this.log('No Docker configuration found', 'warning');
      this.results.warnings.push('Docker configuration recommended');
    }

    // Check health check endpoints
    const healthCheckFiles = [
      'server/index.cjs',
      'tools/run-route-smoke-suite.js'
    ];

    for (const file of healthCheckFiles) {
      if (fs.existsSync(file)) {
        this.log(`Health check infrastructure: ${file}`, 'success');
        this.results.passed.push(`Health check: ${file}`);
      }
    }

    // Check monitoring configuration
    const monitoringEnabled = process.env.MONITORING_ENABLED === 'true' ||
                           process.env.METRICS_ENABLED === 'true';
    
    if (monitoringEnabled) {
      this.log('Monitoring configuration detected', 'success');
      this.results.passed.push('Monitoring enabled');
    } else {
      this.log('Monitoring not configured', 'warning');
      this.results.warnings.push('Monitoring recommended');
    }
  }

  checkTestingAndQuality() {
    this.log(`Checking ${CHECKS.TESTING.name}...`);

    try {
      // Run tests
      const testResult = execSync('npm test 2>&1', { 
        encoding: 'utf8',
        timeout: 30000
      });
      
      if (testResult.includes('Test Suites:')) {
        this.log('Tests can be executed', 'success');
        this.results.passed.push('Tests executable');
      }
    } catch (error) {
      this.log('Tests execution failed', 'error');
      this.results.failed.push('Tests not passing');
    }

    // Check test configuration
    if (fs.existsSync('jest.config.js')) {
      this.log('Test configuration found', 'success');
      this.results.passed.push('Test config');
    }

    // Check coverage configuration
    if (fs.existsSync('coverage/') || fs.existsSync('jest.config.js')) {
      this.log('Coverage configuration available', 'success');
      this.results.passed.push('Coverage config');
    }
  }

  checkDocumentation() {
    this.log(`Checking ${CHECKS.DOCUMENTATION.name}...`);

    for (const file of CHECKS.DOCUMENTATION.required) {
      if (fs.existsSync(file)) {
        this.log(`Documentation found: ${file}`, 'success');
        this.results.passed.push(`Documentation: ${file}`);
      } else {
        this.log(`Documentation missing: ${file}`, 'warning');
        this.results.warnings.push(`Missing documentation: ${file}`);
      }
    }

    // Check API documentation
    const apiDocs = [
      'docs/api/',
      'docs/api.md',
      'API.md'
    ];

    let apiDocsFound = false;
    for (const doc of apiDocs) {
      if (fs.existsSync(doc)) {
        this.log(`API documentation found: ${doc}`, 'success');
        this.results.passed.push(`API docs: ${doc}`);
        apiDocsFound = true;
      }
    }

    if (!apiDocsFound) {
      this.log('API documentation not found', 'warning');
      this.results.warnings.push('API documentation recommended');
    }
  }

  runAllChecks() {
    console.log('🔍 Starting Production Deploy Readiness Verification\n');
    console.log(`Environment: ${this.isProduction ? '🚨 PRODUCTION' : '🧪 DEVELOPMENT'}\n`);

    this.checkEnvironmentVariables();
    this.checkSecurityConfiguration();
    this.checkDatabaseConfiguration();
    this.checkInfrastructure();
    this.checkTestingAndQuality();
    this.checkDocumentation();

    this.generateReport();
  }

  generateReport() {
    console.log('\n📊 Production Deploy Readiness Report');
    console.log('=====================================\n');

    const totalChecks = this.results.passed.length + this.results.failed.length + this.results.warnings.length;
    const passRate = totalChecks > 0 ? (this.results.passed.length / totalChecks * 100).toFixed(1) : 0;

    console.log(`✅ Passed: ${this.results.passed.length}`);
    console.log(`❌ Failed: ${this.results.failed.length}`);
    console.log(`⚠️  Warnings: ${this.results.warnings.length}`);
    console.log(`📈 Pass Rate: ${passRate}%\n`);

    if (this.results.failed.length > 0) {
      console.log('🚨 CRITICAL ISSUES (Must Fix Before Deploy):');
      this.results.failed.forEach(issue => console.log(`   - ${issue}`));
      console.log('');
    }

    if (this.results.warnings.length > 0) {
      console.log('⚠️  WARNINGS (Recommended for Production):');
      this.results.warnings.forEach(warning => console.log(`   - ${warning}`));
      console.log('');
    }

    if (this.results.passed.length > 0) {
      console.log('✅ SUCCESSFULLY CONFIGURED:');
      this.results.passed.forEach(pass => console.log(`   - ${pass}`));
      console.log('');
    }

    // Overall assessment
    if (this.results.failed.length === 0) {
      console.log('🎉 RESULT: READY FOR PRODUCTION DEPLOY');
      console.log('   All critical checks passed. Review warnings and proceed with deployment.');
      process.exit(0);
    } else {
      console.log('🚫 RESULT: NOT READY FOR PRODUCTION DEPLOY');
      console.log('   Please address all critical issues before deploying to production.');
      process.exit(1);
    }
  }
}

// Main execution
if (require.main === module) {
  const verifier = new ProductionDeployVerifier();
  verifier.runAllChecks();
}

module.exports = ProductionDeployVerifier;
