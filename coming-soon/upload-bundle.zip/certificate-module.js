// Defensive: ensure escapeHtml is available even if utils.js fails to load
if (typeof window !== 'undefined' && !window.escapeHtml) {
    window.escapeHtml = function(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    };
}

// ============================================================================
// ZIP Markdown Template Schema — drives uniform module report generation
// ============================================================================
const ZIP_MARKDOWN_TEMPLATES = [
    { moduleId: '17', section: 'aiResidue', title: 'AI Residue', metricLabel: 'AI Residue Hits', advice: 'Review stubs, deprecated APIs, error swallowing, and dead code blocks before production.', filename: 'ai-residue.md' },
    { moduleId: '18', section: 'performance', title: 'Performance', metricLabel: 'Performance Hits', advice: 'Review nested loops, leaked event listeners, and inefficient regex patterns.', filename: 'performance.md' },
    { moduleId: '19', section: 'typeSafety', title: 'Type Safety', metricLabel: 'Type Safety Hits', advice: 'Replace `any` types, add PropTypes, and reduce excessive parameters.', filename: 'type-safety.md' },
    { moduleId: '20', section: 'documentation', title: 'Documentation', metricLabel: 'Documentation Gaps', advice: 'Add JSDoc to public functions and keep README in sync with code changes.', filename: 'documentation.md' },
    { moduleId: '21', section: 'testCoverage', title: 'Test Coverage', metricLabel: 'Test Coverage Gaps', advice: 'Ensure all production code has active test coverage; remove or fix skipped tests.', filename: 'test-coverage.md' },
    { moduleId: '22', section: 'accessibility', title: 'Accessibility', metricLabel: 'Accessibility Gaps', advice: 'Add alt text to images, label all inputs, and ensure buttons have accessible names.', filename: 'accessibility.md' },
    { moduleId: '23', section: 'i18n', title: 'i18n Readiness', metricLabel: 'i18n Issues', advice: 'Wrap UI strings with i18n functions and use locale-aware formatting.', filename: 'i18n.md' },
    { moduleId: '24', section: 'sensitiveData', title: 'Sensitive Data Exposure', metricLabel: 'Sensitive Data Hits', advice: 'Remove PII from logs and source code; never store tokens or passwords in localStorage.', filename: 'sensitive-data.md' },
    { moduleId: '25', section: 'configDrift', title: 'Configuration Drift', metricLabel: 'Config Drift Hits', advice: 'Move secrets to environment variables; avoid committing .env files to version control.', filename: 'config-drift.md' },
    { moduleId: '26', section: 'securityHeaders', title: 'Security Headers', metricLabel: 'Security Header References', advice: 'Verify CSP, X-Frame-Options, HSTS, and Referrer-Policy are configured on all responses.', filename: 'security-headers.md' },
    { moduleId: '27', section: 'databasePatterns', title: 'Database Patterns', metricLabel: 'Database Anti-Patterns', advice: 'Use parameterized queries, add pagination, and ensure transactions have rollback.', filename: 'database-patterns.md' },
    { moduleId: '28', section: 'frameworkPractices', title: 'Framework Practices', metricLabel: 'Framework Issues', advice: 'Fix React hook dependency arrays, avoid direct DOM access, and clean up subscriptions.', filename: 'framework-practices.md' },
    { moduleId: '29', section: 'workspaceHealth', title: 'Workspace Health', metricLabel: 'Workspace Issues', advice: 'Review circular imports and ensure dependency versions are consistent across packages.', filename: 'workspace-health.md' },
    { moduleId: '30', section: 'unusedDeps', title: 'Unused Dependencies', metricLabel: 'Unused Dependency Flags', advice: 'Cross-reference package.json against source imports to remove unused packages.', filename: 'unused-deps.md' },
    { moduleId: '31', section: 'apiContract', title: 'API Contract', metricLabel: 'API Contract Drifts', advice: 'Verify all REST endpoints have frontend consumers and OpenAPI specs are current.', filename: 'api-contract.md' },
    { moduleId: '32', section: 'complexity', title: 'Complexity Metrics', metricLabel: 'High Complexity Patterns', advice: 'Break down long functions, reduce nesting depth, and extract helper functions.', filename: 'complexity.md' }
];

function generateZipModuleMarkdown(zip, allowedModules, filteredReport, projectName, dateStr, template) {
    if (!allowedModules.includes(template.moduleId)) return;
    const data = filteredReport[template.section] || {};
    const hits = data[`${template.section}Hits`] || 0;
    const list = (data[`${template.section}Findings`] || []).slice(0, 10);
    const md = `# ${template.title} Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| ${template.metricLabel} | ${hits} |\n\n${list.length ? `## Findings\n\n${list.map(f => `- ${f.file} (${f.type})`).join('\n')}\n` : ''}> ${template.advice}\n`;
    zip.file(template.filename, md);
}

async function generateSovereignCertificate(report, token) {
    if (!window.JSZip || !window.html2canvas) {
        throw new Error('Certificate libraries not loaded. Check your network connection.');
    }
    if (false) { /* token optional for certificate generation */
        throw new Error('Invalid or malformed license token. Please paste a valid token.');
    }
    if (!report || typeof report !== 'object' || Object.keys(report).length === 0) {
        throw new Error('Report data is missing or empty. Run a scan first.');
    }

    const zip = new JSZip();
    const now = new Date();
    const certId = 'SB-' + crypto.getRandomValues(new Uint32Array(1))[0];
    const dateStr = now.toLocaleDateString();
    const isoDate = now.toISOString();
    const projectName = report.projectName || 'Untitled Project';
    const fileCount = report.filesAnalyzed || report.totalFiles || report.fileCount || 0;
    const lineCount = report.totalLines || report.linesOfCode || 0;
    const gateReport = report.gateReport || report.gate || {};
    const issueCount = (gateReport.blockingIssues || []).length + (gateReport.warningIssues || []).length;
    const qs = Number.isFinite(report.qualityScore) ? report.qualityScore : (report.qualityScore || 0);
    let grade = 'F';
    let gradeColor = '#EF4444';
    if (qs >= 95) { grade = 'A'; gradeColor = '#34D399'; }
    else if (qs >= 85) { grade = 'B'; gradeColor = '#60A5FA'; }
    else if (qs >= 70) { grade = 'C'; gradeColor = '#F59E0B'; }
    else if (qs >= 50) { grade = 'D'; gradeColor = '#F97316'; }

    const gatePassed = report.gate?.pass === true || report.gate?.status === 'PASS';
    const gateLabel = gatePassed ? 'PASS' : (report.gate?.blockingCount ? 'BLOCKED' : 'REVIEW');
    const gateColor = gatePassed ? '#34D399' : '#EF4444';
    const profileLabel = (window._tokenPayload?.tier || window._tokenPayload?.product || 'executive').toUpperCase();

    // Map UI module IDs (from analyzer dropdown) to certificate numeric module IDs
    const UI_TO_CERT_MODULE = {
        'gate': '1', 'consolidation': '2', 'mock-data': '3', 'roadmap': '4',
        'codebase': '5', 'file-reduction': '6', 'data-quality': '7', 'cleanup': '8',
        'npm-audit': '9', 'compliance': '10', 'eu-ai-act': '11', 'dependency-vulns': '12',
        'build-readiness': '13', 'ai-indicators': '14', 'governance': '15', 'junk-files': '16', 'ai-residue': '17',
        'performance': '18', 'type-safety': '19', 'documentation': '20', 'test-coverage': '21', 'accessibility': '22',
        'i18n': '23', 'sensitive-data': '24', 'config-drift': '25', 'security-headers': '26', 'database-patterns': '27',
        'framework-practices': '28', 'workspace-health': '29', 'unused-deps': '30', 'api-contract': '31', 'complexity': '32'
    };
    // Read selected modules from the analyzer card grid (global selectedModules Set)
    let allowedModules = [];
    if (typeof selectedModules !== 'undefined' && selectedModules instanceof Set && selectedModules.size > 0) {
        allowedModules = Array.from(selectedModules).map(id => UI_TO_CERT_MODULE[id]).filter(Boolean);
    }
    // Always enforce tier-based unlocking — intersect with what the user actually paid for
    const paidModules = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32'].filter(m => isModulePaidFor(m));
    if (allowedModules.length > 0) {
        allowedModules = allowedModules.filter(m => paidModules.includes(m));
    } else {
        allowedModules = paidModules;
    }

    const moduleKeyMap = {
        '1': ['gateReport', 'gate'],
        '2': ['consolidation'],
        '3': ['mockDataCategories', 'mockSampleFiles'],
        '4': ['roadmap', 'remediationPhases'],
        '5': ['codebase'],
        '6': ['fileReduction'],
        '7': ['dataQuality'],
        '8': ['cleanup'],
        '9': ['npmAudit'],
        '10': ['compliance'],
        '11': ['euAiActSummary', 'checkEuAi'],
        '12': ['dependencyAudit', 'vulnerabilityAudit'],
        '13': ['buildReadiness'],
        '14': ['aiIndicators'],
        '15': ['governance', 'compliance'],
        '16': ['junkFiles'],
        '17': ['aiResidue', 'aiResidueFindings'],
        '18': ['performance', 'performanceFindings'],
        '19': ['typeSafety', 'typeSafetyFindings'],
        '20': ['documentation', 'documentationFindings'],
        '21': ['testCoverage', 'testCoverageFindings'],
        '22': ['accessibility', 'accessibilityFindings'],
        '23': ['i18n', 'i18nFindings'],
        '24': ['sensitiveData', 'sensitiveDataFindings'],
        '25': ['configDrift', 'configDriftFindings'],
        '26': ['securityHeaders', 'securityHeadersFindings'],
        '27': ['databasePatterns', 'databasePatternsFindings'],
        '28': ['frameworkPractices', 'frameworkPracticesFindings'],
        '29': ['workspaceHealth', 'workspaceHealthFindings'],
        '30': ['unusedDeps', 'unusedDepsFindings'],
        '31': ['apiContract', 'apiContractFindings'],
        '32': ['complexity', 'complexityFindings']
    };
    const baseKeys = [
        'type', 'reportVersion', 'version', 'generatedAt', 'generatedBy', 'scanProfileLabel',
        'projectName', 'projectRoot', 'projectPath', 'scanTargetRoot', 'platformRoot',
        'filesAnalyzed', 'totalFiles', 'fileCount', 'fileList', 'repositoryInventory',
        'totalLines', 'linesOfCode', 'qualityScore', 'schemaCompliance', 'consistencyScore',
        'duplicateGroups', 'invalidJson', 'emptyFiles', 'schemaChecked', 'schemaPassed',
        'issues', 'issueCount', 'simplebeaconIssues', 'detectedIssues', 'severityCounts',
        'gate', 'gateReport', 'summary',
        'timestamp', 'metadata', 'totalModules', 'exportType',
        'euAiActFindings', 'euAiActScanned',
        'aiContext'
    ];

    const perModuleData = {
        '1': { gateReport: report.gateReport, gate: report.gate },
        '2': { consolidation: report.consolidation },
        '3': { mockDataCategories: report.mockDataCategories, mockSampleFiles: report.mockSampleFiles },
        '4': { roadmap: report.roadmap, remediationPhases: report.remediationPhases },
        '5': { codebase: report.codebase },
        '6': { fileReduction: report.fileReduction },
        '7': { dataQuality: report.dataQuality },
        '8': { cleanup: report.cleanup },
        '9': { npmAudit: report.npmAudit },
        '10': { compliance: report.compliance },
        '11': { euAiActSummary: report.euAiActSummary, checkEuAi: report.checkEuAi, euAiActFindings: report.euAiActFindings, euAiActScanned: report.euAiActScanned },
        '12': { dependencyAudit: report.dependencyAudit, vulnerabilityAudit: report.vulnerabilityAudit },
        '13': { buildReadiness: report.buildReadiness },
        '14': { aiIndicators: report.aiIndicators },
        '15': { governance: report.governance, compliance: report.compliance },
        '16': { junkFiles: report.junkFiles },
        '17': { aiResidue: report.aiResidue },
        '18': { performance: report.performance },
        '19': { typeSafety: report.typeSafety },
        '20': { documentation: report.documentation },
        '21': { testCoverage: report.testCoverage },
        '22': { accessibility: report.accessibility },
        '23': { i18n: report.i18n },
        '24': { sensitiveData: report.sensitiveData },
        '25': { configDrift: report.configDrift },
        '26': { securityHeaders: report.securityHeaders },
        '27': { databasePatterns: report.databasePatterns },
        '28': { frameworkPractices: report.frameworkPractices },
        '29': { workspaceHealth: report.workspaceHealth },
        '30': { unusedDeps: report.unusedDeps },
        '31': { apiContract: report.apiContract },
        '32': { complexity: report.complexity }
    };

    // Assemble comprehensive report.json with ALL available scan data for rich roadmap generation
    const assembledReport = {};
    for (const key of baseKeys) {
        if (report[key] != null) assembledReport[key] = report[key];
    }
    // Include ALL per-module data regardless of tier so roadmaps have full detail
    for (const data of Object.values(perModuleData)) {
        Object.entries(data).forEach(([k, v]) => { if (v != null) assembledReport[k] = v; });
    }
    const filteredReport = assembledReport;

    const reportHash = await computeSha256(JSON.stringify(assembledReport));
    const shortHash = reportHash.slice(0, 16) + '...' + reportHash.slice(-8);

    const certHtml = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>SimpleBeacon Certificate — ${escapeHtml(projectName)}</title>
<style>body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;background:#0B0F19;color:#F3F4F6;margin:0;padding:40px;line-height:1.6;} .cert-wrap{max-width:800px;margin:0 auto;border:2px solid rgba(37,99,235,0.3);padding:32px;background:#0F1626;} .header{display:flex;justify-content:space-between;border-bottom:1px solid #1E293B;padding-bottom:20px;margin-bottom:24px;} h1{margin:0;font-size:22px;letter-spacing:0.08em;text-transform:uppercase;} .meta{font-size:11px;color:#9CA3AF;text-align:right;line-height:1.6;} .panel{background:#0B0F19;border:1px solid #1E293B;border-radius:8px;padding:16px;margin-bottom:16px;display:grid;grid-template-columns:1fr 1fr;gap:10px 24px;font-size:12px;} .seal{background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.2);border-radius:8px;padding:12px;margin-top:16px;} .seal code{font-size:10px;color:#64748B;word-break:break-all;} .footer{border-top:1px solid #1E293B;padding-top:16px;margin-top:24px;display:flex;justify-content:space-between;font-size:9px;color:#64748B;}</style></head>
<body><div class="cert-wrap">
<div class="header"><div><h1>SimpleBeacon Certification</h1><p style="margin:6px 0 0;font-size:11px;color:#60A5FA;">${profileLabel} — Compliance Index</p></div><div class="meta"><div>ID: ${certId}</div><div>Issued: ${dateStr}</div><div>SHA-256: ${shortHash}</div></div></div>
<p style="font-size:12px;color:#CBD5E1;margin:0 0 16px;">This document certifies the scan result metadata from the associated SimpleBeacon report. The underlying analysis was performed entirely on the local machine — no source code or AST was transmitted to external servers.</p>
<div class="panel"><div><span style="color:#9CA3AF;">Project:</span> <strong>${escapeHtml(projectName)}</strong></div><div><span style="color:#9CA3AF;">Files:</span> <strong>${fileCount}</strong></div><div><span style="color:#9CA3AF;">Lines:</span> <strong>${lineCount.toLocaleString()}</strong></div><div><span style="color:#9CA3AF;">Gate:</span> <strong style="color:${gateColor};">${gateLabel}</strong></div><div><span style="color:#9CA3AF;">Grade:</span> <strong style="color:${gradeColor};font-size:13px;">${grade}</strong></div><div><span style="color:#9CA3AF;">Findings:</span> <strong>${issueCount}</strong></div><div><span style="color:#9CA3AF;">Scope:</span> <strong>${filteredReport.generatedBy?.includes('Browser') ? 'Browser Sandbox' : 'Local CLI'}</strong></div><div><span style="color:#9CA3AF;">Quality:</span> <strong>${qs}/100</strong></div></div>
<div class="seal"><p style="font-size:9px;font-weight:700;color:#60A5FA;text-transform:uppercase;letter-spacing:0.05em;margin:0 0 6px;">Cryptographic Verification Seal</p><code>SHA-256: ${reportHash}</code><p style="font-size:8px;color:#475569;margin:4px 0 0;">This hash cryptographically binds the certificate to the underlying report.json. Re-scanning will produce a different hash.</p></div>
<div class="footer"><div>Token: ${token.slice(0,8)}...${token.slice(-4)} (Client-Side Runtime)</div><div style="font-weight:700;color:#9CA3AF;">SIMPLEBEACON SOVEREIGN PROTOCOL</div></div>
</div></body></html>`;

    const readme = `# SimpleBeacon Executive Risk Certificate

**Project:** ${projectName}
**Certificate ID:** ${certId}
**Issued:** ${dateStr}
**Grade:** ${grade}
**Gate:** ${gateLabel}
**Quality Score:** ${qs}/100
**Files Analyzed:** ${fileCount}
**SHA-256:** ${reportHash}
**Product Tier:** ${window._tokenPayload ? (window._tokenPayload.tier || window._tokenPayload.product || 'executive').toUpperCase() : 'SOVEREIGN'}

Generated entirely in-browser. Zero data uploaded.
`;

    zip.file('certificate.html', certHtml);
    zip.file('report.json', JSON.stringify(assembledReport, null, 2));
    zip.file('README.md', readme);

    // Tier-filtered human-readable markdown reports
    if (allowedModules.includes('1')) {
        const gate = filteredReport.gateReport || filteredReport.gate || {};
        const blocking = gate.blockingFindings || gate.blockingIssues || [];
        const warnings = gate.allIssues || gate.warningIssues || [];
        const items = [];
        if (blocking.length) {
            items.push('## Blocking Issues\n');
            blocking.forEach((i, idx) => {
                const fp = Array.isArray(i.filePath) ? i.filePath.join(', ') : (i.filePath || 'N/A');
                items.push(`${idx + 1}. **${i.type || 'Issue'}** — ${(i.severity || '').toUpperCase()}\n   - File(s): ${fp}\n   - Count: ${i.count || 0}${i.fix ? '\n   - Remediation: ' + i.fix : ''}`);
            });
        }
        if (warnings.length) {
            items.push('## Warnings\n');
            warnings.forEach((i, idx) => {
                const fp = Array.isArray(i.filePath) ? i.filePath.join(', ') : (i.filePath || 'N/A');
                items.push(`${idx + 1}. **${i.type || 'Issue'}** — ${(i.severity || '').toUpperCase()}\n   - File(s): ${fp}\n   - Count: ${i.count || 0}${i.fix ? '\n   - Remediation: ' + i.fix : ''}`);
            });
        }
        const findingsMd = `# Gate Findings Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n**Blocking:** ${blocking.length}\n**Warnings:** ${warnings.length}\n\n${items.length ? items.join('\n\n') : 'No blocking or warning issues detected.'}\n`;
        zip.file('findings.md', findingsMd);
    }

    if (allowedModules.includes('4')) {
        const phases = filteredReport.remediationPhases || [];
        const rm = filteredReport.roadmap || {};
        const roadmapMd = phases.length ? `# 5-Phase Compliance Roadmap\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n**Todo Items:** ${rm.todoCount || 0}\n\n${phases.map((p, idx) => `## ${idx + 1}. ${p.title || 'Untitled Phase'}\n\n${p.description || ''}\n\n- **Severity:** ${p.severity || 'N/A'}\n- **Effort:** ${p.effort || 'N/A'}\n- **Status:** ${p.status || 'N/A'}\n- **Progress:** ${p.progress ?? 0}%\n\n${(p.tasks || []).map(t => `- ${t}`).join('\n')}\n`).join('\n\n')}\n` : `# Roadmap\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n${rm.summary || 'No roadmap data available.'}\n`;
        zip.file('roadmap.md', roadmapMd);
    }

    if (allowedModules.includes('11')) {
        const eu = filteredReport.euAiActSummary || {};
        const euControls = eu.controls || [];
        const aiCount = eu.aiSystemIndicators || 0;
        const hrCount = eu.highRiskIndicators || 0;
        const tgCount = eu.transparencyGaps || 0;
        const docCount = eu.documentationArtifacts || 0;
        const docsFound = eu.documentationFound || [];
        const deadlineDate = new Date('2026-08-02');
        const daysUntil = Math.max(0, Math.ceil((deadlineDate - new Date(dateStr)) / (1000 * 60 * 60 * 24)));

        // Control cards
        const controlCards = euControls.length ? euControls.map(c => `### ${c.controlId}: ${c.title}\n\n- **Article:** ${c.article || 'N/A'}\n- **Status:** ${c.status || 'N/A'}\n- **Severity:** ${c.severity || 'N/A'}\n- **Evidence:** ${c.evidence || 'N/A'}\n- **Action:** ${c.action || 'N/A'}\n`).join('\n') : 'No controls data available.';

        // Risk matrix — use worst control status to drive overall risk, not just AI counts
        const worstControl = euControls.length ? euControls.reduce((w, c) => {
            const rank = { 'FAIL': 4, 'WARN': 3, 'REVIEW': 2, 'PASS': 1 };
            return rank[c.status] > rank[w.status] ? c : w;
        }, euControls[0]) : null;
        const likelihood = aiCount > 5 ? 'High' : (aiCount > 0 ? 'Medium' : 'Low');
        const impact = (worstControl && (worstControl.severity === 'critical' || worstControl.severity === 'high')) ? 'High' : (hrCount > 0 ? 'High' : (aiCount > 0 ? 'Medium' : 'Low'));
        const riskLevel = (likelihood === 'High' || impact === 'High') ? 'High' : (likelihood === 'Medium' || impact === 'Medium') ? 'Medium' : 'Low';
        const riskColor = riskLevel === 'High' ? '🔴' : (riskLevel === 'Medium' ? '🟡' : '🟢');

        // Remediation guide — PASS = no open task; REVIEW/WARN/FAIL = open task
        const remediationGuide = euControls.map(c => {
            if (c.status === 'PASS') return `- [ ] **${c.controlId}** — No open action. ${c.action}`;
            if (c.status === 'FAIL') return `- [ ] **${c.controlId}** — 🚨 **BLOCK RELEASE** until risk assessment and conformity documentation are complete.`;
            return `- [ ] **${c.controlId}** — ${c.action}`;
        }).join('\n');

        // Documentation checklist
        const requiredDocs = [
            { name: 'Model Card', pattern: /model[-_\s]?card/i, found: docsFound.some(d => /model[-_\s]?card/i.test(d)) },
            { name: 'Risk Assessment / FRIA', pattern: /risk[-_\s]?assessment|fundamental[-_\s]?rights/i, found: docsFound.some(d => /risk[-_\s]?assessment|fundamental[-_\s]?rights/i.test(d)) },
            { name: 'Technical Documentation', pattern: /technical[-_\s]?documentation|ai[-_\s]?system[-_\s]?documentation/i, found: docsFound.some(d => /technical[-_\s]?documentation/i.test(d)) },
            { name: 'Conformity Declaration', pattern: /conformity[-_\s]?declaration/i, found: docsFound.some(d => /conformity[-_\s]?declaration/i.test(d)) },
            { name: 'EU AI Act Reference', pattern: /eu[-_\s]?ai[-_\s]?act/i, found: docsFound.some(d => /eu[-_\s]?ai[-_\s]?act/i.test(d)) }
        ];
        const docChecklist = requiredDocs.map(d => `- [${d.found ? 'x' : ' '}] ${d.name}`).join('\n');

        const euMd = `# EU AI Act Assessment\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n## Executive Summary\n\n| Metric | Value |\n|---|---|\n| AI System Indicators | ${aiCount} |\n| High Risk Indicators | ${hrCount} |\n| Transparency Gaps | ${tgCount} |\n| Documentation Artifacts | ${docCount} |\n| Overall Risk Posture | ${riskColor} ${riskLevel} |\n\n${aiCount > 0 ? `**Risk Posture:** ${aiCount} AI indicator(s) detected; ${hrCount} high-risk; EU AI Act applicability review recommended.` : '**Risk Posture:** No AI indicators detected. EU AI Act obligations not applicable.'}\n\n---\n\n## Control Cards\n\n${controlCards}\n\n---\n\n## Risk Matrix\n\n| | **Impact: Low** | **Impact: Medium** | **Impact: High** |\n|---|---|---|---|\n| **Likelihood: High** | Medium | High | 🔴 **High** |\n| **Likelihood: Medium** | Low | 🟡 **Medium** | High |\n| **Likelihood: Low** | 🟢 **Low** | Low | Medium |\n\n**Position:** Likelihood = ${likelihood}, Impact = ${impact} → **${riskLevel} Risk**\n\n---\n\n## Remediation Guide\n\n${remediationGuide || 'No remediation actions required.'}\n\n---\n\n## Documentation Checklist\n\n${docChecklist}\n\n${docsFound.length ? `## Documentation Found\n\n${docsFound.map(f => `- ${f}`).join('\n')}\n` : ''}\n\n---\n\n## Deadline\n\n> **EU AI Act compliance deadline: August 2, 2026**\n> \n> ${daysUntil} days remaining.\n\n${eu.deadlineNote ? `> ${eu.deadlineNote}` : ''}\n`;
        zip.file('eu-ai-act.md', euMd);
    }

    // Module 5: Codebase Analysis
    if (allowedModules.includes('5')) {
        const cb = filteredReport.codebase || {};
        const langBreakdown = cb.languageBreakdown || {};
        const langRows = Object.entries(langBreakdown).map(([lang, count]) => `| ${lang} | ${count} |`).join('\n');
        const cbMd = `# Codebase Analysis\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| Total Files | ${cb.totalFiles || 0} |\n| Total Lines | ${(cb.totalLines || 0).toLocaleString()} |\n| Avg Lines/File | ${cb.averageLinesPerFile || 0} |\n\n${langRows ? `## Language Breakdown\n\n| Language | Files |\n|---|---|\n${langRows}\n` : ''}\n`;
        zip.file('codebase.md', cbMd);
    }

    // Module 7: Data Quality
    if (allowedModules.includes('7')) {
        const dq = filteredReport.dataQuality || {};
        const dqMd = `# Data Quality Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| Invalid JSON | ${dq.invalidJsonCount || 0} |\n| Empty JSON | ${dq.emptyJsonCount || 0} |\n| Schema Compliance | ${dq.schemaCompliance != null ? dq.schemaCompliance + '%' : 'N/A'} |\n\n${dq.summary || 'No data quality issues detected.'}\n`;
        zip.file('data-quality.md', dqMd);
    }

    // Module 9: npm Audit
    if (allowedModules.includes('9')) {
        const npm = filteredReport.npmAudit || {};
        const pkgFiles = (npm.packageJsonFiles || []).slice(0, 10);
        const npmMd = `# npm Audit Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| package.json Files | ${npm.packageJsonCount || 0} |\n| Total Dependencies | ${(npm.dependencyCount || 0).toLocaleString()} |\n| Avg Deps / Package | ${npm.packageJsonCount > 0 ? Math.round((npm.dependencyCount || 0) / npm.packageJsonCount) : 0} |\n\n${pkgFiles.length ? `## package.json Files\n\n${pkgFiles.map(f => `- ${f}`).join('\n')}\n` : ''}\n`;
        zip.file('npm-audit.md', npmMd);
    }

    // Module 10: Compliance
    if (allowedModules.includes('10')) {
        const comp = filteredReport.compliance || {};
        const licFiles = (comp.licenseFiles || []).slice(0, 10);
        const secFiles = (comp.securityFiles || []).slice(0, 10);
        const compMd = `# Compliance & Governance Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| License Files | ${comp.licenseCount || 0} |\n| Security Files | ${comp.securityCount || 0} |\n\n${licFiles.length ? `## License Files\n\n${licFiles.map(f => `- ${f}`).join('\n')}\n` : ''}\n${secFiles.length ? `## Security / Governance Files\n\n${secFiles.map(f => `- ${f}`).join('\n')}\n` : ''}\n`;
        zip.file('compliance.md', compMd);
    }

    // Module 12: Dependency Vulnerabilities
    if (allowedModules.includes('12')) {
        const dep = filteredReport.dependencyAudit || filteredReport.vulnerabilityAudit || {};
        const vulnCount = dep.vulnerabilityCount || 0;
        const crit = dep.critical || 0;
        const high = dep.high || 0;
        const affected = (dep.affectedPackages || dep.affectedFiles || []).slice(0, 10);
        const depMd = `# Dependency Vulnerability Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| Total Vulnerabilities | ${vulnCount} |\n| Critical | ${crit} |\n| High | ${high} |\n\n${affected.length ? `## Affected Packages\n\n${affected.map(f => `- ${f}`).join('\n')}\n` : ''}\n${vulnCount ? '> Run `npm audit fix` to auto-resolve patchable issues. Review breaking changes before major version bumps.\n' : ''}\n`;
        zip.file('dependency-vulns.md', depMd);
    }

    // Module 13: Build Readiness
    if (allowedModules.includes('13')) {
        const allFiles = filteredReport.fileList || filteredReport.repositoryInventory?.totalFiles || [];
        const filePaths = Array.isArray(allFiles) ? allFiles : [];
        const lowerPaths = filePaths.map(f => (typeof f === 'string' ? f : f.path || '').toLowerCase());
        const checks = [
            { name: 'package.json', found: lowerPaths.some(p => p.endsWith('package.json')) },
            { name: 'Lockfile', found: lowerPaths.some(p => /package-lock\.json|yarn\.lock|pnpm-lock\.yaml/.test(p)) },
            { name: 'README', found: lowerPaths.some(p => /readme\.?/.test(p)) },
            { name: 'CHANGELOG', found: lowerPaths.some(p => /changelog|changes|history/i.test(p)) },
            { name: 'Tests', found: lowerPaths.some(p => /test|spec|\.test\.|\.spec\.|__tests__|jest\.config|vitest\.config|cypress/i.test(p)) },
            { name: 'CI/CD', found: lowerPaths.some(p => /\.github\/workflows|\.gitlab-ci|jenkins|\.circleci|\.travis|azure-pipelines|build\.yml|deploy\.yml/i.test(p)) },
            { name: 'Docker', found: lowerPaths.some(p => /dockerfile|docker-compose|\.dockerignore/i.test(p)) },
            { name: 'Linting/Formatting', found: lowerPaths.some(p => /eslint|prettier|\.editorconfig|lint-staged|husky/i.test(p)) },
            { name: 'TypeScript Config', found: lowerPaths.some(p => /tsconfig|\.ts$/i.test(p)) },
            { name: 'Build Tool Config', found: lowerPaths.some(p => /(webpack|rollup|vite|esbuild|parcel|babel|gulpfile|gruntfile)/i.test(p)) },
            { name: '.env.example', found: lowerPaths.some(p => /\.env\.example|\.env\.sample|\.env\.template/i.test(p)) },
            { name: '.gitignore', found: lowerPaths.some(p => p.includes('.gitignore')) },
            { name: 'Build artifacts ignored', found: !lowerPaths.some(p => /\/(dist|build|\.next|out)\//.test(p) && !/node_modules\//.test(p)) }
        ];
        const readinessScore = Math.round(((checks.filter(c => c.found).length / checks.length) * 100));
        const present = checks.filter(c => c.found).map(c => `- [x] ${c.name}`).join('\n');
        const missing = checks.filter(c => !c.found).map(c => `- [ ] ${c.name}`).join('\n');
        const brMd = `# Build Readiness Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n**Score:** ${readinessScore}%\n\n## Present\n\n${present}\n\n## Missing\n\n${missing}\n`;
        zip.file('build-readiness.md', brMd);
    }

    // Module 14: AI System Indicators
    if (allowedModules.includes('14')) {
        const ai = filteredReport.aiIndicators || filteredReport.aiSystemIndicators || {};
        const aiFiles = (ai.files || []).slice(0, 10);
        const aiMd = `# AI System Indicators Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| AI SDK Imports | ${ai.sdkCount || ai.aiSystemIndicators || 0} |\n| Model References | ${ai.modelCount || 0} |\n\n${aiFiles.length ? `## Files with AI Indicators\n\n${aiFiles.map(f => `- ${f}`).join('\n')}\n` : ''}\n`;
        zip.file('ai-indicators.md', aiMd);
    }

    // Module 15: Governance
    if (allowedModules.includes('15')) {
        const gov = filteredReport.governance || {};
        const govFiles = (gov.files || []).slice(0, 10);
        const govMd = `# License & Governance Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| License Headers | ${gov.licenseHeaders || 0} |\n| Copyright Notices | ${gov.copyrightNotices || 0} |\n\n${govFiles.length ? `## Files with License Headers\n\n${govFiles.map(f => `- ${f}`).join('\n')}\n` : ''}\n`;
        zip.file('governance.md', govMd);
    }

    // Module 16: Junk & Temporary Files
    if (allowedModules.includes('16')) {
        const junk = filteredReport.junkFiles || {};
        const junkFileList = (junk.files || []).slice(0, 10);
        const junkMd = `# Junk & Temporary Files Report\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n\n| Metric | Value |\n|---|---|\n| Junk / Temp Files | ${junk.fileCount || 0} |\n\n${junkFileList.length ? `## Files Detected\n\n${junkFileList.map(f => `- ${f}`).join('\n')}\n` : ''}\n> Clean up temporary files, editor backups, and OS artifacts before production builds.\n`;
        zip.file('junk-files.md', junkMd);
    }

    // Modules 17-32: schema-driven markdown generation
    ZIP_MARKDOWN_TEMPLATES.forEach(t => generateZipModuleMarkdown(zip, allowedModules, filteredReport, projectName, dateStr, t));

    // Executive Summary — consolidated overview of all included modules
    const execSections = [];
    if (allowedModules.includes('1')) {
        const g = filteredReport.gateReport || filteredReport.gate || {};
        execSections.push(`## Gate Scan\n- Blocking: ${(g.blockingIssues || []).length}\n- Warnings: ${(g.warningIssues || []).length}\n- Status: ${g.pass ? 'PASS' : 'BLOCKED'}`);
    }
    if (allowedModules.includes('5')) {
        const cb = filteredReport.codebase || {};
        execSections.push(`## Codebase Analysis\n- Files: ${cb.totalFiles || 0}\n- Lines: ${(cb.totalLines || 0).toLocaleString()}\n- Avg lines/file: ${cb.averageLinesPerFile || 0}`);
    }
    if (allowedModules.includes('7')) {
        const dq = filteredReport.dataQuality || {};
        execSections.push(`## Data Quality\n- Invalid JSON: ${dq.invalidJsonCount || 0}\n- Empty JSON: ${dq.emptyJsonCount || 0}\n- Schema compliance: ${dq.schemaCompliance != null ? dq.schemaCompliance + '%' : 'N/A'}`);
    }
    if (allowedModules.includes('9')) {
        const npm = filteredReport.npmAudit || {};
        execSections.push(`## npm Audit\n- package.json files: ${npm.packageJsonCount || 0}\n- Dependencies: ${(npm.dependencyCount || 0).toLocaleString()}`);
    }
    if (allowedModules.includes('10')) {
        const comp = filteredReport.compliance || {};
        execSections.push(`## Compliance\n- License files: ${comp.licenseCount || 0}\n- Security files: ${comp.securityCount || 0}`);
    }
    if (allowedModules.includes('11')) {
        const eu = filteredReport.euAiActSummary || {};
        const euControls = eu.controls || [];
        execSections.push(`## EU AI Act\n- AI indicators: ${eu.aiSystemIndicators || 0}\n- High risk: ${eu.highRiskIndicators || 0}\n- Transparency gaps: ${eu.transparencyGaps || 0}\n\n### Controls\n\n| Control ID | Article | Status | Severity | Action |\n|---|---|---|---|---|\n${euControls.map(c => `| ${c.controlId} | ${(c.article || '').split(',').pop()?.trim() || 'N/A'} | ${c.status} | ${c.severity} | ${c.action.substring(0, 60)}${c.action.length > 60 ? '...' : ''} |`).join('\n')}`);
    }
    if (allowedModules.includes('12')) {
        const dep = filteredReport.dependencyAudit || filteredReport.vulnerabilityAudit || {};
        execSections.push(`## Dependency Vulnerabilities\n- Total: ${dep.vulnerabilityCount || 0}\n- Critical: ${dep.critical || 0}\n- High: ${dep.high || 0}`);
    }
    if (allowedModules.includes('15')) {
        const gov = filteredReport.governance || {};
        execSections.push(`## Governance\n- License headers: ${gov.licenseHeaders || 0}\n- Copyright notices: ${gov.copyrightNotices || 0}`);
    }
    if (allowedModules.includes('16')) {
        const junk = filteredReport.junkFiles || {};
        execSections.push(`## Junk & Temporary Files\n- Junk / temp files: ${junk.fileCount || 0}`);
    }
    // New modules in executive summary
    if (allowedModules.includes('17')) {
        const ar = filteredReport.aiResidue || {};
        execSections.push(`## AI Residue\n- AI residue hits: ${ar.aiResidueHits || 0}`);
    }
    if (allowedModules.includes('18')) {
        const perf = filteredReport.performance || {};
        execSections.push(`## Performance\n- Performance anti-patterns: ${perf.performanceHits || 0}`);
    }
    if (allowedModules.includes('19')) {
        const ts = filteredReport.typeSafety || {};
        execSections.push(`## Type Safety\n- Type safety gaps: ${ts.typeSafetyHits || 0}`);
    }
    if (allowedModules.includes('20')) {
        const doc = filteredReport.documentation || {};
        execSections.push(`## Documentation\n- Documentation gaps: ${doc.documentationHits || 0}`);
    }
    if (allowedModules.includes('21')) {
        const tc = filteredReport.testCoverage || {};
        execSections.push(`## Test Coverage\n- Test coverage gaps: ${tc.testCoverageHits || 0}`);
    }
    if (allowedModules.includes('22')) {
        const a11y = filteredReport.accessibility || {};
        execSections.push(`## Accessibility\n- Accessibility gaps: ${a11y.accessibilityHits || 0}`);
    }
    if (allowedModules.includes('23')) {
        const i18n = filteredReport.i18n || {};
        execSections.push(`## i18n Readiness\n- i18n issues: ${i18n.i18nHits || 0}`);
    }
    if (allowedModules.includes('24')) {
        const sd = filteredReport.sensitiveData || {};
        execSections.push(`## Sensitive Data\n- Sensitive data exposures: ${sd.sensitiveDataHits || 0}`);
    }
    if (allowedModules.includes('25')) {
        const cd = filteredReport.configDrift || {};
        execSections.push(`## Config Drift\n- Configuration drifts: ${cd.configDriftHits || 0}`);
    }
    if (allowedModules.includes('26')) {
        const sh = filteredReport.securityHeaders || {};
        execSections.push(`## Security Headers\n- Security header references: ${sh.securityHeadersHits || 0}`);
    }
    if (allowedModules.includes('27')) {
        const db = filteredReport.databasePatterns || {};
        execSections.push(`## Database Patterns\n- Database anti-patterns: ${db.databasePatternsHits || 0}`);
    }
    if (allowedModules.includes('28')) {
        const fw = filteredReport.frameworkPractices || {};
        execSections.push(`## Framework Practices\n- Framework issues: ${fw.frameworkPracticesHits || 0}`);
    }
    if (allowedModules.includes('29')) {
        const wh = filteredReport.workspaceHealth || {};
        execSections.push(`## Workspace Health\n- Workspace issues: ${wh.workspaceHealthHits || 0}`);
    }
    if (allowedModules.includes('30')) {
        const ud = filteredReport.unusedDeps || {};
        execSections.push(`## Unused Dependencies\n- Unused dependency flags: ${ud.unusedDepsHits || 0}`);
    }
    if (allowedModules.includes('31')) {
        const ac = filteredReport.apiContract || {};
        execSections.push(`## API Contract\n- API contract drifts: ${ac.apiContractHits || 0}`);
    }
    if (allowedModules.includes('32')) {
        const cx = filteredReport.complexity || {};
        execSections.push(`## Complexity Metrics\n- High complexity patterns: ${cx.complexityHits || 0}`);
    }
    if (execSections.length) {
        const execMd = `# Executive Summary\n\n**Project:** ${projectName}\n**Date:** ${dateStr}\n**Grade:** ${grade}\n**Quality Score:** ${qs}/100\n**Gate:** ${gateLabel}\n**Modules Included:** ${allowedModules.length} of 32\n\n---\n\n${execSections.join('\n\n---\n\n')}\n`;
        zip.file('executive-summary.md', execMd);
    }

    let createdModules = 0;
    for (const mod of allowedModules) {
        const data = perModuleData[mod];
        const cleanData = data ? Object.fromEntries(Object.entries(data).filter(([_, v]) => v != null)) : {};
        if (Object.keys(cleanData).length === 0) {
            cleanData._note = 'Module enabled by token but no scan data available in this report.';
        }
        zip.file(`module-${mod}.json`, JSON.stringify(cleanData, null, 2));
        createdModules++;
    }


    zip.file('manifest.json', JSON.stringify({
        generator: 'SimpleBeacon Sovereign Engine v1.4.0',
        timestamp: isoDate,
        certificateId: certId,
        tokenPrefix: token.slice(0,8) + '...',
        reportIntegrity: reportHash,
        localOnly: true,
        zeroUpload: true,
        includedModules: allowedModules
    }, null, 2));

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `simplebeacon-certificate-${isoDate.slice(0,10)}.zip`;
    a.style.display = 'none';
    document.body.appendChild(a);
    try { a.click(); } catch (e) { window.open(url, '_blank'); }
    setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 5000);
}

async function doGenerateCertificate(buttonEl) {
    const token = licenseInput ? licenseInput.value.trim() : '';
    const tokenError = document.getElementById('tokenError');
    if (tokenError) tokenError.classList.add('hidden-display');
    if (!reportData) {
        showToast('No scan report loaded. Upload a JSON || run a browser scan first.', 'error');
        showStatus('No report data. Upload || scan first.', 'error');
        return;
    }

    if (buttonEl) {
        buttonEl.disabled = true;
        buttonEl.classList.add('btn-loading');
    }
    showStatus('Generating certificate locally in browser sandbox...', 'loading');

    try {
        await generateSovereignCertificate(reportData, token);
        updateStepper();
        showToast('Certificate ZIP downloaded — generated entirely in your browser!', 'success', 6000);
        showStatus('Certificate ZIP generated locally! Zero bytes uploaded to any server.', 'success');
    } catch (err) {
        const errMsg = (err && err.message) || (typeof err === 'string' ? err : JSON.stringify(err));
        appendTerminalLine(`Certificate generation failed: ${errMsg || 'Unknown error'}`, 'error');
        showToast(errMsg || 'Certificate generation failed', 'error');
        const statusEl = document.getElementById('status');
        if (statusEl) {
            const safeErr = String(errMsg || 'Unknown error').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
            statusEl.innerHTML = `<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;"><span>${safeErr}</span><button id="retryCertBtn" style="padding:6px 14px;background:var(--accent);color:white;border:none;border-radius:6px;font-size:0.8rem;font-weight:600;cursor:pointer;">&#128260; Retry</button></div>`;
            statusEl.className = 'status error';
            statusEl.style.display = 'block';
            document.getElementById('retryCertBtn')?.addEventListener('click', () => {
                doGenerateCertificate(buttonEl);
            });
        }
    } finally {
        if (buttonEl) {
            buttonEl.disabled = false;
            buttonEl.classList.remove('btn-loading');
        }
    }
}
