const fs = require('fs');
const p = 'c:\\Users\\Trevor\\CascadeProjects\\coming-soon\\js\\dashboard\\main.js';
const lines = fs.readFileSync(p, 'utf8').split('\n');

let idx = -1;
for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes("pushModule('13'") && lines[i].includes('Build Readiness')) {
        idx = i;
        break;
    }
}

if (idx < 0) {
    console.log('pushModule 13 not found');
    process.exit(1);
}

// Find end of pushModule 13 call (the ], ... line)
let endIdx = idx + 1;
while (endIdx < lines.length && !lines[endIdx].trim().startsWith('],')) {
    endIdx++;
}

const insertLines = [
    '',
    '        // 14. AI System Indicators',
    "        const aiInd = data.aiIndicators || data.aiSystemIndicators || {};",
    "        const aiSdkCount = aiInd.sdkCount || aiInd.aiSystemIndicators || 0;",
    "        const aiModelCount = aiInd.modelCount || 0;",
    "        const aiFiles = (aiInd.files || []).slice(0, 6);",
    "        const aiColor = aiSdkCount > 0 ? '#EF4444' : (aiModelCount > 0 ? '#F59E0B' : null);",
    '        const aiDetail = aiSdkCount ? "<div class=\"detail-label\">AI SDK Imports</div><div style=\"font-size:0.72rem;color:var(--text-muted);margin-bottom:6px;\">" + aiSdkCount + " AI/LLM SDK import(s) detected.</div>" + (aiFiles.length ? "<div class=\"detail-label\">Files</div><ul>" + aiFiles.map(f=>"<li>"+f+"</li>").join("") + "</ul>" : "") + "<div class=\"detail-fix\">Verify all AI integrations are approved && document model usage for compliance.</div>" : "<div class=\"detail-label\">No AI indicators</div><div style=\"font-size:0.72rem;color:var(--text-muted);\">No AI/LLM SDK imports or model inference patterns detected.</div>";',
    "        pushModule('14', '&#129302;', 'AI System Indicators', [",
    "            {value: aiSdkCount, label: 'SDK imports', color: aiColor || '#60A5FA'},",
    "            {value: aiModelCount, label: 'Model refs'}",
    "        ], aiSdkCount ? aiSdkCount + ' AI SDK import' + (aiSdkCount === 1 ? '' : 's') + ' detected.' : 'No AI system indicators found.', aiColor, aiDetail);",
    '',
    '        // 15. License & Governance',
    "        const gov = data.governance || {};",
    "        const govLicense = gov.licenseHeaders || comp.licenseCount || 0;",
    "        const govCopyright = gov.copyrightNotices || 0;",
    "        const govFiles = (gov.files || []).slice(0, 6);",
    "        const govColor = govLicense === 0 ? '#EF4444' : (govCopyright === 0 ? '#F59E0B' : null);",
    '        const govDetail = govLicense ? "<div class=\"detail-label\">License Headers</div><div style=\"font-size:0.72rem;color:var(--text-muted);margin-bottom:6px;\">" + govLicense + " file(s) with license headers.</div>" + (govCopyright ? "<div style=\"font-size:0.72rem;color:var(--text-muted);margin-bottom:6px;\">" + govCopyright + " copyright notice(s).</div>" : "") + (govFiles.length ? "<div class=\"detail-label\">Files</div><ul>" + govFiles.map(f=>"<li>"+f+"</li>").join("") + "</ul>" : "") + "<div class=\"detail-fix\">Ensure license compatibility with your distribution model.</div>" : "<div class=\"detail-label\">No license headers</div><div style=\"font-size:0.72rem;color:var(--text-muted);\">No license or copyright markers detected.</div>";',
    "        pushModule('15', '&#128220;', 'License & Governance', [",
    "            {value: govLicense, label: 'License headers', color: govColor || '#60A5FA'},",
    "            {value: govCopyright, label: 'Copyright notices'}",
    "        ], govLicense ? govLicense + ' license header' + (govLicense === 1 ? '' : 's') + ' detected.' : 'No license or governance markers found.', govColor, govDetail);"
];

lines.splice(endIdx + 1, 0, ...insertLines);
fs.writeFileSync(p, lines.join('\n'));
console.log('Added modules 14 and 15 after line', endIdx + 1);
