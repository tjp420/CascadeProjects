#!/usr/bin/env node
/**
 * SimpleBeacon Project Cleanup Script
 * Safely removes accumulated junk: old backups, node_modules, cache, logs.
 *
 * Usage:
 *   node cleanup.js              # dry-run (shows what would be deleted)
 *   node cleanup.js --confirm    # actually delete
 *   node cleanup.js --days 7     # only touch items older than N days
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname);

const args = process.argv.slice(2);
const CONFIRM = args.includes('--confirm');
const DAYS = (() => {
  const idx = args.indexOf('--days');
  return idx !== -1 && args[idx + 1] ? parseInt(args[idx + 1], 10) : 0;
})();
const OLDER_THAN_MS = DAYS > 0 ? DAYS * 24 * 60 * 60 * 1000 : 0;

const JUNK_PATTERNS = [
  // SimpleBeacon backup files
  { pattern: '**/*.simplebeacon-backup.*', label: 'SimpleBeacon backups' },
  // Report delivery JSONs older than 30 days (keep recent)
  { pattern: '.simplebeacon/report-deliveries/*.json', label: 'old report deliveries', minAgeDays: 30 },
  // Email queue stale files
  { pattern: '.simplebeacon/email-queue/*.json', label: 'stale email queue', minAgeDays: 7 },
  // Old scan reports
  { pattern: '**/*-report.json', label: 'old scan reports', minAgeDays: 7 },
  // Root-level temp files
  { pattern: '*.log', label: 'log files', minAgeDays: 3 },
  { pattern: 'tmp-*.txt', label: 'temp text files' },
  { pattern: 'error-check*.log', label: 'error logs' },
];

const NODE_MODULES_TARGETS = [
  'ai-platform/node_modules',
  'coming-soon/node_modules',
  'packages/simplebeacon-cli/node_modules',
];

const CACHE_TARGETS = [
  'ai-platform/github-cache',
];

function isOlderThan(filePath, ms) {
  try {
    const stat = fs.statSync(filePath);
    return Date.now() - stat.mtime.getTime() > ms;
  } catch {
    return false;
  }
}

function globSync(dir, pattern) {
  const results = [];
  const parts = pattern.split('/');
  const isAbsolute = !pattern.startsWith('**/');
  const recurse = pattern.startsWith('**/');
  const targetPattern = recurse ? pattern.slice(3) : pattern;

  function walk(currentDir, depth) {
    let entries;
    try {
      entries = fs.readdirSync(currentDir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(currentDir, entry.name);
      const rel = path.relative(isAbsolute ? path.join(ROOT, dir) : ROOT, full);
      if (entry.isDirectory() && recurse) {
        walk(full, depth + 1);
        if (entry.name === targetPattern.split('/')[0]) {
          // Handle **/node_modules style
        }
      }
      if (entry.isFile() || entry.isDirectory()) {
        const match = rel.replace(/\\/g, '/');
        // Simple glob matching
        const regex = new RegExp('^' + targetPattern
          .replace(/\*\*/g, '.*')
          .replace(/\*/g, '[^/]*')
          .replace(/\?/g, '.')
          .replace(/\./g, '\\.') + '$');
        if (regex.test(match) || regex.test(entry.name)) {
          results.push(full);
        }
      }
    }
  }

  walk(isAbsolute ? path.join(ROOT, dir) : ROOT, 0);
  return results;
}

function collectTargets() {
  const toDelete = [];

  // Pattern-based files
  for (const item of JUNK_PATTERNS) {
    const minAge = item.minAgeDays ? item.minAgeDays * 24 * 60 * 60 * 1000 : 0;
    const files = globSync('.', item.pattern);
    for (const file of files) {
      if (minAge && !isOlderThan(file, minAge)) continue;
      if (OLDER_THAN_MS && !isOlderThan(file, OLDER_THAN_MS)) continue;
      toDelete.push({ path: file, label: item.label });
    }
  }

  // node_modules
  for (const rel of NODE_MODULES_TARGETS) {
    const full = path.join(ROOT, rel);
    if (fs.existsSync(full)) {
      toDelete.push({ path: full, label: 'node_modules' });
    }
  }

  // caches
  for (const rel of CACHE_TARGETS) {
    const full = path.join(ROOT, rel);
    if (fs.existsSync(full)) {
      toDelete.push({ path: full, label: 'cache' });
    }
  }

  return toDelete;
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getSize(targetPath) {
  let total = 0;
  try {
    const stat = fs.statSync(targetPath);
    if (stat.isFile()) return stat.size;
    if (stat.isDirectory()) {
      const entries = fs.readdirSync(targetPath, { withFileTypes: true });
      for (const entry of entries) {
        total += getSize(path.join(targetPath, entry.name));
      }
    }
  } catch {
    return 0;
  }
  return total;
}

function deleteItem(targetPath) {
  try {
    const stat = fs.statSync(targetPath);
    if (stat.isFile() || stat.isSymbolicLink()) {
      fs.unlinkSync(targetPath);
    } else if (stat.isDirectory()) {
      fs.rmSync(targetPath, { recursive: true, force: true });
    }
    return true;
  } catch (err) {
    return err.message;
  }
}

// ─── Main ───
const targets = collectTargets();

if (targets.length === 0) {
  console.log('✅ Nothing to clean. Workspace is tidy.');
  process.exit(0);
}

let totalSize = 0;
const byLabel = {};

for (const t of targets) {
  const size = getSize(t.path);
  totalSize += size;
  byLabel[t.label] = (byLabel[t.label] || 0) + size;
  const rel = path.relative(ROOT, t.path);
  console.log(`  ${CONFIRM ? '🔴' : '🟡'} ${rel}  (${formatBytes(size)})  [${t.label}]`);
}

console.log(`\n${'─'.repeat(50)}`);
console.log(`Total items: ${targets.length}`);
console.log(`Total reclaimable: ${formatBytes(totalSize)}`);

if (!CONFIRM) {
  console.log(`\n⚠️  This was a dry-run. Add --confirm to actually delete.`);
  console.log(`   node cleanup.js --confirm${DAYS ? ' --days ' + DAYS : ''}`);
  process.exit(0);
}

console.log('\nDeleting...');
let deleted = 0;
let failed = 0;
for (const t of targets) {
  const result = deleteItem(t.path);
  const rel = path.relative(ROOT, t.path);
  if (result === true) {
    console.log(`  ✅ ${rel}`);
    deleted++;
  } else {
    console.log(`  ⚠️  ${rel} — ${result}`);
    failed++;
  }
}

console.log(`\n${'─'.repeat(50)}`);
console.log(`Deleted: ${deleted} items`);
if (failed) console.log(`Skipped (locked/in-use): ${failed} items`);
console.log(`Reclaimed: ${formatBytes(totalSize)}`);
