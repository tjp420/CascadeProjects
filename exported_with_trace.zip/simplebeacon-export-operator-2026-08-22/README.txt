SimpleBeacon scan export bundle
Tier: Operator vault export
Generated: 2026-08-22T19:47:07.338Z

Contents:
  - json/public-summary.json — Public gate summary
  - json/simplebeacon-gate.json — SimpleBeacon gate report
  - json/fiction-digest.json — Fiction KPI digest
  - json/compliance-checklist.json — Compliance checklist
  - json/complete-scan.json — Complete scan bundle
  - json/consolidation.json — Consolidation report
  - json/codebase-summary.json — Codebase summary
  - json/file-reduction.json — File reduction scan
  - json/data-quality.json — Data quality scan
  - json/cleanup-brief.json — Cleanup assistant brief
  - json/npm-audit.json — npm audit summary
  - json/roadmap.json — Roadmap advisory
  - reports/executive-audit.html — Executive audit PDF source
  - reports/agency-certificate.html — Agency milestone certificate
  - json/re-attestation-note.json — Re-attestation cover letter metadata

Notes:
  - fiction-digest: not present in scan
  - compliance-checklist: not present - run compliance step or Complete scan
  - consolidation: not present in scan
  - codebase-summary: not present in scan
  - file-reduction: not present in scan
  - data-quality: not present in scan
  - cleanup-brief: not present in scan
  - npm-audit: not present in scan
  - roadmap: not present in scan

Print HTML reports to PDF for client delivery.
This bundle is a technical hygiene export — not legal conformity certification.